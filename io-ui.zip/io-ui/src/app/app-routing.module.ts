import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppPreloadingStrategy } from './app-routing-preloader';

const routes: Routes = [
  {
    path: '',
    loadChildren: './modules/home/home.module#HomeModule',
    data: {
      preload: true,
      delay: false,
    },
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    preloadingStrategy: AppPreloadingStrategy
 })],
  exports: [RouterModule],
  providers: [AppPreloadingStrategy]
})
export class AppRoutingModule { }
