import { AggregateStatsCardBase } from '../shared/interfaces/aggregate-stats-card';

export class AggregateStatsCardConfig {
    public static readonly aggregateStatsBase: AggregateStatsCardBase[] = [
        {
            title: 'Count of items',
            valueId: 'stockKeepingUnit',
            backgroundImage: 'assets/images/CountOfItems.svg'
        },
        {
            title: 'Current Inventory Baseline',
            valueId: 'currentInventoryBaseline',
            differenceId: 'currentInventoryBaselineDifference',
            backgroundImage: 'assets/images/CurrentInventoryBaseline.svg',
            currency: '$'
        },
        {
            title: 'Current Float Value',
            valueId: 'currentSafetyStock',
            differenceId: 'currentSafetyStockDifference',
            backgroundImage: 'assets/images/CurrentFloatValue.svg',
            currency: '$'
        },
        {
            title: 'Surplus Float Value',
            valueId: 'surplusSafetyStock',
            differenceId: 'surplusSafetyStockDifference',
            backgroundImage: 'assets/images/SurplusFloatValue.svg',
            currency: '$'
        },
      ];
}
