export class DashboardReportConfig {
    public static readonly details: any = [
        {
            id: 'dashboardOverview',
            name: 'Overview',
            show: false,
            chartData: {
                xAxis: {
                    category: [],
                    text: 'Part Number'
                },
                yAxis: {
                    text: 'Inventory Value (USD)'
                },
                dataSet: [
                    {
                        name: 'Current Float',
                        data: [],
                        color:  ['#4B84E5']
                    },
                    {
                        name: 'Float Surplus',
                        data: [],
                        offset: [],
                        color:  ['#3BC483']
                    },
                    {
                        name: 'Recommended Float',
                        data: [],
                        color:  ['#F8A23D']
                    },
                ],
                options: {
                    innerPadding: 0.2,
                    padding: 0.4,
                    margin:  { top:  50, right:  50, bottom:  50, left:  60 },
                    legend: { show: false}
                }
            },
            chartType: 'bar',
            legend: [
                {
                    type: 'bar',
                    color: '#4B84E5',
                    value: 'Current Float'
                },
                {
                    type: 'bar',
                    color: '#3BC483',
                    value: 'Float Surplus'
                },
                {
                    type: 'bar',
                    color: '#F8A23D',
                    value: 'Recommended Float'
                },
            ]
        },
        {
            id: 'dashboardDVC',
            name: 'Demand Variability Contribution',
            show: false,
            chartData: {
                xAxis: {
                    category: [],
                    text: 'Part Number'
                },
                yAxis: {
                    text: 'Average Daily Demand (EA)'
                },
                yAxisSecondary: {
                    text: 'Demand Coefficient of Variance %'
                },
                dataSet: [
                    {
                        name: 'Average Daily Demand (EA)',
                        data: [],
                        color:  ['#3BC483'],
                        type: 'bar'
                    },
                    {
                        name: 'Coefficient of Variance of Daily Demand (%)',
                        data: [],
                        color:  ['#FF627A'],
                        type: 'line',
                        lineDetails: {
                            curve: false,
                            dashed: true,
                            dashedWidth: 5,
                        },
                        yAxisSecondary: true,
                    },
                ],
                options: {
                    innerPadding: 0.2,
                    padding: 0.4,
                    margin:  { top:  50, right:  50, bottom:  50, left:  60 },
                    legend: { show: false}
                }
            },
            chartType: 'dual-axes-bar-line',
            legend: [
                {
                    type: 'bar',
                    color: '#3BC483',
                    value: 'Average Daily Demand (EA)'
                },
                {
                    type: 'line',
                    color: '#FF627A',
                    value: 'Coefficient of Variance of Daily Demand (%)'
                },
            ]
        },
        {
            id: 'dashboardSVC',
            name: 'Supply Variability Contribution',
            show: false,
            chartData: {
                xAxis: {
                    category: [],
                    text: 'Part Number'
                },
                yAxis: {
                    text: 'Supply Cycle Time (Days)'
                },
                yAxisSecondary: {
                    text: 'Lead Time Coefficient of Variance %'
                },
                dataSet: [
                    {
                        name: 'Average Supply Cycle Time (days)',
                        data: [],
                        color:  ['#35B0FF'],
                        type: 'bar'
                    },
                    {
                        name: 'Coefficient of Variance of Supply Cycle Time (%)',
                        data: [],
                        color:  ['#FF627A'],
                        type: 'line',
                        lineDetails: {
                            curve: false,
                            dashed: true,
                            dashedWidth: 5,
                        },
                        yAxisSecondary: true,
                    },
                ],
                options: {
                    innerPadding: 0.2,
                    padding: 0.4,
                    margin:  { top:  50, right:  50, bottom:  50, left:  60 },
                    legend: { show: false}
                }
            },
            chartType: 'dual-axes-bar-line',
            legend: [
                {
                    type: 'bar',
                    color: '#35B0FF',
                    value: 'Average Supply Cycle Time (days)'
                },
                {
                    type: 'line',
                    color: '#FF627A',
                    value: 'Coefficient of Variance of Supply Cycle Time (%)'
                },
            ]
        },
    ];
}
