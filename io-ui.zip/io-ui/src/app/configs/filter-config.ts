export class FilterConfig {
    public static readonly PARTS_CONTROLLER_FILTER_TYPE = 'Parts Controller';
    public static readonly SUPPLIER_FILTER_TYPE = 'Supplier';
    public static readonly CATEGORY_FILTER_TYPE = 'Category';
    public static readonly LOCATION_FILTER_TYPE = 'Location';
    public static readonly PARTS_FLOW_FILTER_TYPE = 'Parts Flow';
    public static readonly LOCATION_LIST = [{
        name : 'Domestic',
        id : 1
    },
    {
        name : 'Imported',
        id : 2
    },
   ];
    public static readonly PARTS_FLOW_LIST = [{
        name : 'Direct',
        id : 1
    },
    {
        name : 'ILC',
        id : 2
    }];
}
