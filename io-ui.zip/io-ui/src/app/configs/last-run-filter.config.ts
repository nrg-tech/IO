export class LastRunFilterConfig {
    public static readonly filters: any = [
        {
            id: '',
            name: 'Analyst Code',
            constant: false,
            type: '',
            path: ''
        },
        {
            id: '',
            name: 'Analyst Code',
            constant: false,
            type: '',
            path: ''
        },
    ];
}
