import { LastRunTableModel } from '../../modules/last-run/models/last-run-table-model';

export class LastRunMockConfig {
  public lastRunTableRows = [];

  constructor() {
    for (let i = 0; i < 150; i++) {
      this.lastRunTableRows.push(this.getLastRunTableRow(i));
    }
  }

  public getLastRunTableRow(i: number): LastRunTableModel {
    const row1 = new LastRunTableModel();
    row1.itemNumber = 'Part ' + i;
    row1.plantCode = 'NA ' + i;
    row1.modelExecutionDate = new Date();
    row1.supplierType = 'Supplier ' + i;
    row1.partsCategory = 'Category' + i;
    row1.partsController = 'Controller ' + i;
    return row1;
  }
}
