export class ScheduleRunMockConfig {

    public static offsets = [
      {
        offsetId: 302,
        offsetValue: 20,
        offsetName: 'Offset 1',
        offsetEndDate: '2019-08-29',
        offsetStartDate: '2019-07-17'
      },
      {
        offsetId: 301,
        offsetValue: 20,
        offsetName: 'Offset 2',
        offsetEndDate: '2019-08-29',
        offsetStartDate: '2019-07-17'
      }
      // ,
      // {
      //   offsetId: 304,
      //   offsetValue: 21,
      //   offsetEndDate: '2019-08-27',

      //   offsetName: 'Offset 2',
      //   offsetStartDate: '2019-07-18'
      // },
      // {
      //   offsetId: 305,
      //   offsetValue: 22,
      //   offsetEndDate: '2019-08-25',
      //   offsetName: 'Offset 3',
      //   offsetStartDate: '2019-07-19'
      // }
    ];

    public static tableRows = [{
       plantCode: 'abc',
       offsets: [
        {
          offsetId: 302,
          offsetValue: 20,
          offsetName: 'Offset 1',
          offsetEndDate: '2019-08-29',
          offsetStartDate: '2019-07-17'
        }
      ],
       lastRun: {
                currFloat: 10,
                recSL: 14.19,
                recFloat: 12
         },

       itemNumber: '20651EN30A        ',
       partId: 7005,
       modelExecutionDate: '2019-08-02T06:57:00.000+0000',
       unitPrice: 0.5,
       supplierType: 'Domestic',
       supplierCode: '1006606',
       baselineInventoryQuantity: 4981.12,
       baselineInventoryValue: 2490.56,
       abcClassInventoryValue: 'B',
       abcClassConsumptionValue: 'C',
       xyzClassCoefficientOfVarianceDemandForecast: 'X',
       minimumRanOrderQuantity: 140,
       snqQuantity: 140,
       floatRecommendedDays: 4,
       operationalReserveQuantity: 2686,
       operationalReserveValue: 1343,
       serviceLevel: 0.99,
       directPipelineStockQuantity: 0,
       ilcPipelineStockQuantity: 2,
       scrapPercentageToAnnualDemand: 0,
       cycleLossPercentageTotalAnnualDemand: 0.01,
       floatInventorySavings: 1343,
        totalRecommendedFloatHours: 6,
         totalRecommendedFloatDays: 7,
       minimumRecommendedFloatHours: 3,
     minimumRecommendedFloatDays: 5,
     minimumFloatQuantity: 4,
     changePercentageRecommendedFloatValue: 4,
     partsController: 'John Doe',
     partsCategory: '2',
     partTypeCode: 'Direct'
      },
      {
        plantCode: 'abc',
        offsets: [
                   {
                     offsetId: 303,
                     offsetValue: 20,
                     offsetName: 'Offset 1',
                     offsetEndDate: '2019-08-29',
                     offsetStartDate: '2019-07-17'
                   },
                   {
                     offsetId: 304,
                     offsetValue: 21,
                     offsetEndDate: '2019-08-27',
                     offsetName: 'Offset 2',
                     offsetStartDate: '2019-07-18'
                   },
                   {
                     offsetId: 305,
                     offsetValue: 22,
                     offsetEndDate: '2019-08-25',
                     offsetName: 'Offset 3',
                     offsetStartDate: '2019-07-19'
                   }
                 ],
        lastRun: {
                 currFloat: 10,
                 recSL: 12,
                 recFloat: 12
          },
       itemNumber: '3102070X2A       ' ,
       partId: 7006,
       modelExecutionDate: '2019-08-02T06:57:00.000+0000',
       unitPrice: 994.22,
       supplierType: 'Domestic',
       supplierCode: '1000200',
       baselineInventoryQuantity: 98.69,
       baselineInventoryValue: 98114.78,
       abcClassInventoryValue: 'A',
       abcClassConsumptionValue: 'A',
       xyzClassCoefficientOfVarianceDemandForecast: 'Z',
       minimumRanOrderQuantity: 180,
       snqQuantity: 4,
       floatRecommendedDays: 3,
       operationalReserveQuantity: 1981,
       operationalReserveValue: 1969549.82,
       serviceLevel: 0.99,
       directPipelineStockQuantity: 107,
       ilcPipelineStockQuantity: 2,
       scrapPercentageToAnnualDemand: 0,
       cycleLossPercentageTotalAnnualDemand: 0,
       totalRecommendedFloatHours: 6,
       totalRecommendedFloatDays: 9,
       floatInventorySavings: 1585566.47,
       minimumRecommendedFloatHours: 3,
     minimumRecommendedFloatDays: 5,
     minimumFloatQuantity: 4,
     mimimumFloatValue: 8,
     changePercentageRecommendedFloatValue: 4,
     partsController: 'John Doe',
     partsCategory: '2',
     partTypeCode: 'ILC'
      }
    ];
}
