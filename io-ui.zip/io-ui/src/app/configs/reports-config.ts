export class ReportsConfig {
    public static readonly reportTypes: string[] = ['Float Contribution', 'Surplus & Inadequate Safety Stock'];
    public static readonly parts: string[] = ['Top 15 Parts', 'Selected Parts'];
    public static readonly days: string[] = ['Today', 'Yesterday', 'Last Week'];
}
