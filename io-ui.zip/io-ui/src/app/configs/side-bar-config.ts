export class SideBarConfig {
    public static readonly menus: any = [
        {
          displayName: 'Dashboard',
          iconName: 'dashboard',
          route: '',
          activate: false,
        },
        {
          displayName: 'Inventory Output',
          iconName: 'inventory-output',
          activate: false,
          children: [
            {
              displayName: 'Latest Run',
              route: 'inventory-output/latest-run'
            },
            {
              displayName: 'Schedule Run',
              route: 'inventory-output/schedule-run'
            }
          ]
        },
        {
          displayName: 'Reports',
          iconName: 'reports',
          route: 'reports',
          activate: false,
          }
      ];
}
