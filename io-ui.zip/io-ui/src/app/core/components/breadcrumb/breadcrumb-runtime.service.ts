import { Injectable } from '@angular/core';
import { HttpService } from '../../services/http-service/http.service';
import { apiEndPoints } from 'src/app/configs/api-end-points';
import { Observable } from 'rxjs';
import { UrlCreatorService } from '../../services/url-creator/url-creator.service';
import { Runtime } from 'src/app/shared/interfaces/runtime';

@Injectable({
  providedIn: 'root'
})
export class BreadcrumbRuntimeService {

  constructor(
    private httpService: HttpService,
    private urlCreatorService: UrlCreatorService,
    ) { }

  getRuntime(currentPlantId: number): Observable<Runtime> {

    const paramDetailsMap = new Map();
    paramDetailsMap.set('plantId', currentPlantId);
    return this.httpService.get(this.urlCreatorService.createURL(apiEndPoints.runTime, paramDetailsMap));
  }
}
