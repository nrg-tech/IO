import { Component, OnInit, OnDestroy } from '@angular/core';
import { Breadcrumb } from 'src/app/shared/interfaces/breadcrumb';
import { Router, ActivatedRoute, NavigationEnd, Event } from '@angular/router';
import { filter, distinctUntilChanged } from 'rxjs/operators';
import { BreadcrumbService } from '../../services/breadcrumb/breadcrumb.service';
import { EventListenerService } from 'src/app/shared/services/event-listener/event-listener.service';
import { BreadcrumbRuntimeService } from './breadcrumb-runtime.service';
import { Runtime } from 'src/app/shared/interfaces/runtime';
import { Subscription } from 'rxjs';

@Component({
  selector: 'io-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss']
})
export class BreadcrumbComponent implements OnInit, OnDestroy {

  breadcrumbs: Breadcrumb[];
  subscriptions: Subscription[] = [];
  showingData = true;
  showRuntime = true;
  currentPlantId: number;
  runtime: Runtime;
  nextRuntime: Date;

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private breadcrumbService: BreadcrumbService,
    private breadcrumbRuntimeService: BreadcrumbRuntimeService,
    private eventListenerService: EventListenerService,
  ) {
    this.breadcrumbs = this.breadcrumbService.buildBreadCrumb(this.activatedRoute.root);
    this.getRuntime();
  }

  ngOnInit() {
    this.subscriptions.push(this.router.events.pipe(
      filter((event: Event) => event instanceof NavigationEnd),
      distinctUntilChanged(),
    ).subscribe(() => {
      this.breadcrumbs = this.breadcrumbService.buildBreadCrumb(this.activatedRoute.root);
      this.getRuntime();
    }));
    this.subscriptions.push(this.eventListenerService.currentPlantId.subscribe((currentPlantId: number) => {
      this.currentPlantId = currentPlantId;
      this.getRuntime();
    }));
  }

  getRuntime() {
    this.showRuntime = (this.breadcrumbs && this.breadcrumbs[0] && this.breadcrumbs[0].label === 'Reports') ? false : true;
    if (this.showRuntime) {
      this.showingData = (this.breadcrumbs && this.breadcrumbs[1] && this.breadcrumbs[1].label === 'Schedule Run') ? false : true;
    }

    if (!this.runtime) {
      if (this.currentPlantId !== null && this.currentPlantId !== undefined) {
        this.subscriptions.push(this.breadcrumbRuntimeService.getRuntime(this.currentPlantId).subscribe((response: Runtime) => {
          this.runtime = response;
          this.eventListenerService.updateRuntime(this.runtime);
          this.getNextRuntime(this.runtime.date);
        }));
      }
    }
  }

  getNextRuntime(date: Date) {
    const tempDate = new Date(date);
    tempDate.setDate(tempDate.getDate() + 1);  // adds 1 day to the last run date to get next run date
    this.nextRuntime = tempDate;
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
  }
}
