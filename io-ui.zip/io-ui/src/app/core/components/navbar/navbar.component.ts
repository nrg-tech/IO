import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavbarService } from './navbar.service';
import { PlantDetails } from 'src/app/shared/interfaces/plant-details';
import { UserDetails } from 'src/app/shared/interfaces/user-details';
import { EventListenerService } from 'src/app/shared/services/event-listener/event-listener.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'io-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit, OnDestroy {

  plantDetails: PlantDetails[];
  subscriptions: Subscription[] = [];
  userDetails: UserDetails;
  plantAbbrv = '';
  usernameAbbrv = '';
  usernameAbbrvBackColor: any;
  usernameAbbrvColor: any;
  constructor(private navbarService: NavbarService, private eventListenerService: EventListenerService) { }

  ngOnInit() {
    this.subscriptions.push(this.navbarService.getPlantDetails().subscribe((response: PlantDetails[]) => {
      this.plantDetails = response;
      this.eventListenerService.updatePlant(this.plantDetails[0].plantId);
      if (this.plantDetails && this.plantDetails[0] && this.plantDetails[0].plantName) {
        this.plantAbbrv = this.getAbbrv(this.plantDetails[0].plantName, 2);
      }
    }));

    this.subscriptions.push(this.navbarService.getUserDetails().subscribe((response: UserDetails) => {
      this.userDetails = response;
      if (!this.userDetails.userImage || this.userDetails.userImage === null) {
        this.usernameAbbrv = (this.userDetails.firstName && this.userDetails.lastName) ?
          this.getAbbrv(this.userDetails.firstName.concat(' ' + this.userDetails.lastName), 2) :
          (this.userDetails.firstName || this.userDetails.firstName !== null) ?
          this.getAbbrv(this.userDetails.firstName, 1) :
          this.getAbbrv(this.userDetails.lastName, 1);
        this.getColor();
      }
    }));
  }

  getAbbrv(name: string, charCount: number) {
    const words = name.split(' ', charCount);
    let abbrv = '';
    words.forEach(word => {
      abbrv += word[0].toUpperCase();
    });
    return abbrv;
  }

  getColor() {
    const backgroundColorPallete = ['rgba(28, 202, 184, 0.07)', 'rgba(255, 98, 122, 0.07)',
                                    'rgba(255, 156, 0, 0.07)', 'rgba(106, 105, 244, 0.07)'];
    const textColorPallete = ['rgba(28, 202, 184, 1)', 'rgba(255, 98, 122, 1)',
                              'rgba(255, 156, 0, 1)', 'rgba(106, 105, 244, 1)'];
    const index = Math.floor(Math.random() * backgroundColorPallete.length);
    const backColor = backgroundColorPallete[index];
    const textColor = textColorPallete[index];
    this.usernameAbbrvBackColor = backColor;
    this.usernameAbbrvColor = textColor;
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
  }

}
