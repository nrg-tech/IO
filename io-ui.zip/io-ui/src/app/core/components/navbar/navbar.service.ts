import { Injectable } from '@angular/core';
import { HttpService } from '../../services/http-service/http.service';
import { apiEndPoints } from 'src/app/configs/api-end-points';
import { Observable } from 'rxjs';
import { PlantDetails } from 'src/app/shared/interfaces/plant-details';
import { UserDetails } from 'src/app/shared/interfaces/user-details';

@Injectable({
  providedIn: 'root'
})
export class NavbarService {

  constructor(private httpService: HttpService) { }

  getPlantDetails(): Observable<PlantDetails[]> {
    return this.httpService.get(apiEndPoints.plantDetails);
  }

  getUserDetails(): Observable<UserDetails> {
    return this.httpService.get(apiEndPoints.userDetails);
  }
}
