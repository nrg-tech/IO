import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd, Event } from '@angular/router';
import { SideBarConfig } from 'src/app/configs/side-bar-config';
import { Breadcrumb } from 'src/app/shared/interfaces/breadcrumb';
import { BreadcrumbService } from '../../services/breadcrumb/breadcrumb.service';
import { filter, distinctUntilChanged } from 'rxjs/operators';
import { Subscription } from 'rxjs';
@Component({
  selector: 'io-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit, OnDestroy {

  public menus: any[];
  public breadcrumbs: Breadcrumb[];
  subscriptions: Subscription[] = [];

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private breadcrumbService: BreadcrumbService,
    ) {
        this.breadcrumbs = this.breadcrumbService.buildBreadCrumb(this.activatedRoute.root);
     }

  ngOnInit() {
    this.menus = SideBarConfig.menus;
    this.getActiveMenu();
    this.subscriptions.push(this.router.events.pipe(
      filter((event: Event) => event instanceof NavigationEnd),
      distinctUntilChanged(),
      ).subscribe(() => {
        this.breadcrumbs = this.breadcrumbService.buildBreadCrumb(this.activatedRoute.root);
        this.getActiveMenu();
      }));
  }

  getActiveMenu() {
    const activeMenu = (this.breadcrumbs && this.breadcrumbs[0] && this.breadcrumbs[0].label) ? this.breadcrumbs[0].label : '';
    for (const menu of this.menus) {
      menu.activate = (menu.displayName === activeMenu) ? true : false;
    }
  }

  expand(firstChildRoutePath: string, event: any) {
    const item = this.removeClasses(event);
    item.classList.add('activate');
    item.classList.toggle('active');
    item.getElementsByClassName('icon-style')[0].classList.add('activate');
    const collapseItem = item.nextElementSibling as HTMLElement;
    if (collapseItem.style.display === 'block') {
      collapseItem.style.display = 'none';
    } else {
      collapseItem.style.display = 'block';
    }
    let containsActivate = false;
    const collapseItemArray = Array.prototype.slice.call(collapseItem.children[0].children);
    for (const collapseItemElement of collapseItemArray) {
      if (collapseItemElement.classList.contains('activate')) {
        containsActivate = true;
      }
    }
    if (!containsActivate) {
      collapseItem.children[0].children[0].classList.add('activate');
      this.route(firstChildRoutePath);
    }
  }

  activate(path: string, event: any) {
    const item = this.removeClasses(event);
    item.classList.add('activate');
    this.router.navigateByUrl(path);
  }

  private removeClasses(event: any) {
    const item = document.getElementById(event.target.id);
    const collapseClasses = document.querySelectorAll('.list-items');
    const collapseClassesArray = Array.prototype.slice.call(collapseClasses);
    for (const collapseClass of collapseClassesArray) {
      if (item !== collapseClass) {
        collapseClass.classList.remove('active');
        collapseClass.classList.remove('activate');
        collapseClass.getElementsByClassName('icon-style')[0].classList.remove('activate');
        const collapseClassNextElement = collapseClass.nextElementSibling;
        if (collapseClassNextElement && collapseClassNextElement.style) {
          collapseClassNextElement.style.display = 'none';
          const collapseClassNextElementArray = Array.prototype.slice.call(collapseClassNextElement.children[0].children);
          for (const collapseClassElement of collapseClassNextElementArray) {
            if (collapseClassElement.classList.contains('activate')) {
              collapseClassElement.classList.remove('activate');
            }
          }
        }
      }
    }
    return item;
  }

  route(path: string, event?: any) {
    if (event) {
      const listItem = document.querySelector('#' + event.target.id);
      listItem.classList.add('activate');
      if (listItem.previousElementSibling !== null) {
        this.deActivateSiblings(listItem, 'previous');
      }
      if (listItem.nextElementSibling !== null) {
        this.deActivateSiblings(listItem, 'next');
      }
    }
    this.router.navigateByUrl(path);
  }

  deActivateSiblings(listItem: any, order: string) {
    let orderElement: any;
    if (order === 'previous') {
      orderElement = listItem.previousElementSibling;
      while (orderElement) {
        orderElement.classList.remove('activate');
        orderElement = orderElement.previousElementSibling;
      }
    } else {
      orderElement = listItem.nextElementSibling;
      while (orderElement) {
        orderElement.classList.remove('activate');
        orderElement = orderElement.nextElementSibling;
      }
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
  }
}
