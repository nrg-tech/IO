import { Injectable } from '@angular/core';
import { apiEndPoints } from 'src/app/configs/api-end-points';

@Injectable({
  providedIn: 'root'
})
export class UrlCreatorService {

  constructor() { }

  createURL(endpoint: string, additionalParamsMap: Map<any, any>) {
    let apiEndpoint = endpoint;
    if (additionalParamsMap && additionalParamsMap.size) {
      additionalParamsMap.forEach((value, key) => {
        const regEx = new RegExp('{(' + key + ')}', 'g');
        apiEndpoint = apiEndpoint.replace(regEx , value);
      });
    }
    return apiEndpoint;
  }
}
