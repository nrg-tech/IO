import { CommonModule } from '@angular/common';
import tip from 'd3-tip';
import { v4 } from 'uuid';
import { Component, Input, ViewChild, ViewEncapsulation, NgModule } from '@angular/core';
import { stack, stackOffsetDiverging, line, curveCardinal, select, max, min, scaleBand, scaleLinear, axisLeft, axisBottom, sum, selectAll, scaleOrdinal, format, axisRight } from 'd3';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/** @type {?} */
const tooltipTemplate = '<div class="tool-tip-container">'
    + '<div class="heading">d.xAxis</div>'
    + '<div class="content">'
    + '<div class="circle" style="background : d.color;"></div>'
    + '<div class="legend-value"> d.legendName :</div>'
    + '<div class="value">d.data</div>'
    + '</div>'
    + '</div>';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CommonChartComponent {
    constructor() {
        this.margin = { top: 50, right: 50, bottom: 50, left: 50 }; // default margin
        this.noOfYAxisTick = 5;
        this.convertedData = [];
        this.error = false;
        this.tickList = [];
        this.tickListSecondary = [];
        this.bufferMargin = 25;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.createId();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.generateChart(this.data);
    }
    /**
     * @return {?}
     */
    createId() {
        this.chartId = `d3c-${v4().substring(0, 8)}`;
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        if (!changes['data'].isFirstChange()) {
            // do stuff if this is not the initialization of 'data'
            this.generateChart(this.data);
        }
    }
    // onResize() {
    //   this.generateChart(this.data);
    // }
    // this functions needs to be overridden by the developers in order to draw chart on svg on X and Y Axis
    /**
     * @param {?} chart
     * @param {?} data
     * @param {?} xScaleGroup
     * @param {?} xScaleIndividual
     * @param {?} yScale
     * @param {?=} yScaleSecondary
     * @return {?}
     */
    draw(chart, data, xScaleGroup, xScaleIndividual, yScale, yScaleSecondary) { }
    /**
     * @param {?} data
     * @return {?}
     */
    generateChart(data) {
        if (!(data && data.dataSet)) {
            console.log('dataSet attribute is mandatory.');
            return;
        }
        this.width = this.chartContainer.nativeElement.clientWidth || 800;
        this.height = this.chartContainer.nativeElement.clientHeight || 800;
        this.clearChart();
        this.getMinMaxValueAndCount(data.dataSet);
        if (this.error) {
            return;
        }
        if (data.xAxis && data.xAxis.category) {
            if (data.xAxis.category.length !== this.maxCount) {
                console.log('The X axis category length does not match the max length of data in dataSet');
                return;
            }
        }
        else {
            if (!data.xAxis) {
                data.xAxis = {};
                data.xAxis.category = [];
            }
            for (let i = 1; i <= this.maxCount; i++) {
                data.xAxis.category.push(i.toString());
            }
        }
        if (data && data.options && data.options.margin) {
            this.setMargin(data.options.margin);
        }
        this.setPaddings(data);
        this.setNoOfYAxisTick(data);
        console.log('before', this.margin);
        if (this.min !== undefined && this.max !== undefined) {
            this.setSideMargin(this.max, this.min, 'left');
        }
        if (this.secondaryMin !== undefined && this.secondaryMax !== undefined) {
            this.setSideMargin(this.secondaryMax, this.secondaryMin, 'right');
        }
        console.log('after', this.margin);
        this.drawChart(data);
    }
    // sets paddings
    /**
     * @param {?} data
     * @return {?}
     */
    setPaddings(data) {
        this.padding = (data.options && data.options.padding) ? data.options.padding : 0.3;
        this.innerPadding = (data.options && data.options.innerPadding) ? data.options.innerPadding : 0.2;
    }
    // sets the Y Axis tick count
    /**
     * @param {?} data
     * @return {?}
     */
    setNoOfYAxisTick(data) {
        if (data.yAxis && data.yAxisSecondary && data.yAxis.noOfTicks && data.yAxisSecondary.noOfTicks) {
            if (data.yAxisSecondary.noOfTicks === data.yAxis.noOfTicks) {
                this.noOfYAxisTick = data.yAxis.noOfTicks;
            }
            else {
                this.noOfYAxisTick = Math.max(data.yAxis.noOfTicks, data.yAxisSecondary.noOfTicks);
            }
        }
        else if (data.yAxis && data.yAxis.noOfTicks) {
            this.noOfYAxisTick = data.yAxis.noOfTicks;
        }
        else if (data.yAxisSecondary && data.yAxisSecondary.noOfTicks) {
            this.noOfYAxisTick = data.yAxisSecondary.noOfTicks;
        }
        else {
            this.noOfYAxisTick = 5;
        }
    }
    // Clears the current chart which is drawn
    /**
     * @return {?}
     */
    clearChart() {
        select(`#${this.chartId}` + ' svg').remove();
    }
    /**
     * @param {?} dataSet
     * @return {?}
     */
    getMinMaxValueAndCount(dataSet) {
        // this.max = d3.max(dataSet[0].data);
        // this.min = d3.min(dataSet[0].data);
        this.maxCount = 0;
        /** @type {?} */
        let skip = false;
        dataSet.forEach((/**
         * @param {?} element
         * @return {?}
         */
        element => {
            /** @type {?} */
            let temp_max;
            /** @type {?} */
            let temp_min;
            if (element.offset) {
                if (element.offset.length !== element.data.length) {
                    console.log('Offset and the Data length must be equal.');
                    this.error = true;
                    skip = true;
                    return;
                }
                /** @type {?} */
                const sum$$1 = element.data.map((/**
                 * @param {?} d
                 * @param {?} i
                 * @return {?}
                 */
                (d, i) => d + element.offset[i]));
                temp_max = max(sum$$1);
                temp_min = min(sum$$1);
            }
            else {
                temp_max = max(element.data);
                temp_min = min(element.data);
            }
            if (element.yAxisSecondary) {
                if (this.secondaryMax === undefined) {
                    this.secondaryMax = temp_max;
                }
                if (this.secondaryMin === undefined) {
                    this.secondaryMin = temp_min;
                }
                if (this.secondaryMax < temp_max) {
                    this.secondaryMax = temp_max;
                }
                if (this.secondaryMin > temp_min) {
                    this.secondaryMin = temp_min;
                }
            }
            else {
                if (this.max === undefined) {
                    this.max = temp_max;
                }
                if (this.min === undefined) {
                    this.min = temp_min;
                }
                if (this.max < temp_max) {
                    this.max = temp_max;
                }
                if (this.min > temp_min) {
                    this.min = temp_min;
                }
            }
            // get the maximum count of dataSet data
            /** @type {?} */
            const temp_maxCount = element.data.length;
            if (this.maxCount < temp_maxCount) {
                this.maxCount = temp_maxCount;
            }
        }));
        if (!skip) {
            if (this.max !== undefined && this.min !== undefined) {
                this.max = (this.max < 0) ? 0 : this.max;
                this.min = (this.min > 0) ? 0 : this.min;
                this.max = this.calculateCeil(this.max);
                this.min = this.calculateCeil(this.min);
                /** @type {?} */
                const minMax = this.calculateScaleMinMax(this.min, this.max);
                this.min = minMax.min;
                this.max = minMax.max;
                this.tickList = minMax.tickList;
            }
            if (this.secondaryMax !== undefined && this.secondaryMin !== undefined) {
                this.secondaryMax = (this.secondaryMax < 0) ? 0 : this.secondaryMax;
                this.secondaryMin = (this.secondaryMin > 0) ? 0 : this.secondaryMin;
                this.secondaryMax = this.calculateCeil(this.secondaryMax);
                this.secondaryMin = this.calculateCeil(this.secondaryMin);
                /** @type {?} */
                const minMax = this.calculateScaleMinMax(this.secondaryMin, this.secondaryMax);
                this.secondaryMin = minMax.min;
                this.secondaryMax = minMax.max;
                this.tickListSecondary = minMax.tickList;
            }
            // console.log(this.max, this.min, this.secondaryMax, this.secondaryMin);
        }
    }
    /**
     * @param {?} min
     * @param {?} max
     * @return {?}
     */
    calculateScaleMinMax(min$$1, max$$1) {
        if (min$$1 < 0) {
            /** @type {?} */
            let range = (-1 * min$$1) + max$$1;
            /** @type {?} */
            let rangeNeg = -1 * min$$1;
            /** @type {?} */
            let rangePos = max$$1;
            /** @type {?} */
            let perMin = (rangeNeg * 100) / range;
            if (perMin < 100 / this.noOfYAxisTick) {
                perMin = 100 / this.noOfYAxisTick;
                /** @type {?} */
                const perMax = 100 - perMin;
                range = (rangePos * 100) / perMax;
                rangeNeg = range - rangePos;
            }
            else {
                perMin = perMin - (perMin % (100 / this.noOfYAxisTick));
                range = (rangeNeg * 100) / perMin;
                rangePos = range - rangeNeg;
            }
            rangeNeg = -1 * rangeNeg;
            /** @type {?} */
            const steps = range / this.noOfYAxisTick;
            /** @type {?} */
            const tickList = [];
            /** @type {?} */
            let i = 0;
            while (i < this.noOfYAxisTick + 1) {
                tickList.push(rangeNeg + (i * steps));
                i++;
            }
            /** @type {?} */
            const minMax = {
                min: rangeNeg,
                max: rangePos,
                tickList: tickList
            };
            return minMax;
        }
        else {
            /** @type {?} */
            const steps = max$$1 / this.noOfYAxisTick;
            /** @type {?} */
            const tickList = [];
            /** @type {?} */
            let i = 0;
            while (i < this.noOfYAxisTick + 1) {
                tickList.push(i * steps);
                i++;
            }
            /** @type {?} */
            const minMax = {
                min: 0,
                max: max$$1,
                tickList: tickList
            };
            return minMax;
        }
    }
    /**
     * @param {?} value
     * @return {?}
     */
    calculateCeil(value) {
        if (value % 20 !== 0) {
            return value = (value > 0) ? value + (20 - value % 20) : -1 * (Math.abs(value) + (20 - (Math.abs(value) % 20)));
        }
        else {
            return value;
        }
    }
    // set users provided margin
    /**
     * @param {?} margin
     * @return {?}
     */
    setMargin(margin) {
        this.margin = margin;
    }
    // set side margin
    /**
     * @param {?} max
     * @param {?} min
     * @param {?} side
     * @return {?}
     */
    setSideMargin(max$$1, min$$1, side) {
        if (Math.max(max$$1.toString().length, min$$1.toString().length) < 5) {
            this.margin[side] = 65;
        }
        else {
            this.margin[side] = 75;
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    setHeight(data) {
        this.height = this.height - this.margin.top - this.margin.bottom - this.bufferMargin;
        if (data.yAxisSecondary) {
            this.width = this.width - this.margin.left - this.margin.right - 50;
        }
        else {
            this.width = this.width - this.margin.left;
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    drawChart(data) {
        /** @type {?} */
        const chartWrapper = this.selectIdAndApppendSVG();
        this.setHeight(data);
        /** @type {?} */
        const width = this.width;
        /** @type {?} */
        const height = this.height;
        /** @type {?} */
        const chart = this.GroupWrapperAndTranslate(chartWrapper, data);
        this.addToolTip();
        chartWrapper.call(this.tip);
        // scale spacing for group
        /** @type {?} */
        const xScaleGroup = this.createGroupXAxis(data);
        // The scale spacing for spacing inside group
        /** @type {?} */
        const xScaleIndividual = this.createIndividualXScale();
        /** @type {?} */
        let yScale;
        /** @type {?} */
        let yScaleSecondary;
        if (this.max !== undefined && this.min !== undefined) {
            // Y left Axis scale
            yScale = this.createYScale();
        }
        if (this.secondaryMax !== undefined && this.secondaryMin !== undefined) {
            // Y right Axis scale
            yScaleSecondary = this.createYScaleSecondary();
        }
        // vertical grid lines
        // const makeXLines = this.forVerticalGridLines(xScaleGroup)
        // for horizontal grid lines
        /** @type {?} */
        const makeYLines = this.forHorizontalGridLines(yScale);
        this.xScaleIndividualSetDomainAndRange(xScaleIndividual, xScaleGroup);
        this.drawXBottomAxis(chart, xScaleGroup);
        this.removeXAxisLine(); // remove x axis ticks
        if (this.min !== undefined && this.max !== undefined) {
            this.drawYLeftAxis(chart, yScale, data); // draw the y axis on the left
        }
        if (this.secondaryMin !== undefined && this.secondaryMax !== undefined) {
            this.drawYRightAxis(chart, yScaleSecondary, data); // draw the y axis on the left
        }
        this.removeYAxisLine(); // removes y axis line and ticks
        // vertical grid lines from X Axis
        // this.drawVerticalGridLines(chart, makeXLines);
        // horizontal grid lines from Y Axis
        this.drawHorizontalGridLines(chart, makeYLines);
        // colors for the legends
        /** @type {?} */
        const colors = this.colorsForLegends(data);
        // add Y left axis title
        if (data.yAxis && data.yAxis.text) {
            this.addYLeftAxisTitle(chartWrapper, height, data);
        }
        // add Y right axis title
        if (data.yAxisSecondary && data.yAxisSecondary.text) {
            this.addYRightAxisTitle(chartWrapper, height, width, data);
        }
        // add X axis title
        if (data.xAxis && data.xAxis.text) {
            this.addXAxisTitle(chartWrapper, width, height, data);
        }
        // add main title at the top
        if (data.title && data.title.text) {
            this.addMainTitle(chartWrapper, width, data);
        }
        // add source if needed we can activate this feature
        // this.addSourceInformation(chartWrapper, width, height);
        // groups of vertical bars
        if (this.secondaryMax === undefined && this.secondaryMin === undefined) {
            this.draw(chart, data, xScaleGroup, xScaleIndividual, yScale);
        }
        else {
            this.draw(chart, data, xScaleGroup, xScaleIndividual, yScale, yScaleSecondary);
        }
        /** @type {?} */
        let filteredContent = [];
        /** @type {?} */
        const keys = this.getKeysAndTypeMap();
        if ((!data.options) || (!data.options.legend) || (data.options.legend.show)) {
            // create legend and updating the chart once the data is filtered from legends
            /** @type {?} */
            const legend = this.createLegend(data, chartWrapper, width, colors, data.options.legend, (/**
             * @param {?} d
             * @return {?}
             */
            (d) => {
                filteredContent = this.updateSVG(filteredContent, d, keys, xScaleIndividual, xScaleGroup, this.convertedData, yScale, yScaleSecondary, chartWrapper, width, data, height, legend, colors);
            }));
        }
    }
    /**
     * @param {?} data
     * @return {?}
     */
    colorsForLegends(data) {
        return scaleOrdinal()
            .range(data.dataSet.map((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.color[0];
        })).reverse());
    }
    /**
     * @param {?} chart
     * @param {?} makeYLines
     * @return {?}
     */
    drawHorizontalGridLines(chart, makeYLines) {
        chart.append('g')
            .attr('class', 'grid')
            .call(makeYLines()
            .tickSize(-this.width, 0, 0)
            .tickFormat(''));
    }
    /**
     * @param {?} chart
     * @param {?} makeXLines
     * @return {?}
     */
    drawVerticalGridLines(chart, makeXLines) {
        chart.append('g')
            .attr('class', 'grid')
            .attr('transform', `translate(0, ${this.height})`)
            .call(makeXLines()
            .tickSize(-this.height, 0, 0)
            .tickFormat(''));
    }
    /**
     * @return {?}
     */
    removeYAxisLine() {
        selectAll('.y-axis-path-tick g line').remove(); // removes y axis ticks
        selectAll('.y-axis-path-tick path').remove(); // removes y axis path
    }
    /**
     * @return {?}
     */
    removeXAxisLine() {
        selectAll('.x-axis-path g line').remove(); // removes x axis path
    }
    /**
     * @param {?} chart
     * @param {?} yScale
     * @param {?} data
     * @return {?}
     */
    drawYLeftAxis(chart, yScale, data) {
        /** @type {?} */
        let ticksConfig;
        ticksConfig = this.getTickConfig(ticksConfig, yScale, this.tickList, 'left');
        chart.append('g')
            .attr('class', 'y-axis-path-tick y-axis-left')
            .call(ticksConfig.tickFormat((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (data.yAxis && data.yAxis.symbol && data.yAxis.symbolPosition) {
                if (data.yAxis.symbolPosition === 'before') {
                    return data.yAxis.symbol + format('.2s')(d);
                }
                else if (data.yAxis.symbolPosition === 'after') {
                    return format('.2s')(d) + data.yAxis.symbol;
                }
            }
            else {
                return format('.2s')(d);
            }
        })));
    }
    /**
     * @param {?} chart
     * @param {?} yScaleSecondary
     * @param {?} data
     * @return {?}
     */
    drawYRightAxis(chart, yScaleSecondary, data) {
        /** @type {?} */
        let ticksConfig;
        ticksConfig = this.getTickConfig(ticksConfig, yScaleSecondary, this.tickListSecondary, 'right');
        chart.append('g')
            .attr('class', 'y-axis-path-tick y-axis-right')
            .attr('transform', `translate(${this.width + 5}, 0)`)
            .call(ticksConfig.tickFormat((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (data.yAxisSecondary && data.yAxisSecondary.symbol && data.yAxisSecondary.symbolPosition) {
                if (data.yAxisSecondary.symbolPosition === 'before') {
                    return data.yAxisSecondary.symbol + format('.2s')(d);
                }
                else if (data.yAxisSecondary.symbolPosition === 'after') {
                    return format('.2s')(d) + data.yAxisSecondary.symbol;
                }
            }
            else {
                return format('.2s')(d);
            }
        })));
    }
    /**
     * @param {?} ticksConfig
     * @param {?} yScale
     * @param {?} tickList
     * @param {?} axisPosition
     * @return {?}
     */
    getTickConfig(ticksConfig, yScale, tickList, axisPosition) {
        if (axisPosition === 'right') {
            if (tickList.length !== 0) {
                ticksConfig = axisRight(yScale).tickValues(tickList);
            }
            else {
                ticksConfig = axisRight(yScale).ticks(this.noOfYAxisTick);
            }
        }
        else {
            if (tickList.length !== 0) {
                ticksConfig = axisLeft(yScale).tickValues(tickList);
            }
            else {
                ticksConfig = axisLeft(yScale).ticks(this.noOfYAxisTick);
            }
        }
        return ticksConfig;
    }
    /**
     * @param {?} chart
     * @param {?} xScaleGroup
     * @return {?}
     */
    drawXBottomAxis(chart, xScaleGroup) {
        chart.append('g')
            .attr('class', 'x-axis-path')
            .attr('transform', `translate(0, ${this.height})`)
            .call(axisBottom(xScaleGroup).tickSizeOuter(0));
    }
    /**
     * @param {?} xScaleIndividual
     * @param {?} xScaleGroup
     * @return {?}
     */
    xScaleIndividualSetDomainAndRange(xScaleIndividual, xScaleGroup) {
        xScaleIndividual.domain(this.getKeysOfBarType())
            .rangeRound([0, xScaleGroup.bandwidth()]);
    }
    /**
     * @param {?} xScaleGroup
     * @return {?}
     */
    forVerticalGridLines(xScaleGroup) {
        return (/**
         * @return {?}
         */
        () => axisBottom(xScaleGroup)
            .scale(xScaleGroup));
    }
    /**
     * @param {?} yScale
     * @return {?}
     */
    forHorizontalGridLines(yScale) {
        if (this.tickList.length !== 0) {
            return (/**
             * @return {?}
             */
            () => axisLeft(yScale)
                .tickValues(this.tickList)
                .scale(yScale));
        }
        else {
            return (/**
             * @return {?}
             */
            () => axisLeft(yScale)
                .ticks(this.noOfYAxisTick)
                .scale(yScale));
        }
    }
    /**
     * @return {?}
     */
    createYScale() {
        return scaleLinear()
            .range([this.height, 0])
            .domain([this.min, this.max]);
        // .interpolate(d3.interpolateNumber)
        // .nice();
    }
    /**
     * @return {?}
     */
    createYScaleSecondary() {
        return scaleLinear()
            .range([this.height, 0])
            .domain([this.secondaryMin, this.secondaryMax]);
        // .interpolate(d3.interpolateNumber)
        // .nice();
    }
    /**
     * @return {?}
     */
    createIndividualXScale() {
        return scaleBand()
            .padding(this.innerPadding);
    }
    /**
     * @param {?} chartWrapper
     * @param {?} data
     * @return {?}
     */
    GroupWrapperAndTranslate(chartWrapper, data) {
        if (data.title || (data.options.legend && data.options.legend.show) || !data.options.legend) {
            return chartWrapper.append('g')
                .attr('transform', `translate(${this.margin.left}, ${this.margin.top + this.bufferMargin})`)
                .append('g');
        }
        else {
            return chartWrapper.append('g')
                .attr('transform', `translate(${this.margin.left}, ${this.margin.top})`)
                .append('g');
        }
    }
    /**
     * @return {?}
     */
    selectIdAndApppendSVG() {
        return select(`#${this.chartId}`)
            .append('svg').style('width', this.width).style('height', this.height);
    }
    /**
     * @param {?} data
     * @return {?}
     */
    createGroupXAxis(data) {
        return scaleBand()
            .rangeRound([0, this.width])
            .domain(data.xAxis.category)
            .padding(this.padding);
    }
    // for creating the legends
    /**
     * @param {?} data
     * @param {?} chartWrapper
     * @param {?} width
     * @param {?} colors
     * @param {?} legendObj
     * @param {?} updateChart
     * @return {?}
     */
    createLegend(data, chartWrapper, width, colors, legendObj, updateChart) {
        /** @type {?} */
        const legend = chartWrapper.append('g')
            .attr('class', 'legends')
            .attr('transform', (/**
         * @return {?}
         */
        () => {
            if (data.yAxisSecondary) {
                return 'translate(' + (width + this.bufferMargin) + ', ' + (this.margin.top + 15) + ')';
            }
            else {
                return 'translate(' + (width - this.margin.right) + ', ' + (this.margin.top + 15) + ')';
            }
        }))
            .selectAll('g')
            .data(this.getKeys())
            .enter().append('g')
            .attr('transform', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return 'translate(' + (-(i * 100) - width + this.margin.right) + ',' + -this.margin.top / 2 + ')';
        }));
        legend.append('circle')
            .attr('cx', width - 17)
            .attr('r', 7.5)
            // .attr('height', 15)
            .attr('fill', colors)
            .attr('stroke', colors)
            .attr('stroke-width', 2)
            .on('click', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if ((legendObj === undefined) || (legendObj.interactive === undefined) || (legendObj.interactive)) {
                return updateChart(d);
            }
        }));
        legend.append('text')
            .attr('x', width + 41)
            .attr('y', 5)
            // .attr('dy', '0.32em')
            .text((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d;
        }));
        return legend;
    }
    // update the svg chart
    /**
     * @param {?} filteredContent
     * @param {?} d
     * @param {?} keys
     * @param {?} xScaleIndividual
     * @param {?} xScaleGroup
     * @param {?} convertedData
     * @param {?} yScale
     * @param {?} yScaleSecondary
     * @param {?} chart
     * @param {?} width
     * @param {?} data
     * @param {?} height
     * @param {?} legend
     * @param {?} colors
     * @return {?}
     */
    updateSVG(filteredContent, d, keys, xScaleIndividual, xScaleGroup, convertedData, yScale, yScaleSecondary, chart, width, data, height, legend, colors) {
        //
        // Update the array to filter the chart by:
        //
        // add the clicked key if not included:
        /** @type {?} */
        let minMaxSecondary;
        /** @type {?} */
        let minMax;
        if (filteredContent.indexOf(d) === -1) {
            filteredContent.push(d);
            // if all bars are un-checked, reset:
            if (filteredContent.length === keys.length) {
                filteredContent = [];
            }
        }
        else { // otherwise remove it:
            filteredContent.splice(filteredContent.indexOf(d), 1);
        }
        //
        // Update the scales for each group(/states)'s items:
        //
        /** @type {?} */
        const newKeys = [];
        keys.forEach((/**
         * @param {?} key
         * @return {?}
         */
        (key) => {
            if (filteredContent.indexOf(key.value.name) === -1) {
                if (!key.value.type || key.value.type === 'bar') {
                    newKeys.push(key.value.name);
                }
            }
        }));
        xScaleIndividual.domain(newKeys).rangeRound([0, xScaleGroup.bandwidth()]);
        /** @type {?} */
        let min$$1 = min(convertedData, (/**
         * @param {?} cData
         * @return {?}
         */
        (cData) => {
            return min(keys, (/**
             * @param {?} key
             * @return {?}
             */
            (key) => {
                if (filteredContent.indexOf(key.value.name) === -1) {
                    if (!cData.yAxisSecondary[cData.name.indexOf(key.value.name)]) {
                        return cData.value[cData.name.indexOf(key.value.name)] + cData.offset[cData.name.indexOf(key.value.name)];
                    }
                }
            }));
        }));
        if (min$$1 !== undefined) {
            min$$1 = (min$$1 > 0) ? 0 : min$$1;
            min$$1 = this.calculateCeil(min$$1);
        }
        /** @type {?} */
        let max$$1 = max(convertedData, (/**
         * @param {?} cData
         * @return {?}
         */
        (cData) => {
            return max(keys, (/**
             * @param {?} key
             * @return {?}
             */
            (key) => {
                if (filteredContent.indexOf(key.value.name) === -1) {
                    if (!cData.yAxisSecondary[cData.name.indexOf(key.value.name)]) {
                        return cData.value[cData.name.indexOf(key.value.name)] + cData.offset[cData.name.indexOf(key.value.name)];
                    }
                }
            }));
        }));
        if (max$$1 !== undefined) {
            max$$1 = (max$$1 < 0) ? 0 : max$$1;
            max$$1 = this.calculateCeil(max$$1);
        }
        if (max$$1 === undefined && min$$1 === undefined) {
            chart.select('.y-axis-left')
                .style('opacity', 0)
                .transition()
                .duration(500);
            select(`#${this.chartId + '-y-left-label'}`)
                .style('opacity', 0)
                .transition()
                .duration(500);
        }
        else {
            minMax = this.calculateScaleMinMax(min$$1, max$$1);
            min$$1 = minMax.min;
            max$$1 = minMax.max;
            chart.select('.y-axis-left')
                .style('opacity', 1)
                .transition()
                .duration(500);
            select(`#${this.chartId + '-y-left-label'}`)
                .style('opacity', 1)
                .transition()
                .duration(500);
            yScale.domain([min$$1, max$$1]);
            // .interpolate(d3.interpolateNumber)
            // .nice();
            /** @type {?} */
            let ticksConfig;
            ticksConfig = this.getTickConfig(ticksConfig, yScale, minMax.tickList, 'left');
            // update the y left axis:
            chart.select('.y-axis-left')
                .transition()
                .call(ticksConfig.tickFormat((/**
             * @param {?} text
             * @return {?}
             */
            (text) => {
                if (data.yAxis && data.yAxis.symbol && data.yAxis.symbolPosition) {
                    if (data.yAxis.symbolPosition === 'before') {
                        return data.yAxis.symbol + format('.2s')(text);
                    }
                    else if (data.yAxis.symbolPosition === 'after') {
                        return format('.2s')(text) + data.yAxis.symbol;
                    }
                }
                else {
                    return format('.2s')(text);
                }
            })))
                .duration(500);
        }
        if (data && data.yAxisSecondary) {
            /** @type {?} */
            let secondaryMax = max(convertedData, (/**
             * @param {?} cData
             * @return {?}
             */
            (cData) => {
                return max(keys, (/**
                 * @param {?} key
                 * @return {?}
                 */
                (key) => {
                    if (filteredContent.indexOf(key.value.name) === -1) {
                        if (cData.yAxisSecondary[cData.name.indexOf(key.value.name)]) {
                            return cData.value[cData.name.indexOf(key.value.name)] + cData.offset[cData.name.indexOf(key.value.name)];
                        }
                    }
                }));
            }));
            if (secondaryMax !== undefined) {
                secondaryMax = (secondaryMax < 0) ? 0 : secondaryMax;
                secondaryMax = this.calculateCeil(secondaryMax);
            }
            /** @type {?} */
            let secondaryMin = min(convertedData, (/**
             * @param {?} cData
             * @return {?}
             */
            (cData) => {
                return min(keys, (/**
                 * @param {?} key
                 * @return {?}
                 */
                (key) => {
                    if (filteredContent.indexOf(key.value.name) === -1) {
                        if (cData.yAxisSecondary[cData.name.indexOf(key.value.name)]) {
                            return cData.value[cData.name.indexOf(key.value.name)] + cData.offset[cData.name.indexOf(key.value.name)];
                        }
                    }
                }));
            }));
            if (secondaryMin !== undefined) {
                secondaryMin = (secondaryMin > 0) ? 0 : secondaryMin;
                secondaryMin = this.calculateCeil(secondaryMin);
            }
            if (secondaryMax === undefined && secondaryMin === undefined) {
                chart.select('.y-axis-right')
                    .style('opacity', 0)
                    .transition()
                    .duration(500);
                select(`#${this.chartId + '-y-right-label'}`)
                    .style('opacity', 0)
                    .transition()
                    .duration(500);
            }
            else {
                minMaxSecondary = this.calculateScaleMinMax(secondaryMin, secondaryMax);
                secondaryMin = minMaxSecondary.min;
                secondaryMax = minMaxSecondary.max;
                chart.select('.y-axis-right')
                    .style('opacity', 1)
                    .transition()
                    .duration(500);
                select(`#${this.chartId + '-y-right-label'}`)
                    .style('opacity', 1)
                    .transition()
                    .duration(500);
                yScaleSecondary.domain([secondaryMin, secondaryMax]);
                // .interpolate(d3.interpolateNumber);
                // .nice();
                if (data && data.yAxisSecondary) {
                    /** @type {?} */
                    let ticksConfig;
                    ticksConfig = this.getTickConfig(ticksConfig, yScaleSecondary, minMaxSecondary.tickList, 'right');
                    // update the y right axis:
                    chart.select('.y-axis-right')
                        .transition()
                        .call(ticksConfig.tickFormat((/**
                     * @param {?} text
                     * @return {?}
                     */
                    (text) => {
                        if (data.yAxisSecondary && data.yAxisSecondary.symbol && data.yAxisSecondary.symbolPosition) {
                            if (data.yAxisSecondary.symbolPosition === 'before') {
                                return data.yAxisSecondary.symbol + format('.2s')(text);
                            }
                            else if (data.yAxisSecondary.symbolPosition === 'after') {
                                return format('.2s')(text) + data.yAxisSecondary.symbol;
                            }
                        }
                        else {
                            return format('.2s')(text);
                        }
                    })))
                        .duration(500);
                }
            }
            // console.log(min, max, secondaryMin, secondaryMax);
        }
        // if (minMax.tickList) {
        //   // update the horizontal lines
        //   const makeUpdatedYLines = () => d3.axisLeft(yScale)
        //     .tickValues(minMax.tickList)
        //     .scale(yScale);
        //   //  chart.selectAll('.grid')
        //   //       .remove();
        //   // update horizontal grid lines from Y Axis
        //   chart.selectAll('.grid')
        //     .transition()
        //     .call(makeUpdatedYLines()
        //       .tickSize(-width, 0, 0)
        //       .tickFormat(''))
        //     .duration(500);
        // }
        this.removeYAxisLine();
        // updates the bar
        this.barUpdate(chart, filteredContent, height, xScaleIndividual, yScale, yScaleSecondary);
        // update the line
        this.lineUpdate(chart, filteredContent, height, xScaleIndividual, yScale, yScaleSecondary, xScaleGroup, d);
        // update legend:
        legend.selectAll('circle')
            .transition()
            .attr('fill', (/**
         * @param {?} color
         * @return {?}
         */
        (color) => {
            if (filteredContent.length) {
                if (filteredContent.indexOf(color) === -1) {
                    return colors(color);
                }
                else {
                    return '#FFFFFF';
                }
            }
            else {
                return colors(color);
            }
        }))
            .duration(100);
        return filteredContent;
    }
    /**
     * @param {?} chart
     * @param {?} filteredContent
     * @param {?} height
     * @param {?} xScaleIndividual
     * @param {?} yScale
     * @param {?} yScaleSecondary
     * @return {?}
     */
    barUpdate(chart, filteredContent, height, xScaleIndividual, yScale, yScaleSecondary) {
        //
        // Filter out the bands that need to be hidden:
        //
        /** @type {?} */
        const bars = chart.selectAll('.bar').selectAll('path')
            .data((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.name.map((/**
             * @param {?} key
             * @param {?} i
             * @return {?}
             */
            (key, i) => {
                return { key: i, value: {
                        value: d.value[i], color: d.color[i], name: d.name[i],
                        yAxisSecondary: d.yAxisSecondary[i], offset: d.offset[i], category: d.category
                    }
                };
            }));
        }));
        bars.filter((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return filteredContent.indexOf(d.value.name) > -1;
        }))
            .transition()
            .attr('d', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => {
            if (g.value.value >= 0) {
                return this.roundedRect((xScaleIndividual.bandwidth() / 2), height, 0, 0, 0, this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
            }
            else {
                return this.roundedRect((xScaleIndividual.bandwidth() / 2), height, 0, 0, 0, 0, 0, this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
            }
        }))
            // .attr('x', function (d) {
            //   return (+d3.select(this).attr('x')) + (+d3.select(this).attr('width')) / 2;
            // })
            // .attr('height', 0)
            // .attr('width', 0)
            // .attr('y', (d) => {
            //   return height;
            // })
            .duration(500);
        //
        // Adjust the remaining bars:
        //
        bars.filter((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return filteredContent.indexOf(d.value.name) === -1;
        }))
            .transition()
            .attr('d', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (d.value.yAxisSecondary) {
                if (d.value.value >= 0) {
                    return this.roundedRect(xScaleIndividual(d.value.name), yScaleSecondary(d.value.value + d.value.offset), xScaleIndividual.bandwidth(), Math.abs(yScaleSecondary(d.value.value) - yScaleSecondary(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))));
                }
                else {
                    return this.roundedRect(xScaleIndividual(d.value.name), yScaleSecondary(Math.max(d.value.offset, d.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScaleSecondary(d.value.value) - yScaleSecondary(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))), 0, 0, this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))));
                }
            }
            else {
                if (d.value.value >= 0) {
                    return this.roundedRect(xScaleIndividual(d.value.name), yScale(d.value.value + d.value.offset), xScaleIndividual.bandwidth(), Math.abs(yScale(d.value.value) - yScale(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))));
                }
                else {
                    return this.roundedRect(xScaleIndividual(d.value.name), yScale(Math.max(d.value.offset, d.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScale(d.value.value) - yScale(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))), 0, 0, this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(d.value.value) - yScale(0))));
                }
            }
        }))
            // .attr('x', function (d) { return xScaleIndividual(d.value.name); })
            // .attr('y', function (d) {
            //   if (d.value.yAxisSecondary) {
            //     if (d.value.value >= 0) {
            //       return yScaleSecondary(d.value.value + d.value.offset);
            //     } else {
            //       return yScaleSecondary(Math.max(d.value.offset, d.value.value));
            //     }
            //   } else {
            //     if (d.value.value >= 0) {
            //       return yScale(d.value.value + d.value.offset);
            //     } else {
            //       return yScale(Math.max(d.value.offset, d.value.value));
            //     }
            //   }
            // })
            // .attr('height', (d) => {
            //   if (d.value.yAxisSecondary) {
            //     return Math.abs(yScaleSecondary(d.value.value) - yScaleSecondary(0));
            //   } else {
            //     return Math.abs(yScale(d.value.value) - yScale(0));
            //   }
            // })
            // .attr('width', xScaleIndividual.bandwidth())
            .attr('fill', (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return d.value.color; }))
            .duration(500);
    }
    /**
     * @param {?} chart
     * @param {?} filteredContent
     * @param {?} height
     * @param {?} xScaleIndividual
     * @param {?} yScale
     * @param {?} yScaleSecondary
     * @param {?} xScaleGroup
     * @param {?} selectedLegend
     * @return {?}
     */
    lineUpdate(chart, filteredContent, height, xScaleIndividual, yScale, yScaleSecondary, xScaleGroup, selectedLegend) {
        //
        // Filter out the lines that need to be hidden:
        //
        if (filteredContent.length === 0) {
            /** @type {?} */
            const classToShow = '.'.concat(this.chartId).concat('-line');
            selectAll(classToShow)
                .transition()
                .duration(500)
                .style('opacity', 1);
        }
        else {
            /** @type {?} */
            let selectedLegendId = this.chartId + selectedLegend;
            if (document.getElementById(selectedLegendId)) {
                selectedLegendId = '#'.concat(selectedLegendId);
                /** @type {?} */
                const opacity = +select(selectedLegendId).style('opacity') === 1 ? 0 : 1;
                select(selectedLegendId)
                    .transition()
                    .duration(500)
                    .style('opacity', opacity);
            }
        }
        // scale the lines according to the updated scale
        /** @type {?} */
        const lineData = [];
        /** @type {?} */
        const circles = chart.selectAll('.line').selectAll('circle')
            .data((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            lineData.push(d);
            return d.map((/**
             * @param {?} g
             * @param {?} i
             * @return {?}
             */
            (g, i) => {
                return {
                    key: i, value: { value: g.value, color: g.color, name: g.name, category: g.category, yAxisSecondary: g.yAxisSecondary }
                };
            }));
        }));
        circles.filter((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d;
        }))
            .transition()
            .attr('cy', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            if (d.value.yAxisSecondary) {
                return yScaleSecondary(d.value.value);
            }
            else {
                return yScale(d.value.value);
            }
        }))
            .duration(500);
        /** @type {?} */
        const lineSelection = line()
            .x((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return xScaleGroup(d.category);
        }))
            .y((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (d.yAxisSecondary) {
                return yScaleSecondary(d.value);
            }
            else {
                return yScale(d.value);
            }
        }));
        /** @type {?} */
        const lineSelectionCurve = line()
            .x((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return xScaleGroup(d.category);
        }))
            .y((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (d.yAxisSecondary) {
                return yScaleSecondary(d.value);
            }
            else {
                return yScale(d.value);
            }
        }))
            .curve(curveCardinal);
        /** @type {?} */
        const lines = chart.selectAll('.line')
            .data(lineData);
        lines
            .selectAll('path')
            .transition()
            .attr('d', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (d[0].lineDetails !== null && d[0].lineDetails.curve) {
                return lineSelectionCurve(d);
            }
            else {
                return lineSelection(d);
            }
        }))
            .duration(500);
    }
    // adds main title to the graph
    /**
     * @param {?} chartWrapper
     * @param {?} width
     * @param {?} data
     * @return {?}
     */
    addMainTitle(chartWrapper, width, data) {
        chartWrapper.append('text')
            .attr('class', 'title')
            .attr('x', this.margin.left - this.bufferMargin)
            .attr('y', this.bufferMargin)
            .attr('text-anchor', 'start')
            .text(data.title.text);
    }
    // adds X axis title
    /**
     * @param {?} chartWrapper
     * @param {?} width
     * @param {?} height
     * @param {?} data
     * @return {?}
     */
    addXAxisTitle(chartWrapper, width, height, data) {
        chartWrapper.append('text')
            .attr('class', 'label x-label')
            .attr('x', width / 2 + this.margin.left)
            .attr('y', height + this.margin.top + this.margin.bottom + this.bufferMargin)
            .attr('text-anchor', 'middle')
            .text(data.xAxis.text);
    }
    // adds Y left axis title
    /**
     * @param {?} chartWrapper
     * @param {?} height
     * @param {?} data
     * @return {?}
     */
    addYLeftAxisTitle(chartWrapper, height, data) {
        chartWrapper
            .append('text')
            .attr('id', `${this.chartId + '-y-left-label'}`)
            .attr('class', 'label')
            .attr('x', (/**
         * @return {?}
         */
        () => {
            if (data.title || (data.options.legend && data.options.legend.show) || !data.options.legend) {
                if (data.yAxisSecondary) {
                    return -(height / 2) - this.margin.top - this.bufferMargin;
                }
                else {
                    return -(height / 2) - this.margin.top;
                }
            }
            else {
                return -(height / 2) - this.margin.top;
            }
        }))
            .attr('y', 10)
            .attr('transform', 'rotate(-90)')
            .attr('text-anchor', 'middle')
            .text(data.yAxis.text);
    }
    // adds Y right axis title
    /**
     * @param {?} chartWrapper
     * @param {?} height
     * @param {?} width
     * @param {?} data
     * @return {?}
     */
    addYRightAxisTitle(chartWrapper, height, width, data) {
        chartWrapper
            .append('text')
            .attr('id', `${this.chartId + '-y-right-label'}`)
            .attr('class', 'label y-right-label')
            .attr('x', (/**
         * @return {?}
         */
        () => {
            if (data.title || (data.options.legend && data.options.legend.show) || !data.options.legend) {
                return -(height / 2) - this.margin.bottom - this.bufferMargin;
            }
            else {
                return -(height / 2) - this.margin.bottom;
            }
        }))
            .attr('y', (this.margin.right + this.margin.left + width + 10))
            .attr('transform', 'rotate(-90)')
            .attr('text-anchor', 'middle')
            .text(data.yAxisSecondary.text);
    }
    // convert the data into array of objects based on group
    /**
     * @param {?} data
     * @param {?} convertedData
     * @param {?=} type
     * @return {?}
     */
    convertDataInGroup(data, convertedData, type) {
        for (let i = 0; i < this.maxCount; i++) {
            /** @type {?} */
            const temp = {};
            temp.value = [];
            temp.color = [];
            temp.name = [];
            temp.category = data.xAxis.category[i];
            temp.yAxisSecondary = [];
            temp.offset = [];
            temp.lineDetails = [];
            if (type) {
                for (let j = 0; j < data.dataSet.length; j++) {
                    if (data.dataSet[j].type === type) {
                        if (data.dataSet[j].lineDetails) {
                            temp.lineDetails.push(data.dataSet[j].lineDetails);
                        }
                        else {
                            temp.lineDetails.push(null);
                        }
                        if (data.dataSet[j].yAxisSecondary === undefined) {
                            temp.yAxisSecondary.push(false);
                        }
                        else {
                            temp.yAxisSecondary.push(data.dataSet[j].yAxisSecondary);
                        }
                        if (data.dataSet[j].offset && data.dataSet[j].offset[i]) {
                            temp.offset.push(data.dataSet[j].offset[i]);
                        }
                        else {
                            temp.offset.push(0);
                        }
                        temp.value.push(data.dataSet[j].data[i]);
                        temp.name.push(data.dataSet[j].name);
                        if (data.dataSet[j].color) {
                            temp.color.push(data.dataSet[j].color[i % data.dataSet[j].color.length]);
                        }
                        else {
                            temp.color.push('grey');
                        }
                    }
                }
            }
            else {
                for (let j = 0; j < data.dataSet.length; j++) {
                    if (data.dataSet[j].yAxisSecondary === undefined) {
                        temp.yAxisSecondary.push(false);
                    }
                    else {
                        temp.yAxisSecondary.push(data.dataSet[j].yAxisSecondary);
                    }
                    if (data.dataSet[j].offset && data.dataSet[j].offset[i]) {
                        temp.offset.push(data.dataSet[j].offset[i]);
                    }
                    else {
                        temp.offset.push(0);
                    }
                    temp.value.push(data.dataSet[j].data[i]);
                    temp.name.push(data.dataSet[j].name);
                    if (data.dataSet[j].color) {
                        temp.color.push(data.dataSet[j].color[i % data.dataSet[j].color.length]);
                    }
                    else {
                        temp.color.push('grey');
                    }
                }
            }
            convertedData.push(temp);
        }
    }
    // get the keys
    /**
     * @return {?}
     */
    getKeys() {
        /** @type {?} */
        const tempKeys = [];
        this.data.dataSet.forEach((/**
         * @param {?} element
         * @return {?}
         */
        element => {
            tempKeys.push(element.name);
        }));
        return tempKeys.reverse();
    }
    // get the keys and type map
    /**
     * @return {?}
     */
    getKeysAndTypeMap() {
        return (this.data.dataSet[0].type) ? this.data.dataSet.map((/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return {
                key: i, value: { name: d.name, type: d.type }
            };
        })) : this.data.dataSet.map((/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return {
                key: i, value: { name: d.name }
            };
        }));
    }
    // get the keys With type
    /**
     * @return {?}
     */
    getKeysOfBarType() {
        /** @type {?} */
        const tempKeys = [];
        this.data.dataSet.forEach((/**
         * @param {?} element
         * @return {?}
         */
        element => {
            if (element.type) {
                if (element.type === 'bar') {
                    tempKeys.push(element.name);
                }
            }
            else {
                tempKeys.push(element.name);
            }
        }));
        return tempKeys;
    }
    /**
     * @return {?}
     */
    getKeysOfLineType() {
        /** @type {?} */
        const tempKeys = [];
        this.data.dataSet.forEach((/**
         * @param {?} element
         * @return {?}
         */
        element => {
            if (element.type) {
                if (element.type === 'line') {
                    tempKeys.push(element.name);
                }
            }
            else {
                tempKeys.push(element.name);
            }
        }));
        return tempKeys;
    }
    //  setColors(data: any, i: number) {
    //   if (data.dataSet[0].color.length == data.dataSet[0].data.length)
    //     return data.dataSet[0].color[i];
    //   else if (data.dataSet[0].color.length == 1)
    //     return data.dataSet[0].color[0];
    //   else
    //     return 'grey';
    // }
    // add d3 tooltip needs to be modified
    /**
     * @return {?}
     */
    addToolTip() {
        this.tip = tip().attr('class', 'd3-tip').html((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return String(tooltipTemplate)
                .replace(/d.xAxis/, d.value.category)
                .replace(/d.color/, d.value.color)
                .replace(/d.legendName/, d.value.name)
                .replace(/d.data/, d.value.value);
            // return d.value.name + ' : ' + d.value.value;
        }));
    }
    /**
     * @param {?} x
     * @param {?} y
     * @param {?} w
     * @param {?} h
     * @param {?} r
     * @param {?=} tl
     * @param {?=} tr
     * @param {?=} bl
     * @param {?=} br
     * @return {?}
     */
    roundedRect(x, y, w, h, r, tl, tr, bl, br) {
        /** @type {?} */
        let retval;
        retval = 'M' + (x + r) + ',' + y;
        retval += 'h' + (w - 2 * r);
        if (tr) {
            retval += 'a' + r + ',' + r + ' 0 0 1 ' + r + ',' + r;
        }
        else {
            retval += 'h' + r;
            retval += 'v' + r;
        }
        retval += 'v' + (h - 2 * r);
        if (br) {
            retval += 'a' + r + ',' + r + ' 0 0 1 ' + -r + ',' + r;
        }
        else {
            retval += 'v' + r;
            retval += 'h' + -r;
        }
        retval += 'h' + (2 * r - w);
        if (bl) {
            retval += 'a' + r + ',' + r + ' 0 0 1 ' + -r + ',' + -r;
        }
        else {
            retval += 'h' + -r;
            retval += 'v' + -r;
        }
        retval += 'v' + (2 * r - h);
        if (tl) {
            retval += 'a' + r + ',' + r + ' 0 0 1 ' + r + ',' + -r;
        }
        else {
            retval += 'v' + -r;
            retval += 'h' + r;
        }
        retval += 'z';
        return retval;
    }
    /**
     * @param {?} xWidth
     * @param {?} yHeight
     * @return {?}
     */
    getRoundCurve(xWidth, yHeight) {
        return (xWidth <= yHeight) ? xWidth : yHeight;
    }
}
CommonChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'ndi-common-chart',
                template: "",
                styles: [""]
            }] }
];
/** @nocollapse */
CommonChartComponent.ctorParameters = () => [];
CommonChartComponent.propDecorators = {
    chartContainer: [{ type: ViewChild, args: ['chartContainer',] }],
    data: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class BarChartComponent extends CommonChartComponent {
    constructor() {
        super();
    }
    /**
     * @param {?} chart
     * @param {?} data
     * @param {?} xScaleGroup
     * @param {?} xScaleIndividual
     * @param {?} yScale
     * @return {?}
     */
    draw(chart, data, xScaleGroup, xScaleIndividual, yScale) {
        this.convertedData = [];
        this.convertDataInGroup(data, this.convertedData);
        return chart.append('g')
            .selectAll('g')
            .data(this.convertedData)
            .enter()
            .append('g')
            .attr('class', 'bar')
            .attr('transform', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return 'translate(' + xScaleGroup(d.category) + ',0)';
        }))
            .selectAll('path')
            .data((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.name.map((/**
             * @param {?} key
             * @param {?} i
             * @return {?}
             */
            (key, i) => {
                if (d.offset.length === 0) {
                    return { key: i, value: { value: d.value[i], color: d.color[i], name: d.name[i], category: d.category } };
                }
                else {
                    return { key: i, value: { value: d.value[i], color: d.color[i], name: d.name[i], offset: d.offset[i], category: d.category } };
                }
            }));
        }))
            .enter()
            .append('path')
            .attr('d', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => {
            if (g.value.value >= 0) {
                return this.roundedRect(xScaleIndividual(g.value.name), yScale(g.value.value + g.value.offset), xScaleIndividual.bandwidth(), Math.abs(yScale(g.value.value) - yScale(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
            }
            else {
                return this.roundedRect(xScaleIndividual(g.value.name), yScale(Math.max(g.value.offset, g.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScale(g.value.value) - yScale(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), 0, 0, this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
            }
        }))
            // .attr('x', (g) => xScaleIndividual(g.value.name))
            // .attr('y', (g) => {
            //     if (g.value.value >= 0) {
            //       return yScale(g.value.value + g.value.offset);
            //     } else {
            //       return yScale(Math.max(g.value.offset, g.value.value));
            //     }
            // })
            // .attr('width', xScaleIndividual.bandwidth())
            // .attr('height', (g) => Math.abs(yScale(g.value.value) - yScale(0)))
            .attr('fill', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => {
            return g.value.color;
        }))
            .on('mouseenter', this.tip.show)
            .on('mouseout', this.tip.hide);
    }
}
BarChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'ndi-bar-chart',
                template: "<div [id]=\"chartId\" #chartContainer class=\"chart-wrapper\"></div>",
                styles: [""]
            }] }
];
/** @nocollapse */
BarChartComponent.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class LineChartComponent {
    constructor() {
        this.margin = { top: 50, right: 50, bottom: 50, left: 50 };
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.createId();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.generateChart(this.data);
    }
    /**
     * @return {?}
     */
    createId() {
        this.chartIdLine = `d3c-${v4().substring(0, 8)}`;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    generateChart(data) {
        this.width = this.chartContainer.nativeElement.clientWidth || 800;
        this.height = this.chartContainer.nativeElement.clientHeight || 800;
        // this.svg = d3.select('svg');
        // this.chart = d3.select('#conainter');
        this.clearChart();
        this.getMinMaxValue(data.dataSet);
        if (data && data.options && data.options.margin) {
            this.setMargin(data.options.margin);
        }
        this.setLeftMargin(this.max);
        this.generateLineChart(data);
    }
    //Clears the current chart which is drawn
    /**
     * @return {?}
     */
    clearChart() {
        select(`#${this.chartIdLine}` + ' svg').remove();
    }
    /**
     * @private
     * @param {?} series
     * @return {?}
     */
    getMinMaxValue(series) {
        this.max = max(series[0].data);
        this.min = min(series[0].data);
        series.forEach((/**
         * @param {?} element
         * @return {?}
         */
        element => {
            /** @type {?} */
            var temp_max = max(element.data);
            /** @type {?} */
            var temp_min = min(element.data);
            if (this.max < temp_max)
                this.max = temp_max;
            if (this.min > temp_min)
                this.min = temp_min;
        }));
        if (this.min > 0)
            this.min = 0;
    }
    //set margin 
    /**
     * @private
     * @param {?} margin
     * @return {?}
     */
    setMargin(margin) {
        this.margin = margin;
    }
    // set left margin
    /**
     * @param {?} max
     * @return {?}
     */
    setLeftMargin(max$$1) {
        switch (max$$1.toString().length) {
            case 1: {
                this.margin.left = 50;
                break;
            }
            case 2: {
                this.margin.left = 55;
                break;
            }
            case 3: {
                this.margin.left = 60;
                break;
            }
            case 4: {
                this.margin.left = 70;
                break;
            }
            case 5: {
                this.margin.left = 80;
                break;
            }
            case 6: {
                this.margin.left = 85;
                break;
            }
            case 7: {
                this.margin.left = 90;
                break;
            }
            default: {
                this.margin.left = 100;
                break;
            }
        }
    }
    /**
     * @return {?}
     */
    setHeight() {
        this.height = this.height - this.margin.top - this.margin.bottom;
        this.width = this.width - this.margin.left - this.margin.right;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    generateLineChart(data) {
        /** @type {?} */
        const chartContainer = select(`#${this.chartIdLine}`)
            .append('svg').style('width', this.width).style('height', this.height);
        this.setHeight();
        /** @type {?} */
        const width = this.width;
        /** @type {?} */
        const height = this.height;
        /** @type {?} */
        const sample = [];
        this.convertData(data, sample);
        /** @type {?} */
        const chart = chartContainer.append('g')
            .attr('transform', `translate(${this.margin.left}, ${this.margin.right})`);
        this.addToolTip();
        chartContainer.call(this.tip);
        /** @type {?} */
        const xScale = scaleBand()
            .range([0, width])
            .domain(sample.map((/**
         * @param {?} s
         * @return {?}
         */
        (s) => s.category)))
            .padding(data.options.padding);
        /** @type {?} */
        const yScale = scaleLinear()
            .range([height, 0])
            .domain([this.min, this.max]);
        /** @type {?} */
        var valueline = line()
            .x((/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return xScale(d.category); }))
            .y((/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return yScale(d.value); }));
        console.log("sample", sample);
        // vertical grid lines
        // const makeXLines = () => d3.axisBottom(xScale)
        // .scale(xScale)
        /** @type {?} */
        const makeYLines = (/**
         * @return {?}
         */
        () => axisLeft(yScale))
        // .ticks(data.yAxis.noOfTicks)
        // .scale(yScale)
        ;
        // .ticks(data.yAxis.noOfTicks)
        // .scale(yScale)
        chart.append('g')
            .attr('transform', `translate(0, ${height})`)
            .call(axisBottom(xScale));
        chart.append('g')
            .call(axisLeft(yScale) // .ticks(data.yAxis.noOfTicks)
            .tickFormat((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (data.yAxis.symbolPosition == 'before')
                return data.yAxis.symbol + d;
            else if (data.yAxis.symbolPosition == 'after')
                return d + data.yAxis.symbol;
        })));
        // vertical grid lines
        // chart.append('g')
        //   .attr('class', 'grid')
        //   .attr('transform', `translate(0, ${height})`)
        //   .call(makeXLines()
        //     .tickSize(-height, 0, 0)
        //     .tickFormat('')
        //   )
        chart.append('g')
            .attr('class', 'grid')
            .call(makeYLines()
            .tickSize(-width, 0, 0)
            .tickFormat(''));
        /** @type {?} */
        const lineGroups = chart.selectAll()
            .data(sample)
            .enter()
            .append('g');
        lineGroups.append("path")
            .data([sample])
            .attr("class", "line")
            .attr("d", valueline)
            .on('mouseenter', this.tip.show)
            .on('mouseout', this.tip.hide);
        chartContainer
            .append('text')
            .attr('class', 'label')
            .attr('x', -(height / 2) - this.margin.left)
            .attr('y', this.margin.top / 2.4)
            .attr('transform', 'rotate(-90)')
            .attr('text-anchor', 'middle')
            .text(data.yAxis.text);
        chartContainer.append('text')
            .attr('class', 'label')
            .attr('x', width / 2 + this.margin.left)
            .attr('y', height + this.margin.top * 1.7)
            .attr('text-anchor', 'middle')
            .text(data.xAxis.text);
        chartContainer.append('text')
            .attr('class', 'title')
            .attr('x', width / 2 + this.margin.left)
            .attr('y', 40)
            .attr('text-anchor', 'middle')
            .text(data.title.text);
    }
    /**
     * @return {?}
     */
    addToolTip() {
        this.tip = tip().attr('class', 'd3-tip').html((/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return d.value; }));
    }
    /**
     * @private
     * @param {?} data
     * @param {?} sample
     * @return {?}
     */
    convertData(data, sample) {
        for (var i = 0; i < data.xAxis.category.length; i++) {
            /** @type {?} */
            const temp = {};
            temp.category = data.xAxis.category[i];
            temp.value = data.dataSet[0].data[i];
            temp.color = data.dataSet[0].color[i % data.dataSet[0].color.length];
            sample.push(temp);
        }
    }
}
LineChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'ndi-line-chart',
                encapsulation: ViewEncapsulation.None,
                template: "<div [id]=\"chartIdLine\" #chartContainerLine class=\"chart-wrapper\">",
                styles: ["ndi-line-chart #chartContainerLine{height:100%;width:100%}ndi-line-chart #chartContainerLine .bar{fill:#4682b4}ndi-line-chart #chartContainerLine .bar:hover{fill:brown}ndi-line-chart #chartContainerLine .axis--x path{display:none}body{font-family:'Open Sans',sans-serif}div#chartContainerLine{text-align:center}div.chart-wrapper{width:100%;height:100%;margin:auto;background-color:#fff}svg{width:100%;height:100%}.bar{fill:#80cbc4}text{font-size:12px;fill:#000}path{stroke:#000;stroke:#4682b4;stroke-width:1;fill:none}.grid path{stroke-width:0}.grid .tick line{stroke:#bbc4c7;stroke-opacity:.3}text.divergence{font-size:14px;fill:#2f4a6d}text.value{font-size:14px}text.title{font-size:22px;font-weight:600}text.label{font-size:14px;font-weight:400}text.y-label-margin{margin-right:10px}text.source{font-size:10px}.d3-tip{line-height:1;font-weight:700;padding:12px;background:rgba(0,0,0,.8);color:#fff;border-radius:2px}.d3-tip:after{box-sizing:border-box;display:inline;font-size:10px;width:100%;line-height:1;color:rgba(0,0,0,.8);content:\"\\25BC\";position:absolute;text-align:center}.d3-tip.n:after{margin:-1px 0 0;top:100%;left:0}"]
            }] }
];
/** @nocollapse */
LineChartComponent.ctorParameters = () => [];
LineChartComponent.propDecorators = {
    chartContainer: [{ type: ViewChild, args: ['chartContainerLine',] }],
    data: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NdiChartComponent {
    constructor() { }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
}
NdiChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'ndi-chart',
                template: "<div class=\"ndi-chart-wrapper\">\r\n    <ndi-bar-chart *ngIf=\"type==='bar'\" [data]=\"data\"></ndi-bar-chart>\r\n    <ndi-line-chart *ngIf=\"type==='line'\" [data]=\"data\"></ndi-line-chart>\r\n    <ndi-combined-bar-line-chart *ngIf=\"type==='combined'\" [data]=\"data\"></ndi-combined-bar-line-chart>\r\n    <ndi-waterfall-chart\u00A0*ngIf=\"type==='waterfall'\"\u00A0[data]=\"data\"></ndi-waterfall-chart> \r\n    <ndi-stacked-bar-chart *ngIf=\"type==='stacked'\"\u00A0[data]=\"data\"></ndi-stacked-bar-chart>\r\n    <ndi-dual-axes-bar-line-chart *ngIf=\"type==='dual-axes-bar-line'\"\u00A0[data]=\"data\"></ndi-dual-axes-bar-line-chart>\r\n</div>",
                encapsulation: ViewEncapsulation.None,
                styles: ["@font-face{font-family:Nissan Brand Regular;src:url(../../assets/fonts/NissanBrandRegular.eot);src:url(../../assets/fonts/NissanBrandRegular.woff)}@font-face{font-family:Nissan Brand Light;src:url(../../assets/fonts/NissanBrandLight.eot);src:url(../../assets/fonts/NissanBrandLight.woff)}@font-face{font-family:Nissan Brand Bold;src:url(../../assets/fonts/NissanBrandBold.eot);src:url(../../assets/fonts/NissanBrandBold.woff)}@font-face{font-family:Nissan Brand Italic;src:url(../../assets/fonts/NissanBrandItalic.eot);src:url(../../assets/fonts/NissanBrandItalic.woff)}@media screen and (-webkit-min-device-pixel-ratio:0){@font-face{font-family:Nissan Brand Bold;src:url(../../assets/fonts/NissanBrandBold.otf) format(\"opentype\");src:url(../../assets/fonts/NissanBrandBold.ttf) format(\"truetype\")}@font-face{font-family:Nissan Brand Italic;src:url(../../assets/fonts/NissanBrandItalic.otf) format(\"opentype\");src:url(../../assets/fonts/NissanBrandItalic.ttf) format(\"truetype\")}@font-face{font-family:Nissan Brand Light;src:url(../../assets/fonts/NissanBrandLight.otf) format(\"opentype\");src:url(../../assets/fonts/NissanBrandItalic.ttf) format(\"truetype\")}@font-face{font-family:Nissan Brand Regular;src:url(../../assets/fonts/NissanBrandRegular.otf) format(\"opentype\");src:url(../../assets/fonts/NissanBrandRegular.ttf) format(\"truetype\")}}ndi-chart{width:100%;height:100%}ndi-chart .ndi-chart-wrapper{height:100%;width:100%}.ndi-chart-wrapper div.chart-wrapper{width:100%;height:100%;background-color:#fff}.ndi-chart-wrapper svg{width:100%;height:100%}.ndi-chart-wrapper text{font-family:Nissan Brand Regular;font-size:.8rem;text-align:center;fill:#5f6a89}.ndi-chart-wrapper .tick text{fill:#435077}.ndi-chart-wrapper .grid path{stroke-width:0}.ndi-chart-wrapper .grid .tick line{stroke:#f1f2f3}.ndi-chart-wrapper text.title{font-family:Nissan Brand Bold;font-size:1.2rem;text-align:left;fill:#435077}.ndi-chart-wrapper text.label{font-family:Nissan Brand Bold;font-size:.8rem;text-align:center;fill:#435077}.ndi-chart-wrapper text.y-label-margin{margin-right:10px}.ndi-chart-wrapper .y-axis-path-tick path{stroke:transparent;opacity:0}.ndi-chart-wrapper .y-axis-path-tick g line{opacity:0;stroke:transparent}.ndi-chart-wrapper .legends{color:#5f6a89;font-family:Nissan Brand Regular;font-size:.8rem;text-align:right;text-anchor:end}.d3-tip{line-height:1;background:#212945;color:#fff;border-radius:5px;font-family:Nissan Brand Regular;font-size:1rem;text-align:left}.d3-tip .tool-tip-container{display:flex;flex-direction:column;justify-content:center;align-items:center}.d3-tip .tool-tip-container .heading{flex:1;width:100%;padding:8px 0;text-align:center;background:#303956;border-radius:5px;color:#959fbc;text-transform:uppercase}.d3-tip .tool-tip-container .content{flex:3;padding:5px 12px 12px;width:100%;display:flex;flex-direction:row;justify-content:center;align-items:center}.d3-tip .tool-tip-container .content .circle{width:10px;height:10px;border-radius:5px}.d3-tip .tool-tip-container .content .legend-value{margin:5px 10px}.d3-tip .tool-tip-container .content .value{margin:5px;font-weight:600;font-family:Nissan Brand Bold;font-size:1rem;text-align:left}.d3-tip:after{box-sizing:border-box;display:block;font-size:10px;width:100%;line-height:1;color:#212945;content:\"\\25BC\";position:absolute;text-align:center}.d3-tip.n:after{margin:-1px 0 0;top:100%;left:0}"]
            }] }
];
/** @nocollapse */
NdiChartComponent.ctorParameters = () => [];
NdiChartComponent.propDecorators = {
    type: [{ type: Input }],
    data: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class CombinedBarLineChartComponent extends CommonChartComponent {
    constructor() {
        super();
    }
    /**
     * @param {?} chart
     * @param {?} data
     * @param {?} xScaleGroup
     * @param {?} xScaleIndividual
     * @param {?} yScale
     * @return {?}
     */
    draw(chart, data, xScaleGroup, xScaleIndividual, yScale) {
        /** @type {?} */
        const convertedGroupDataBar = [];
        /** @type {?} */
        const convertedGroupDataLine = [];
        // this.convertData(data,convertedData);
        this.convertDataInGroup(data, convertedGroupDataBar, 'bar');
        this.convertDataInGroup(data, convertedGroupDataLine, 'line');
        this.convertedData = convertedGroupDataBar.concat(convertedGroupDataLine);
        /** @type {?} */
        const convertedLineData = [];
        for (let i = 0; i < convertedGroupDataLine[0].name.length; i++) {
            convertedLineData[i] = [];
            for (let j = 0; j < convertedGroupDataLine.length; j++) {
                /** @type {?} */
                const temp = {};
                temp.category = convertedGroupDataLine[j].category;
                temp.color = convertedGroupDataLine[j].color[i];
                temp.name = convertedGroupDataLine[j].name[i];
                temp.value = convertedGroupDataLine[j].value[i];
                temp.lineDetails = convertedGroupDataLine[j].lineDetails[i];
                convertedLineData[i].push(temp);
            }
        }
        chart.append('g')
            .selectAll('g')
            .data(convertedGroupDataBar)
            .enter()
            .append('g')
            .attr('class', 'bar')
            .attr('transform', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return 'translate(' + xScaleGroup(d.category) + ',0)';
        }))
            .selectAll('path')
            .data((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.name.map((/**
             * @param {?} key
             * @param {?} i
             * @return {?}
             */
            (key, i) => {
                return {
                    key: i, value: { value: d.value[i], color: d.color[i], name: d.name[i], category: d.category }
                };
            }));
        }))
            .enter()
            .append('path')
            .attr('d', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => {
            if (g.value.value >= 0) {
                return this.roundedRect(xScaleIndividual(g.value.name), yScale(Math.max(0, g.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScale(g.value.value) - yScale(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
            }
            else {
                return this.roundedRect(xScaleIndividual(g.value.name), yScale(Math.max(0, g.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScale(g.value.value) - yScale(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), 0, 0, this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
            }
        }))
            // .attr('x', (g) => xScaleIndividual(g.value.name))
            // .attr('y', (g) => yScale(Math.max(0, g.value.value)))
            // .attr('width', xScaleIndividual.bandwidth())
            // .attr('height', (g) => Math.abs(yScale(g.value.value) - yScale(0)))
            .attr('fill', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => {
            return g.value.color;
        }))
            .on('mouseenter', this.tip.show)
            .on('mouseout', this.tip.hide);
        /** @type {?} */
        const lineClass = 'line ' + this.chartId + '-line';
        /** @type {?} */
        const lineSelection = line()
            .x((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return xScaleGroup(d.category);
        }))
            .y((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return yScale(d.value);
        }));
        /** @type {?} */
        const lineSelectionCurve = line()
            .x((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return xScaleGroup(d.category);
        }))
            .y((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return yScale(d.value);
        }))
            .curve(curveCardinal);
        /** @type {?} */
        const line$$1 = chart.append('g')
            .attr('class', 'line-group')
            .selectAll('g')
            // .append('g')
            .data(convertedLineData);
        // .enter();
        // .selectAll('g');
        line$$1
            .enter()
            .append('g')
            .attr('id', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return this.chartId + d[0].name;
        }))
            .attr('class', lineClass)
            // .style('opacity', 1)
            .attr('transform', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return 'translate(' + (xScaleGroup.bandwidth() / 2) + ',0)';
        }))
            // .selectAll('path')
            .append('path')
            .attr('d', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (d[0].lineDetails !== null && d[0].lineDetails.curve) {
                return lineSelectionCurve(d);
            }
            else {
                return lineSelection(d);
            }
        }))
            .attr('stroke', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return d[i].color;
        }))
            .attr('stroke-width', 2)
            .attr('stroke-dasharray', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            // set the dasharray if condition null means no attr
            if (d[0].lineDetails !== null && d[0].lineDetails.dashed) {
                return (d[0].lineDetails.dashedWidth) ? d[0].lineDetails.dashedWidth : 5;
            }
            return null;
        }))
            .attr('fill', 'none');
        chart.selectAll('g.line')
            .selectAll('circle')
            .data((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.map((/**
             * @param {?} g
             * @param {?} i
             * @return {?}
             */
            (g, i) => {
                return {
                    key: i, value: { value: g.value, color: g.color, name: g.name, category: g.category }
                };
            }));
        }))
            .enter()
            .append('svg:circle')
            .style('cursor', 'pointer')
            .attr('stroke', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.value.color;
        }))
            .attr('fill', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.value.color;
        }))
            .attr('cx', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return xScaleGroup(d.value.category);
        }))
            .attr('cy', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return yScale(d.value.value);
        }))
            .attr('stroke', '#FFFFFF')
            .attr('stroke-width', 2)
            .attr('r', 6)
            .on('mouseenter', this.tip.show)
            .on('mouseout', this.tip.hide);
    }
}
CombinedBarLineChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'ndi-combined-bar-line-chart',
                template: "<div [id]=\"chartId\" #chartContainer class=\"chart-wrapper\"></div>",
                styles: [""]
            }] }
];
/** @nocollapse */
CombinedBarLineChartComponent.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class WaterfallChartComponent {
    constructor() {
        this.margin = { top: 50, right: 50, bottom: 50, left: 50 }; //default margin
        this.padding = 0.3;
    }
    /**
     * @return {?}
     */
    ngOnInit() {
        this.createId();
    }
    /**
     * @return {?}
     */
    ngAfterViewInit() {
        this.generateChart(this.data);
    }
    /**
     * @return {?}
     */
    createId() {
        this.chartId = `d3c-${v4().substring(0, 8)}`;
    }
    /**
     * @return {?}
     */
    ngOnChanges() {
        if (!this.data) {
            return;
        }
        this.generateChart(this.data);
    }
    // onResize() {
    //   this.generateChart(this.data);
    // }
    /**
     * @param {?} data
     * @return {?}
     */
    generateChart(data) {
        this.width = this.chartContainer.nativeElement.clientWidth || 800;
        this.height = this.chartContainer.nativeElement.clientHeight || 800;
        this.clearChart();
        this.getMinMaxValueAndCount(data.dataSet);
        if (data && data.options && data.options.margin) {
            this.setMargin(data.options.margin);
        }
        this.setLeftMargin(this.max, this.min);
        this.generateWaterfallChart(data);
    }
    //Clears the current chart which is drawn
    /**
     * @return {?}
     */
    clearChart() {
        select(`#${this.chartId}` + ' svg').remove();
    }
    /**
     * @private
     * @param {?} dataSet
     * @return {?}
     */
    getMinMaxValueAndCount(dataSet) {
        this.max = sum(dataSet[0].data.filter((/**
         * @param {?} v
         * @return {?}
         */
        v => v > 0)));
        this.min = min(dataSet[0].data.filter((/**
         * @param {?} v
         * @return {?}
         */
        v => v > 0)));
        this.maxCount = 0;
        dataSet.forEach((/**
         * @param {?} element
         * @return {?}
         */
        element => {
            /** @type {?} */
            var temp_max = max(element.data);
            /** @type {?} */
            var temp_min = min(element.data.filter((/**
             * @param {?} v
             * @return {?}
             */
            v => v > 0)));
            if (this.max < temp_max)
                this.max = temp_max;
            if (this.min > temp_min)
                this.min = temp_min;
            //get the maximum count of dataSet data
            /** @type {?} */
            var temp_maxCount = element.data.length;
            if (this.maxCount < temp_maxCount)
                this.maxCount = temp_maxCount;
        }));
        if (this.min > 0)
            this.min = 0;
        else
            this.min = Math.floor(this.min * 1.1);
        if (this.max < 0)
            this.max = 0;
        else
            this.max = Math.ceil(this.max * 1.1);
    }
    //set users provided margin 
    /**
     * @private
     * @param {?} margin
     * @return {?}
     */
    setMargin(margin) {
        this.margin = margin;
    }
    // set left margin
    /**
     * @param {?} max
     * @param {?} min
     * @return {?}
     */
    setLeftMargin(max$$1, min$$1) {
        switch (Math.max(max$$1.toString().length, min$$1.toString().length)) {
            case 1: {
                this.margin.left = 50;
                break;
            }
            case 2: {
                this.margin.left = 55;
                break;
            }
            case 3: {
                this.margin.left = 60;
                break;
            }
            case 4: {
                this.margin.left = 70;
                break;
            }
            case 5: {
                this.margin.left = 80;
                break;
            }
            case 6: {
                this.margin.left = 85;
                break;
            }
            case 7: {
                this.margin.left = 90;
                break;
            }
            default: {
                this.margin.left = 100;
                break;
            }
        }
    }
    /**
     * @return {?}
     */
    setHeight() {
        this.height = this.height - this.margin.top - this.margin.bottom;
        this.width = this.width - this.margin.left - this.margin.right;
    }
    /**
     * @param {?} data
     * @return {?}
     */
    generateWaterfallChart(data) {
        /** @type {?} */
        const chartWrapper = select(`#${this.chartId}`)
            .append('svg').style('width', this.width).style('height', this.height);
        this.setHeight();
        /** @type {?} */
        const width = this.width;
        /** @type {?} */
        const height = this.height;
        /** @type {?} */
        const convertedData = [];
        this.convertData(data, convertedData);
        /** @type {?} */
        const chart = chartWrapper.append('g')
            .attr('transform', `translate(${this.margin.left}, ${this.margin.right})`);
        this.addToolTip();
        chartWrapper.call(this.tip);
        //scale spacing for group 
        /** @type {?} */
        const xScaleGroup = scaleBand()
            .rangeRound([0, width])
            .domain(convertedData.map((/**
         * @param {?} s
         * @return {?}
         */
        (s) => s.category)))
            .padding(data.options.padding);
        //The scale spacing for spacing inside group
        /** @type {?} */
        const xScaleIndividual = scaleBand()
            .padding(data.options.innerPadding);
        /** @type {?} */
        const yScale = scaleLinear()
            .range([height, 0])
            .domain([this.min, this.max])
            .nice();
        // vertical grid lines
        // const makeXLines = () => d3.axisBottom(xScaleGroup)
        // .scale(xScaleGroup)
        /** @type {?} */
        const makeYLines = (/**
         * @return {?}
         */
        () => axisLeft(yScale)
            .ticks(data.yAxis.noOfTicks)
            .scale(yScale));
        xScaleIndividual.domain(this.getKeys(data.dataSet))
            .rangeRound([0, xScaleGroup.bandwidth()]);
        chart.append('g')
            .attr('transform', `translate(0, ${height})`)
            .call(axisBottom(xScaleGroup));
        chart.append('g')
            .attr("class", "y-axis-path-tick")
            .call(axisLeft(yScale).ticks(data.yAxis.noOfTicks)
            .tickFormat((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (data.yAxis.symbolPosition == 'before')
                return data.yAxis.symbol + d;
            else if (data.yAxis.symbolPosition == 'after')
                return d + data.yAxis.symbol;
        })));
        selectAll('.y-axis-path-tick g line').remove(); //removes y axis ticks
        select('.y-axis-path-tick path').remove(); // removes y axis line
        // vertical grid lines from X Axis
        // chart.append('g')
        //   .attr('class', 'grid')
        //   .attr('transform', `translate(0, ${height})`)
        //   .call(makeXLines()
        //     .tickSize(-height, 0, 0)
        //     .tickFormat('')
        //   )
        //horizontal grid lines from Y Axis
        chart.append('g')
            .attr('class', 'grid')
            .call(makeYLines()
            .tickSize(-width, 0, 0)
            .tickFormat(''));
        /** @type {?} */
        let tempData = [];
        for (var i = 0; i < convertedData.length; i++) {
            /** @type {?} */
            const tempAray = convertedData[i];
            if (tempAray.value > 0) {
                this.className = 'positive';
            }
            else {
                this.className = 'negative';
            }
            if (i == 0) {
                this.start = 0;
                this.end = tempAray.value[0];
            }
            else {
                this.start = tempData[i - 1].end;
                this.end = this.start + tempAray.value[0];
            }
            /** @type {?} */
            let tempObj = {
                "name": tempAray.name[0],
                "value": tempAray.value[0],
                "start": this.start,
                "end": this.end,
                "class": this.className,
                "category": tempAray.category
            };
            tempData.push(tempObj);
        }
        console.log("temp obj", tempData);
        console.log("convertedData", convertedData);
        /** @type {?} */
        const x = scaleBand()
            .range([0, width])
            .domain(tempData.map((/**
         * @param {?} s
         * @return {?}
         */
        (s) => s.category)))
            .padding(this.padding);
        /** @type {?} */
        const y = scaleLinear()
            .range([height, 0])
            .domain([this.min, this.max]);
        /*
        var bar = chart.selectAll(".bar")
        .data(tempData)
        .enter().append("g")
         .attr("class", function(d) { return "bar " + d.class })
         .attr("transform", function(d) {  console.log("d value",d); return "translate(" + x(d.category) + ",0)"; });
        
        bar.append("rect")
         
        .attr("y", function(d) { return y( Math.max(d.start, d.end) ); })
        .attr("height", function(d) { return Math.abs( y(d.start) - y(d.end) );  })
        .attr("width", x.bandwidth())
        
        */
        /** @type {?} */
        var bar = chart.selectAll(".bar")
            .data(tempData)
            .enter().append("g")
            .attr("class", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return "bar " + d.class; }))
            .attr("transform", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return "translate(" + x(d.category) + ",0)"; }));
        bar.append("rect")
            .attr("y", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return y(Math.max(d.start, d.end)); }))
            .attr("height", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return Math.abs(y(d.start) - y(d.end)); }))
            .attr("width", x.bandwidth());
        bar.append("text")
            .attr("x", x.bandwidth() / 2)
            .attr("y", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return y(d.end) + 5; }))
            .attr("dy", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return ((d.class == 'negative') ? '-' : '') + ".75em"; }))
            .text((/**
         * @param {?} d
         * @return {?}
         */
        function (d) { /** @type {?} */
        const tot = dollarFormatter(d.end - d.start); return tot; }));
        bar.filter((/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return d.class != "total"; })).append("line")
            .attr("class", "connector")
            .attr("x1", x.bandwidth() + 5)
            .attr("y1", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return y(d.end); }))
            .attr("x2", x.bandwidth() / (1 - this.padding) - 5)
            .attr("y2", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return y(d.end); }));
        /** @type {?} */
        const colors = scaleOrdinal()
            .range(data.dataSet.map((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.color[0];
        })).reverse());
        /** @type {?} */
        const legend = this.createLegends(chart, convertedData, width, colors, updateBars);
        /** @type {?} */
        var filteredBars = [];
        /** @type {?} */
        var keys = convertedData[0].name.reverse();
        /**
         * @param {?} d
         * @return {?}
         */
        function updateBars(d) {
            //
            // Update the array to filter the chart by:
            //
            // add the clicked key if not included:
            if (filteredBars.indexOf(d) == -1) {
                filteredBars.push(d);
                // if all bars are un-checked, reset:
                if (filteredBars.length == keys.length)
                    filteredBars = [];
            }
            // otherwise remove it:
            else {
                filteredBars.splice(filteredBars.indexOf(d), 1);
            }
            //
            // Update the scales for each group(/states)'s items:
            //
            /** @type {?} */
            var newKeys = [];
            keys.forEach((/**
             * @param {?} d
             * @return {?}
             */
            function (d) {
                if (filteredBars.indexOf(d) == -1) {
                    newKeys.push(d);
                }
            }));
            xScaleIndividual.domain(newKeys).rangeRound([0, xScaleGroup.bandwidth()]);
            /** @type {?} */
            var min$$1 = min(convertedData, (/**
             * @param {?} d
             * @return {?}
             */
            (d) => {
                return min(keys, (/**
                 * @param {?} key
                 * @return {?}
                 */
                (key) => {
                    if (filteredBars.indexOf(key) == -1) {
                        return d.value[d.name.indexOf(key)];
                    }
                }));
            }));
            if (min$$1 > 0)
                min$$1 = 0;
            else
                min$$1 = Math.floor(min$$1 * 1.1);
            /** @type {?} */
            var max$$1 = max(convertedData, (/**
             * @param {?} d
             * @return {?}
             */
            (d) => {
                return max(keys, (/**
                 * @param {?} key
                 * @return {?}
                 */
                (key) => {
                    if (filteredBars.indexOf(key) == -1) {
                        return d.value[d.name.indexOf(key)];
                    }
                }));
            }));
            if (max$$1 < 0)
                max$$1 = 0;
            else
                max$$1 = Math.ceil(max$$1 * 1.1);
            yScale.domain([min$$1, max$$1])
                .nice();
            /** @type {?} */
            const makeUpdatedYLines = (/**
             * @return {?}
             */
            () => axisLeft(yScale)
                .ticks(data.yAxis.noOfTicks)
                .scale(yScale))
            //  chart.selectAll(".grid")
            //       .remove();
            //update horizontal grid lines from Y Axis
            ;
            //  chart.selectAll(".grid")
            //       .remove();
            //update horizontal grid lines from Y Axis
            chart.selectAll(".grid")
                .transition()
                .call(makeUpdatedYLines()
                .tickSize(-width, 0, 0)
                .tickFormat(''))
                .duration(500);
            // update the y axis:
            chart.select(".y-axis-path-tick")
                .transition()
                .call(axisLeft(yScale).ticks(data.yAxis.noOfTicks)
                .tickFormat((/**
             * @param {?} d
             * @return {?}
             */
            (d) => {
                if (data.yAxis.symbolPosition == 'before')
                    return data.yAxis.symbol + d;
                else if (data.yAxis.symbolPosition == 'after')
                    return d + data.yAxis.symbol;
            })))
                .duration(500);
            //
            // Filter out the bands that need to be hidden:
            //
            /** @type {?} */
            var bars = chart.selectAll(".bar").selectAll("rect")
                .data((/**
             * @param {?} d
             * @return {?}
             */
            (d) => {
                return d.name.map((/**
                 * @param {?} key
                 * @param {?} i
                 * @return {?}
                 */
                (key, i) => { return { key: i, value: { value: d.value[i], color: d.color[i], name: d.name[i] } }; }));
            }));
            bars.filter((/**
             * @param {?} d
             * @return {?}
             */
            (d) => {
                return filteredBars.indexOf(d.value.name) > -1;
            }))
                .transition()
                .attr("x", (/**
             * @param {?} d
             * @return {?}
             */
            function (d) {
                return (+select(this).attr("x")) + (+select(this).attr("width")) / 2;
            }))
                .attr("height", 0)
                .attr("width", 0)
                .attr("y", (/**
             * @param {?} d
             * @return {?}
             */
            function (d) { return height; }))
                .duration(500);
            //
            // Adjust the remaining bars:
            //
            bars.filter((/**
             * @param {?} d
             * @return {?}
             */
            function (d) {
                return filteredBars.indexOf(d.value.name) == -1;
            }))
                .transition()
                .attr("x", (/**
             * @param {?} d
             * @return {?}
             */
            function (d) { return xScaleIndividual(d.value.name); }))
                .attr("y", (/**
             * @param {?} d
             * @return {?}
             */
            function (d) { return yScale(Math.max(0, d.value.value)); }))
                .attr('height', (/**
             * @param {?} d
             * @return {?}
             */
            (d) => Math.abs(yScale(d.value.value) - yScale(0))))
                .attr("width", xScaleIndividual.bandwidth())
                .attr("fill", (/**
             * @param {?} d
             * @return {?}
             */
            function (d) { return d.value.color; }))
                .duration(500);
            // update legend:
            legend.selectAll("rect")
                .transition()
                .attr("fill", (/**
             * @param {?} d
             * @return {?}
             */
            function (d) {
                if (filteredBars.length) {
                    if (filteredBars.indexOf(d) == -1) {
                        return colors(d);
                    }
                    else {
                        return "white";
                    }
                }
                else {
                    return colors(d);
                }
            }))
                .duration(100);
        }
        this.addYAxisTitle(chartWrapper, height, data);
        this.addXAxisTitle(chartWrapper, width, height, data);
        this.addMainTitle(chartWrapper, width, data);
        // this.addSourceInformation(chartWrapper, width, height);
        /**
         * @param {?} n
         * @return {?}
         */
        function dollarFormatter(n) {
            n = Math.round(n);
            /** @type {?} */
            var result = n;
            if (Math.abs(n) > 1000) {
                result = Math.round(n / 1000) + 'K';
            }
            return '$' + result;
        }
    }
    /**
     * @private
     * @param {?} chart
     * @param {?} convertedData
     * @param {?} width
     * @param {?} colors
     * @param {?} updateBars
     * @return {?}
     */
    createLegends(chart, convertedData, width, colors, updateBars) {
        /** @type {?} */
        const legend = chart.append("g")
            .attr("class", "legends")
            .selectAll("g")
            .data(convertedData[0].name.reverse())
            .enter().append("g")
            .attr("transform", (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        function (d, i) { return "translate(" + (0 - (i * 80)) + ",-25)"; }));
        legend.append("rect")
            .attr("x", width - 17)
            .attr("width", 15)
            .attr("height", 15)
            .attr("fill", colors)
            .attr("stroke", colors)
            .attr("stroke-width", 2)
            .on("click", (/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return updateBars(d); }));
        legend.append("text")
            .attr("x", width - 24)
            .attr("y", 9.5)
            .attr("dy", "0.32em")
            .text((/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return d; }));
        return legend;
    }
    // private addSourceInformation(chartWrapper: any, width: number, height: number) {
    //   chartWrapper.append('text')
    //     .attr('class', 'source')
    //     .attr('x', width - this.margin.left / 2)
    //     .attr('y', height + this.margin.top * 1.7)
    //     .attr('text-anchor', 'start')
    //     .text('Source : convertedData Text');
    // }
    /**
     * @private
     * @param {?} chartWrapper
     * @param {?} width
     * @param {?} data
     * @return {?}
     */
    addMainTitle(chartWrapper, width, data) {
        chartWrapper.append('text')
            .attr('class', 'title')
            .attr('x', width / 2 + this.margin.left)
            .attr('y', 12)
            .attr('text-anchor', 'middle')
            .text(data.title.text);
    }
    /**
     * @private
     * @param {?} chartWrapper
     * @param {?} width
     * @param {?} height
     * @param {?} data
     * @return {?}
     */
    addXAxisTitle(chartWrapper, width, height, data) {
        chartWrapper.append('text')
            .attr('class', 'label')
            .attr('x', width / 2 + this.margin.left)
            .attr('y', height + this.margin.top * 1.7)
            .attr('text-anchor', 'middle')
            .text(data.xAxis.text);
    }
    /**
     * @private
     * @param {?} chartWrapper
     * @param {?} height
     * @param {?} data
     * @return {?}
     */
    addYAxisTitle(chartWrapper, height, data) {
        chartWrapper
            .append('text')
            .attr('class', 'label')
            .attr('x', -(height / 2) - this.margin.left)
            .attr('y', this.margin.top / 2.4)
            .attr('transform', 'rotate(-90)')
            .attr('text-anchor', 'middle')
            .text(data.yAxis.text);
    }
    /**
     * @private
     * @param {?} data
     * @param {?} convertedData
     * @return {?}
     */
    convertData(data, convertedData) {
        for (var i = 0; i < this.maxCount; i++) {
            /** @type {?} */
            const temp = {};
            temp.value = [];
            temp.color = [];
            temp.name = [];
            temp.category = data.xAxis.category[i];
            for (var j = 0; j < data.dataSet.length; j++) {
                temp.value.push(data.dataSet[j].data[i]);
                temp.name.push(data.dataSet[j].name);
                if (data.dataSet[j].color)
                    temp.color.push(data.dataSet[j].color[i % data.dataSet[j].color.length]);
                else
                    temp.color.push("grey");
            }
            convertedData.push(temp);
        }
    }
    /**
     * @private
     * @param {?} dataSet
     * @return {?}
     */
    getKeys(dataSet) {
        /** @type {?} */
        const tempKeys = [];
        dataSet.forEach((/**
         * @param {?} element
         * @return {?}
         */
        element => {
            tempKeys.push(element.name);
        }));
        return tempKeys;
    }
    // private setColors(data: BarChartBaseModel, i: number) {
    //   if (data.dataSet[0].color.length == data.dataSet[0].data.length)
    //     return data.dataSet[0].color[i];
    //   else if (data.dataSet[0].color.length == 1)
    //     return data.dataSet[0].color[0];
    //   else
    //     return "grey";
    // }
    /**
     * @private
     * @return {?}
     */
    addToolTip() {
        this.tip = tip().attr('class', 'd3-tip').html((/**
         * @param {?} d
         * @return {?}
         */
        function (d) { return d.value.value + " " + d.value.name; }));
    }
}
WaterfallChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'ndi-waterfall-chart',
                encapsulation: ViewEncapsulation.None,
                template: "<div [id]=\"chartId\" #chartContainer class=\"chart-wrapper\">\r\n    ",
                styles: [".legends{font-size:10px;font-weight:600;text-anchor:end}body{font-family:sans-serif;font-size:12px;font-weight:400}.bar text{text-anchor:middle;fill:#fff;font:12px sans-serif;text-anchor:middle}.bubble{font-weight:700}.ellipse{fill:none;stroke:#000;stroke-width:2}.bar.total rect{fill:#4682b4}.bar.positive rect{fill:#556b2f}.bar.negative rect{fill:#dc143c}.axis text{font:10px sans-serif}div.tooltip{height:16px;pointer-events:none;position:absolute;text-align:center;padding:2px;font:12px sans-serif;background:#3c0;border:0;border-radius:8px;pointer-events:none;width:90px}.bar line.connector{stroke:grey;stroke-dasharray:3}.axis line,.axis path{fill:none;stroke:#000;shape-rendering:crispEdges}"]
            }] }
];
/** @nocollapse */
WaterfallChartComponent.ctorParameters = () => [];
WaterfallChartComponent.propDecorators = {
    chartContainer: [{ type: ViewChild, args: ['chartContainer',] }],
    data: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class StackedBarChartComponent extends CommonChartComponent {
    constructor() {
        super();
    }
    /**
     * @param {?} dataSet
     * @return {?}
     */
    getMinMaxValueAndCount(dataSet) {
        this.maxCount = 0;
        dataSet.forEach((/**
         * @param {?} element
         * @return {?}
         */
        element => {
            // get the maximum count of dataSet data
            /** @type {?} */
            const temp_maxCount = element.data.length;
            if (this.maxCount < temp_maxCount) {
                this.maxCount = temp_maxCount;
            }
        }));
        // get max and min
        for (let i = 0; i < this.maxCount; i++) {
            /** @type {?} */
            let sumPositive = 0;
            /** @type {?} */
            let sumNegative = 0;
            for (let j = 0; j < dataSet.length; j++) {
                (dataSet[j].data[i] >= 0) ? sumPositive += dataSet[j].data[i] : sumNegative += dataSet[j].data[i];
            }
            (i === 0) ? this.max = sumPositive : ((sumPositive > this.max) ? this.max = sumPositive : this.max = this.max);
            (i === 0) ? this.min = sumNegative : ((sumNegative < this.min) ? this.min = sumNegative : this.min = this.min);
        }
        this.max = (this.max < 0) ? 0 : this.max;
        this.min = (this.min > 0) ? 0 : this.min;
    }
    /**
     * @param {?} data
     * @param {?} convertedData
     * @param {?=} type
     * @return {?}
     */
    convertDataInGroup(data, convertedData, type) {
        for (let i = 0; i < this.maxCount; i++) {
            /** @type {?} */
            const temp = {};
            temp.color = [];
            temp.category = data.xAxis.category[i];
            if (type) {
                for (let j = 0; j < data.dataSet.length; j++) {
                    if (data.dataSet[j].type === type) {
                        temp[data.dataSet[j].name] = data.dataSet[j].data[i];
                        if (data.dataSet[j].color) {
                            temp.color.push(data.dataSet[j].color[i % data.dataSet[j].color.length]);
                        }
                        else {
                            temp.color.push('grey');
                        }
                    }
                }
            }
            else {
                for (let j = 0; j < data.dataSet.length; j++) {
                    temp[data.dataSet[j].name] = data.dataSet[j].data[i];
                    if (data.dataSet[j].color) {
                        temp.color.push(data.dataSet[j].color[i % data.dataSet[j].color.length]);
                    }
                    else {
                        temp.color.push('grey');
                    }
                }
            }
            convertedData.push(temp);
        }
    }
    /**
     * @param {?} chart
     * @param {?} data
     * @param {?} xScaleGroup
     * @param {?} xScaleIndividual
     * @param {?} yScale
     * @return {?}
     */
    draw(chart, data, xScaleGroup, xScaleIndividual, yScale) {
        this.convertedData = [];
        this.convertDataInGroup(data, this.convertedData);
        /** @type {?} */
        const series = this.convertToStack();
        return chart.append('g')
            .selectAll('g')
            .data(series)
            .enter()
            .append('g')
            .attr('class', 'stacked-bar')
            .selectAll('rect')
            .data((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.map((/**
             * @param {?} g
             * @param {?} i
             * @return {?}
             */
            (g, i) => {
                return {
                    key: i, value: { y0: g[0], y1: g[1], value: g.data[d.key],
                        color: g.data.color[d.index], category: g.data.category, name: d.key }
                };
            }));
        }))
            .enter()
            .append('rect')
            .attr('x', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => xScaleGroup(g.value.category)))
            .attr('y', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => yScale(g.value.y1)))
            .attr('width', xScaleGroup.bandwidth())
            .attr('height', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => Math.abs(yScale(g.value.y0) - yScale(g.value.y1))))
            .attr('fill', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => {
            return g.value.color;
        }))
            .on('mouseenter', this.tip.show)
            .on('mouseout', this.tip.hide);
    }
    /**
     * @return {?}
     */
    convertToStack() {
        return stack()
            .keys(this.getKeys())
            .offset(stackOffsetDiverging)(this.convertedData);
    }
}
StackedBarChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'ndi-stacked-bar-chart',
                template: "<div [id]=\"chartId\" #chartContainer class=\"chart-wrapper\"></div>",
                styles: [""]
            }] }
];
/** @nocollapse */
StackedBarChartComponent.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class DualAxesBarLineChartComponent extends CommonChartComponent {
    constructor() {
        super();
    }
    /**
     * @param {?} chart
     * @param {?} data
     * @param {?} xScaleGroup
     * @param {?} xScaleIndividual
     * @param {?} yScale
     * @param {?} yScaleSecondary
     * @return {?}
     */
    draw(chart, data, xScaleGroup, xScaleIndividual, yScale, yScaleSecondary) {
        /** @type {?} */
        const convertedGroupDataBar = [];
        /** @type {?} */
        const convertedGroupDataLine = [];
        // this.convertData(data,convertedData);
        this.convertDataInGroup(data, convertedGroupDataBar, 'bar');
        this.convertDataInGroup(data, convertedGroupDataLine, 'line');
        this.convertedData = convertedGroupDataBar.concat(convertedGroupDataLine);
        /** @type {?} */
        const convertedLineData = [];
        for (let i = 0; i < convertedGroupDataLine[0].name.length; i++) {
            convertedLineData[i] = [];
            for (let j = 0; j < convertedGroupDataLine.length; j++) {
                /** @type {?} */
                const temp = {};
                temp.category = convertedGroupDataLine[j].category;
                temp.color = convertedGroupDataLine[j].color[i];
                temp.name = convertedGroupDataLine[j].name[i];
                temp.value = convertedGroupDataLine[j].value[i];
                temp.yAxisSecondary = convertedGroupDataLine[j].yAxisSecondary[i];
                temp.lineDetails = convertedGroupDataLine[j].lineDetails[i];
                convertedLineData[i].push(temp);
            }
        }
        chart.append('g')
            .selectAll('g')
            .data(convertedGroupDataBar)
            .enter()
            .append('g')
            .attr('class', 'bar')
            .attr('transform', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return 'translate(' + xScaleGroup(d.category) + ',0)';
        }))
            .selectAll('path')
            .data((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.name.map((/**
             * @param {?} key
             * @param {?} i
             * @return {?}
             */
            (key, i) => {
                return {
                    key: i, value: {
                        value: d.value[i], color: d.color[i], name: d.name[i],
                        yAxisSecondary: d.yAxisSecondary[i], category: d.category
                    }
                };
            }));
        }))
            .enter()
            .append('path')
            .attr('d', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => {
            if (g.value.yAxisSecondary) {
                if (g.value.value >= 0) {
                    return this.roundedRect(xScaleIndividual(g.value.name), yScaleSecondary(Math.max(0, g.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScaleSecondary(g.value.value) - yScaleSecondary(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
                }
                else {
                    return this.roundedRect(xScaleIndividual(g.value.name), yScaleSecondary(Math.max(0, g.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScaleSecondary(g.value.value) - yScaleSecondary(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), 0, 0, this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
                }
            }
            else {
                if (g.value.value >= 0) {
                    return this.roundedRect(xScaleIndividual(g.value.name), yScale(Math.max(0, g.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScale(g.value.value) - yScale(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
                }
                else {
                    return this.roundedRect(xScaleIndividual(g.value.name), yScale(Math.max(0, g.value.value)), xScaleIndividual.bandwidth(), Math.abs(yScale(g.value.value) - yScale(0)), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), 0, 0, this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))), this.getRoundCurve(xScaleIndividual.bandwidth() / 4, Math.abs(yScale(g.value.value) - yScale(0))));
                }
            }
        }))
            // .attr('x', (g) => xScaleIndividual(g.value.name))
            // .attr('y', (g) => {
            //   if (g.value.yAxisSecondary) {
            //     return yScaleSecondary(Math.max(0, g.value.value));
            //   } else {
            //     return yScale(Math.max(0, g.value.value));
            //   }
            // })
            // .attr('width', xScaleIndividual.bandwidth())
            // .attr('height', (g) => {
            //   if (g.value.yAxisSecondary) {
            //     return Math.abs(yScaleSecondary(g.value.value) - yScaleSecondary(0));
            //   } else {
            //     return Math.abs(yScale(g.value.value) - yScale(0));
            //   }
            // })
            .attr('fill', (/**
         * @param {?} g
         * @return {?}
         */
        (g) => {
            return g.value.color;
        }))
            .on('mouseenter', this.tip.show)
            .on('mouseout', this.tip.hide);
        /** @type {?} */
        const lineClass = 'line ' + this.chartId + '-line';
        /** @type {?} */
        const lineSelection = line()
            .x((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return xScaleGroup(d.category);
        }))
            .y((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (d.yAxisSecondary) {
                return yScaleSecondary(d.value);
            }
            else {
                return yScale(d.value);
            }
        }));
        /** @type {?} */
        const lineSelectionCurve = line()
            .x((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return xScaleGroup(d.category);
        }))
            .y((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (d.yAxisSecondary) {
                return yScaleSecondary(d.value);
            }
            else {
                return yScale(d.value);
            }
        }))
            .curve(curveCardinal);
        // curve = this.makeCurveLine(curve, lineSelection);
        /** @type {?} */
        const line$$1 = chart.append('g')
            .attr('class', 'line-group')
            .selectAll('g')
            // .append('g')
            .data(convertedLineData);
        // .enter();
        // .selectAll('g');
        line$$1
            .enter()
            .append('g')
            .attr('id', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return this.chartId + d[0].name;
        }))
            .attr('class', lineClass)
            // .style('opacity', 1)
            .attr('transform', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return 'translate(' + (xScaleGroup.bandwidth() / 2) + ',0)';
        }))
            // .selectAll('path')
            .append('path')
            .attr('d', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            if (d[0].lineDetails !== null && d[0].lineDetails.curve) {
                return lineSelectionCurve(d);
            }
            else {
                return lineSelection(d);
            }
        }))
            .attr('stroke', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return d[i].color;
        }))
            .attr('fill', 'none')
            .attr('stroke-width', 2)
            .attr('stroke-dasharray', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            // set the dasharray if condition null means no attr
            if (d[0].lineDetails !== null && d[0].lineDetails.dashed) {
                return (d[0].lineDetails.dashedWidth) ? d[0].lineDetails.dashedWidth : 5;
            }
            return null;
        }));
        chart.selectAll('g.line')
            .selectAll('circle')
            .data((/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.map((/**
             * @param {?} g
             * @param {?} i
             * @return {?}
             */
            (g, i) => {
                return {
                    key: i, value: {
                        value: g.value, color: g.color, name: g.name,
                        category: g.category, yAxisSecondary: g.yAxisSecondary, lineDetails: g.lineDetails
                    }
                };
            }));
        }))
            .enter()
            .append('svg:circle')
            .style('cursor', 'pointer')
            .attr('stroke', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.value.color;
        }))
            .attr('fill', (/**
         * @param {?} d
         * @return {?}
         */
        (d) => {
            return d.value.color;
        }))
            .attr('cx', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            return xScaleGroup(d.value.category);
        }))
            .attr('cy', (/**
         * @param {?} d
         * @param {?} i
         * @return {?}
         */
        (d, i) => {
            if (d.value.yAxisSecondary) {
                return yScaleSecondary(d.value.value);
            }
            else {
                return yScale(d.value.value);
            }
        }))
            .attr('stroke', '#FFFFFF')
            .attr('stroke-width', 2)
            .attr('r', 6)
            .on('mouseenter', this.tip.show)
            .on('mouseout', this.tip.hide);
    }
}
DualAxesBarLineChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'ndi-dual-axes-bar-line-chart',
                template: "<div [id]=\"chartId\" #chartContainer class=\"chart-wrapper\"></div>",
                styles: [""]
            }] }
];
/** @nocollapse */
DualAxesBarLineChartComponent.ctorParameters = () => [];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
class NdiChartMakerModule {
}
NdiChartMakerModule.decorators = [
    { type: NgModule, args: [{
                declarations: [
                    BarChartComponent,
                    LineChartComponent,
                    NdiChartComponent,
                    CombinedBarLineChartComponent,
                    CommonChartComponent,
                    WaterfallChartComponent,
                    StackedBarChartComponent,
                    DualAxesBarLineChartComponent,
                ],
                imports: [CommonModule],
                exports: [NdiChartComponent]
            },] }
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */

export { NdiChartMakerModule, NdiChartComponent, BarChartComponent as ɵa, CombinedBarLineChartComponent as ɵd, CommonChartComponent as ɵb, DualAxesBarLineChartComponent as ɵg, LineChartComponent as ɵc, StackedBarChartComponent as ɵf, WaterfallChartComponent as ɵe };

//# sourceMappingURL=ndi-chart-maker.js.map