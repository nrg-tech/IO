import { BarChartBaseModel } from '../../model/bar-chart-base.model';
import { CommonChartComponent } from '../common-chart/common-chart.component';
export declare class BarChartComponent extends CommonChartComponent {
    constructor();
    draw(chart: any, data: BarChartBaseModel, xScaleGroup: any, xScaleIndividual: any, yScale: any): any;
}
