import { CombinedBarLineBaseModel } from '../../model/combined-bar-line-chart-base.model';
import { CommonChartComponent } from '../common-chart/common-chart.component';
export declare class CombinedBarLineChartComponent extends CommonChartComponent {
    constructor();
    draw(chart: any, data: CombinedBarLineBaseModel, xScaleGroup: any, xScaleIndividual: any, yScale: any): void;
}
