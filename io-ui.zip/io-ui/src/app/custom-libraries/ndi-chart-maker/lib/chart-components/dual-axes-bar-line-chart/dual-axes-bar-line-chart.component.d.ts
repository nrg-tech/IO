import { CommonChartComponent } from '../common-chart/common-chart.component';
import { DualAxesBarLineChartModel } from '../../model/dual-axes-bar-line-base.model';
export declare class DualAxesBarLineChartComponent extends CommonChartComponent {
    constructor();
    draw(chart: any, data: DualAxesBarLineChartModel, xScaleGroup: any, xScaleIndividual: any, yScale: any, yScaleSecondary: any): void;
}
