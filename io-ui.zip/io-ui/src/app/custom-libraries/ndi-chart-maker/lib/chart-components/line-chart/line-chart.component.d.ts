import { ElementRef, OnInit, AfterViewInit } from '@angular/core';
import { LineChartBaseModel } from "../../model/line-chart-base.model";
import { MarginChartModel } from '../../model/margin-chart.model';
export declare class LineChartComponent implements OnInit, AfterViewInit {
    chartContainer: ElementRef;
    data: LineChartBaseModel;
    chartIdLine: string;
    min: number;
    max: number;
    width: number;
    height: number;
    margin: MarginChartModel;
    tip: any;
    constructor();
    ngOnInit(): void;
    ngAfterViewInit(): void;
    createId(): void;
    generateChart(data: LineChartBaseModel): void;
    clearChart(): void;
    private getMinMaxValue;
    private setMargin;
    setLeftMargin(max: number): void;
    setHeight(): void;
    generateLineChart(data: LineChartBaseModel): void;
    addToolTip(): void;
    private convertData;
}
