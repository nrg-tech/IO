import { CommonChartComponent } from '../common-chart/common-chart.component';
import { DataSetChartModel } from '../../model/data-set-chart.model';
import { StackedBarChartBaseModel } from '../../model/stacked-bar-chart-base.model';
export declare class StackedBarChartComponent extends CommonChartComponent {
    constructor();
    getMinMaxValueAndCount(dataSet: DataSetChartModel[]): void;
    convertDataInGroup(data: any, convertedData: any[], type?: string): void;
    draw(chart: any, data: StackedBarChartBaseModel, xScaleGroup: any, xScaleIndividual: any, yScale: any): any;
    convertToStack(): any;
}
