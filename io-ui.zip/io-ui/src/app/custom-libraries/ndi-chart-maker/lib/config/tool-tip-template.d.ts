export declare const tooltipTemplate: string;
