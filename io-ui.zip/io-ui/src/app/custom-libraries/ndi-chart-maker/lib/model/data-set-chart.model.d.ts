import { LineDetails } from './line-details.model';
export interface DataSetChartModel {
    name: string;
    data: Array<number>;
    offset?: Array<number>;
    color?: Array<string>;
    type?: string;
    lineDetails?: LineDetails;
    yAxisSecondary?: boolean;
}
