import { TitleChart } from './title-chart.model';
import { XAxisChartModel } from './xAxis-chart.model';
import { YAxisChartModel } from './yAxis-chart.model';
import { DataSetChartModel } from './data-set-chart.model';
import { OptionsChartModel } from './options-chart.model';
export interface DualAxesBarLineChartModel {
    title?: TitleChart;
    xAxis?: XAxisChartModel;
    yAxis?: YAxisChartModel;
    yAxisSecondary?: YAxisChartModel;
    dataSet: Array<DataSetChartModel>;
    options?: OptionsChartModel;
}
