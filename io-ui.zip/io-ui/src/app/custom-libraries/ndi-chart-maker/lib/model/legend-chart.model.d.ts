export interface LegendChartModel {
    show: boolean;
    interactive?: boolean;
}
