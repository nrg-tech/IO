export interface LineDetails {
    curve: boolean;
    dashed?: boolean;
    dashedWidth?: number;
}
