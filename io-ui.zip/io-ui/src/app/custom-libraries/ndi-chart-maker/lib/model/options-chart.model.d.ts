import { MarginChartModel } from './margin-chart.model';
import { LegendChartModel } from './legend-chart.model';
export interface OptionsChartModel {
    innerPadding?: number;
    outerPadding?: number;
    margin?: MarginChartModel;
    padding?: number;
    legend?: LegendChartModel;
}
