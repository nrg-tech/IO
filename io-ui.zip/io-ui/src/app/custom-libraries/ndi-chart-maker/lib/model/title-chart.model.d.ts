export interface TitleChart {
    text?: string;
    position?: string;
}
