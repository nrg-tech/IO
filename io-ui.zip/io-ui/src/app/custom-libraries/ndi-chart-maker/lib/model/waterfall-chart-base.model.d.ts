import { TitleChart } from './title-chart.model';
import { XAxisChartModel } from './xAxis-chart.model';
import { YAxisChartModel } from './yAxis-chart.model';
import { DataSetChartModel } from './data-set-chart.model';
import { OptionsChartModel } from './options-chart.model';
export interface WaterfallChartBaseModel {
    title?: TitleChart;
    xAxis?: XAxisChartModel;
    yAxis?: YAxisChartModel;
    dataSet: Array<DataSetChartModel>;
    options?: OptionsChartModel;
}
