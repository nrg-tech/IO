export interface XAxisChartModel {
    category?: Array<any>;
    text?: string;
    noOfTIcks?: number;
}
