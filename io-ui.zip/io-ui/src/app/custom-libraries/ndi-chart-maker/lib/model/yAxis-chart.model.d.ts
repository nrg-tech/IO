export interface YAxisChartModel {
    noOfTicks?: number;
    symbol?: string;
    symbolPosition?: string;
    text?: string;
}
