export declare class NdiChartMakerModule {
}
