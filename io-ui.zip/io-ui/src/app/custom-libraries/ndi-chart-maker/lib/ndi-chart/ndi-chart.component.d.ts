import { OnInit } from '@angular/core';
import { BarChartBaseModel } from '../model/bar-chart-base.model';
import { LineChartBaseModel } from '../model/line-chart-base.model';
import { CombinedBarLineBaseModel } from '../model/combined-bar-line-chart-base.model';
import { WaterfallChartBaseModel } from '../model/waterfall-chart-base.model';
import { StackedBarChartBaseModel } from '../model/stacked-bar-chart-base.model';
import { DualAxesBarLineChartModel } from '../model/dual-axes-bar-line-base.model';
export declare class NdiChartComponent implements OnInit {
    type: string;
    data: BarChartBaseModel | LineChartBaseModel | CombinedBarLineBaseModel | WaterfallChartBaseModel | StackedBarChartBaseModel | DualAxesBarLineChartModel;
    constructor();
    ngOnInit(): void;
}
