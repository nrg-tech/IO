import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AggregateStatsCardComponent } from './aggregate-stats-card.component';

describe('AggregateStatsCardComponent', () => {
  let component: AggregateStatsCardComponent;
  let fixture: ComponentFixture<AggregateStatsCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AggregateStatsCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AggregateStatsCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
