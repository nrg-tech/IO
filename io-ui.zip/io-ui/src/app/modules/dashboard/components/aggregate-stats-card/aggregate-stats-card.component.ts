import { Component, OnInit, Input } from '@angular/core';
import { AggregateStatsCardBase } from 'src/app/shared/interfaces/aggregate-stats-card';
@Component({
  selector: 'io-aggregate-stats-card',
  templateUrl: './aggregate-stats-card.component.html',
  styleUrls: ['./aggregate-stats-card.component.scss']
})
export class AggregateStatsCardComponent implements OnInit {

  @Input() aggregateStats: AggregateStatsCardBase;

  constructor() { }

  ngOnInit() {
  }

}
