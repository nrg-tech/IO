import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AggregateStatsCardsCollectionComponent } from './aggregate-stats-cards-collection.component';

describe('AggregateStatsCardsCollectionComponent', () => {
  let component: AggregateStatsCardsCollectionComponent;
  let fixture: ComponentFixture<AggregateStatsCardsCollectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AggregateStatsCardsCollectionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AggregateStatsCardsCollectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
