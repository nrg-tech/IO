import { Component, OnInit, OnDestroy } from '@angular/core';

// Interface
import { AggregateStatsCardBase, AggregateStatsCard } from 'src/app/shared/interfaces/aggregate-stats-card';

// Service
import { AggregateStatsCardsCollectionService } from './aggregate-stats-cards-collection.service';
import { AggregateStatsCardConfig } from 'src/app/configs/aggregate-stats-card-config';
import { Subscription } from 'rxjs';

@Component({
  selector: 'io-aggregate-stats-cards-collection',
  templateUrl: './aggregate-stats-cards-collection.component.html',
  styleUrls: ['./aggregate-stats-cards-collection.component.scss']
})
export class AggregateStatsCardsCollectionComponent implements OnInit, OnDestroy {

  aggregateBase: AggregateStatsCardBase[] = [];
  subscriptions: Subscription[] = [];
  aggregateStats: AggregateStatsCard;
  constructor(private agsService: AggregateStatsCardsCollectionService) { }

  ngOnInit() {
    this.getAggregateStatsData();
  }

  getAggregateStatsData() {
    this.subscriptions.push(this.agsService.getAggregateStats().subscribe((response: AggregateStatsCard) => {
      this.aggregateStats = response;
      this.perpareAggregateBase();
    }));
  }

  perpareAggregateBase() {
    const aggregateStats = this.aggregateStats;
    this.aggregateBase = AggregateStatsCardConfig.aggregateStatsBase;
    this.aggregateBase.forEach(aggregateObj => {
      if (aggregateObj.valueId) {
        aggregateObj.value = aggregateStats[aggregateObj.valueId];
      }
      if (aggregateObj.differenceId) {
        aggregateObj.difference = aggregateStats[aggregateObj.differenceId];
      }
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
  }
}
