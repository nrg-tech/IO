import { TestBed } from '@angular/core/testing';

import { AggregateStatsCardsCollectionService } from './aggregate-stats-cards-collection.service';

describe('AggregateStatsCardsCollectionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AggregateStatsCardsCollectionService = TestBed.get(AggregateStatsCardsCollectionService);
    expect(service).toBeTruthy();
  });
});
