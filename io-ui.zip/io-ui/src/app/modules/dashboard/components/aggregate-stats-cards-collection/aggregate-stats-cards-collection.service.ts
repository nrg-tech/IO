import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http-service/http.service';
import { apiEndPoints } from 'src/app/configs/api-end-points';
import { Observable } from 'rxjs';
import { AggregateStatsCard } from 'src/app/shared/interfaces/aggregate-stats-card';

@Injectable({
  providedIn: 'root'
})
export class AggregateStatsCardsCollectionService {

  constructor(private httpService: HttpService) { }

  getAggregateStats(): Observable<AggregateStatsCard> {
    return this.httpService.get(apiEndPoints.aggregateStats);
  }
}
