import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { DashboardReportConfig } from 'src/app/configs/dashboard-report-config';
import { DashboardService } from './dashboard.service';
import { TopPartsStatsOverview, TopPartsStatsDVC, TopPartsStatsSVC } from 'src/app/shared/interfaces/top-parts-stats';
import { Subscription } from 'rxjs';

@Component({
  selector: 'io-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit, OnDestroy {

  chartBreadcrumbs: string[] = ['Overview'];
  subscriptions: Subscription[] = [];
  allPartsUrl = 'inventory-output/latest-run';
  details: any[];
  constructor(
    private router: Router,
    private dashboardService: DashboardService,
    ) { }

  ngOnInit() {
    this.details = DashboardReportConfig.details;
    this.callDefaultChart();
  }

  gotoAllParts() {
    this.router.navigateByUrl(this.allPartsUrl);
  }

  switchChart(detailId: string) {
    let detailName: string;
    this.details.forEach(detail => {
      if (detail.id === detailId) {
        detail.show = true;
        detailName = detail.name;
      } else {
        detail.show = false;
      }
    });
    if (!this.chartBreadcrumbs.includes(detailName)) {
      this.chartBreadcrumbs.push(detailName);
    }
    this.callService(detailId);
  }

  callService(detailId: string) {
    this.subscriptions.push(this.dashboardService.getChartData(detailId).subscribe
      ((response: TopPartsStatsOverview[] | TopPartsStatsDVC[] | TopPartsStatsSVC[]) => {
        this.convertResponseToChartData(detailId, response);
    }));
  }

  gotoParent() {
    let parentDetailId: string;
    this.details.forEach(detail => {
      if (detail.name === this.chartBreadcrumbs[this.chartBreadcrumbs.length - 1 ]) {
        this.chartBreadcrumbs.pop();
      }
      if (detail.name === this.chartBreadcrumbs[0]) {
        parentDetailId = detail.id;
      }
    });
    this.switchChart(parentDetailId);
  }

  callDefaultChart() {
    let parentDetailId;
    this.details.forEach(detail => {
      if (detail.name === this.chartBreadcrumbs[0]) {
        parentDetailId = detail.id;
        detail.show = true;
      } else {
        detail.show = false;
      }
    });
    this.callService(parentDetailId);
  }

  convertResponseToChartData(detailId: string, response: any[]) {
    this.details.forEach(detail => {
      if (detail.id  === detailId) {
        if (detailId === 'dashboardOverview') {
          detail.chartData.xAxis.category = [];
          detail.chartData.dataSet[0].data = [];
          detail.chartData.dataSet[1].data = [];
          detail.chartData.dataSet[1].offset = [];
          detail.chartData.dataSet[2].data = [];
          response.forEach((res: TopPartsStatsOverview) => {
            detail.chartData.xAxis.category.push(res.itemNumber);
            detail.chartData.dataSet[0].data.push(res.currentFloat);
            detail.chartData.dataSet[1].data.push(res.floatSurplus);
            detail.chartData.dataSet[1].offset.push(res.recommendedFloat);
            detail.chartData.dataSet[2].data.push(res.recommendedFloat);
          });
        } else if (detailId === 'dashboardDVC') {
          detail.chartData.xAxis.category = [];
          detail.chartData.dataSet[0].data = [];
          detail.chartData.dataSet[1].data = [];
          response.forEach((res: TopPartsStatsDVC) => {
            detail.chartData.xAxis.category.push(res.itemNumber);
            detail.chartData.dataSet[0].data.push(res.averageDailyDemand);
            detail.chartData.dataSet[1].data.push(res.coefVariableDailyDemand);
          });

        } else {
          detail.chartData.xAxis.category = [];
          detail.chartData.dataSet[0].data = [];
          detail.chartData.dataSet[1].data = [];
          response.forEach((res: TopPartsStatsSVC) => {
            detail.chartData.xAxis.category.push(res.itemNumber);
            detail.chartData.dataSet[0].data.push(res.averageSupplyCycleTime);
            detail.chartData.dataSet[1].data.push(res.coefVariableSupplyCycleTime);
          });
        }
      }
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
  }

}
