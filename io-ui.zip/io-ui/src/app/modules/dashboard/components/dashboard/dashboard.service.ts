import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpService } from 'src/app/core/services/http-service/http.service';
import { apiEndPoints } from 'src/app/configs/api-end-points';
import { TopPartsStatsOverview, TopPartsStatsDVC, TopPartsStatsSVC } from 'src/app/shared/interfaces/top-parts-stats';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private httpService: HttpService) { }

  getChartData(endpoint: string): Observable<TopPartsStatsOverview[] | TopPartsStatsDVC[] | TopPartsStatsSVC[]> {
    return this.httpService.get(apiEndPoints[endpoint]);
  }
}
