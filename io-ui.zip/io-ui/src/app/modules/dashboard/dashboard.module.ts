import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Module imports
import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardMaterialModule } from './modules/dashboard-material/dashboard-material.module';
import { NdiChartMakerModule } from 'ndi-chart-maker';
import { LegendModule } from '../../shared/modules/legend.module';

// Component imports
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AggregateStatsCardComponent } from './components/aggregate-stats-card/aggregate-stats-card.component';
// tslint:disable-next-line:max-line-length
import { AggregateStatsCardsCollectionComponent } from './components/aggregate-stats-cards-collection/aggregate-stats-cards-collection.component';

// Pipe imports
import { NumberSuffixPipe } from './pipes/number-suffix.pipe';



@NgModule({
  declarations: [
    DashboardComponent,
    AggregateStatsCardComponent,
    AggregateStatsCardsCollectionComponent,
    NumberSuffixPipe,
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    DashboardMaterialModule,
    NdiChartMakerModule,
    LegendModule,
  ]
})
export class DashboardModule { }
