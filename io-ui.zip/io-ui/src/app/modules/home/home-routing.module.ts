import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppPreloadingStrategy } from 'src/app/app-routing-preloader';

// Component imports
import { HomeComponent } from './components/home/home-component.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
      {
        path: '',
        loadChildren: '../dashboard/dashboard.module#DashboardModule',
        data: {
          preload: true,
          delay: false,
        },
      },
      {
        path: 'inventory-output',
        data: {
          breadcrumb: 'Inventory Output',
        },
        children: [
          {
            path: 'latest-run',
            loadChildren: '../last-run/last-run.module#LastRunModule',
            data : {
              preload: true,
              delay: false,
            }
          },
          {
            path: 'schedule-run',
            loadChildren: '../schedule-run/schedule-run.module#ScheduleRunModule',
            data : {
              preload: true,
              delay: false,
            }
          },
        ]
      },
      {
        path: 'reports',
        loadChildren: '../reports/reports.module#ReportsModule',
        data: {
          preload: true,
          delay: false,
        },
      },
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [AppPreloadingStrategy]
})
export class HomeRoutingModule { }
