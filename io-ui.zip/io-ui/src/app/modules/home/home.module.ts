import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Module imports
import { HomeRoutingModule } from './home-routing.module';
import { CoreModule } from '../../core/core.module';

// Component imports
import { HomeComponent } from './components/home/home-component.component';

@NgModule({
  declarations: [
    HomeComponent,
  ],
  imports: [
    CommonModule,
    HomeRoutingModule,
    CoreModule,
  ],
  exports: [
    CoreModule,
    HomeComponent,
  ]
})
export class HomeModule { }
