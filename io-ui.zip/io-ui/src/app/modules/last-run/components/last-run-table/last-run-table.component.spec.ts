import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LastRunTableComponent } from './last-run-table.component';

describe('LastRunTableComponent', () => {
  let component: LastRunTableComponent;
  let fixture: ComponentFixture<LastRunTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LastRunTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LastRunTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
