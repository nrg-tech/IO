import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { LastRunTableModel } from '../../models/last-run-table-model';
import { lastRunTableConstants } from '../../constants/last-run-table-constants';
import { Subscription } from 'rxjs';
import { EventListenerService } from 'src/app/shared/services/event-listener/event-listener.service';
import { Runtime } from 'src/app/shared/interfaces/runtime';

@Component({
  selector: 'io-last-run-table',
  templateUrl: './last-run-table.component.html',
  styleUrls: ['./last-run-table.component.scss']
})
export class LastRunTableComponent implements OnInit, OnDestroy {
  @Input() lastRunModels: LastRunTableModel[];
  @Input() pageSize: number; // number of rows to be displayed

  displayedColumns: string[];
  tableConstants: {};
  subscriptions: Subscription[] = [];
  timeZone: string;
  constructor(private eventListenerService: EventListenerService) { }

  ngOnInit() {
    this.tableConstants = lastRunTableConstants;
    this.displayedColumns = Object.keys(this.lastRunModels[0]);
    this.subscriptions.push(this.eventListenerService.runtimeDetail.subscribe((runtimeDetail: Runtime) => {
      this.timeZone = runtimeDetail.timeZone;
    }));
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
  }

}
