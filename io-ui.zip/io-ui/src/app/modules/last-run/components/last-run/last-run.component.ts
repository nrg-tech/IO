import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FilterModel } from '../../../../shared/models/filter-model';
import { LastRunService } from './last-run.service';
import { LastRunTableModel } from '../../models/last-run-table-model';
import { FilterType } from '../../../../shared/enums/filter-type-enum';
import { PageEvent } from '@angular/material/paginator';
import { Subscription } from 'rxjs';
import { MatMenuTrigger } from '@angular/material';

@Component({
  selector: 'io-last-run',
  templateUrl: './last-run.component.html',
  styleUrls: ['./last-run.component.scss']
})
export class LastRunComponent implements OnInit, OnDestroy {
  @ViewChild('reportMenuTrigger') reportMenuTrigger: MatMenuTrigger;
  @ViewChild('filterMenuTrigger') filterMenuTrigger: MatMenuTrigger;
  subscriptions: Subscription[] = [];
  isClearFilterSelected = false;
  filterModel: FilterModel = new FilterModel();
  lastRunTable: LastRunTableModel[];
  initialLastRunTabledata: LastRunTableModel[];
  loading = true;
  lastrunSize: number;
  pageSizeOptions = [15, 20, 30];
  selectedPageSize = 20;

  constructor(private lastRunService: LastRunService) { }

  ngOnInit() {
    this.getLastRunTable();
  }

  closeMenu(event: string) {
    if (event === 'downloadReport') {
      this.reportMenuTrigger.closeMenu();
    }
  }

  handleFilterItemSelection(event: any) {
    switch (event.filterType) {
      case FilterType.PARTS_CONTROLLER:
        this.filterModel.partsController = event.selectedList;
        break;
      case FilterType.SUPPLIER:
        this.filterModel.supplier = event.selectedList;
        break;
      case FilterType.CATEGORY:
        this.filterModel.category = event.selectedList;
        break;
      // case FilterType.LOCATION:
      //   this.filterModel.location = event.selectedList;
      //   break;
      case FilterType.PARTS_FLOW:
        this.filterModel.partsFlow = event.selectedList;
        break;
    }
  }

  getLastRunTable() {
    setTimeout(() => {
      this.subscriptions.push(this.lastRunService.getLastRunTable().subscribe(data => {
        this.initialLastRunTabledata = data;
        this.lastrunSize = data.length;
        this.lastRunTable = data.slice(0, this.selectedPageSize);
        this.toggleLoading();
      }));
    }, 500);
  }
  toggleLoading() {
    const tableSection = document.querySelector('.tabular-section') as HTMLElement;
    if (this.loading) {
      tableSection.style.height = 'auto';
      tableSection.style.maxHeight = '90%';
    } else {
      tableSection.style.height = '90%';
    }
    this.loading = !this.loading;
  }

  applyFilterClicked() {
    this.lastRunTable = this.initialLastRunTabledata.filter(model => {

      // return (
      //      this.filterModel.partsController
      //        .some(item => item.name === model.partsController) &&
      //     this.filterModel.supplier
      //       .some(item => item.name === model.supplierCode) &&
      //     this.filterModel.category
      //       .some(item => item.name === model.partsCategory)
      //       &&
      //    this.filterModel.partsFlow.
      //    some(item => item.name === model.partTypeCode)
      //   );

      return (
        (this.filterModel.partsController
          .map(item => item.name)
          .includes(model.partsController) || this.filterModel.partsController.length === 0) &&
        (this.filterModel.supplier
          .map(item => item.name)
          .includes(model.supplierCode) || this.filterModel.supplier.length === 0) &&
        (this.filterModel.category
          .map(item => item.name)
          .includes(model.partsCategory) || this.filterModel.category.length === 0) &&
        (this.filterModel.partsFlow
          .map(item => item.name)
          .includes(model.partTypeCode) || this.filterModel.partsFlow.length === 0)

      );

    });

  }

  clearFilterClicked() {
    this.filterModel = new FilterModel();
    this.isClearFilterSelected = true;
    setTimeout(() => {
      // resetting clear filter selected to false
      this.isClearFilterSelected = false;
    }, 5000);
  }

  getFilterTypes(): Array<number> {
    const enumKeys = Object.keys(FilterType);
    const enumKeysString = enumKeys.slice(0, enumKeys.length);
    const enumValues = enumKeysString.map(value => {
      return +value;
    });
    return enumValues;
  }

  onPaginateChange(event: PageEvent) {
    this.toggleLoading();
    this.selectedPageSize = event.pageSize;
    const slicePage = event.pageIndex * event.pageSize;
    const allData = Object.assign([], this.initialLastRunTabledata);
    this.lastRunTable = Object.assign([], allData.slice(slicePage, this.selectedPageSize + slicePage));
    this.toggleLoading();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription: Subscription) => {
      subscription.unsubscribe();
    });
  }

}
