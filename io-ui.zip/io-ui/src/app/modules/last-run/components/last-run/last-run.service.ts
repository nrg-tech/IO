import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { apiEndPoints } from 'src/app/configs/api-end-points';
import { LastRunTableModel } from '../../models/last-run-table-model';
import { HttpService } from 'src/app/core/services/http-service/http.service';
import { environment } from 'src/environments/environment';
import { LastRunMockConfig } from 'src/app/configs/mock/last-run-mock-config';

@Injectable({
  providedIn: 'root'
})
export class LastRunService {

  constructor(private httpService: HttpService) { }

  public getLastRunTable(): Observable<LastRunTableModel[]> {
    if (environment.mock) {
      const lastRunData = new LastRunMockConfig();
      return of(lastRunData.lastRunTableRows);
    } else {
    return this.httpService.get(apiEndPoints.getLastRunTable, []);
    }
  }
}
