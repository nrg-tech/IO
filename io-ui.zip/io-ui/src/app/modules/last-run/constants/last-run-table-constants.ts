export const lastRunTableConstants = {
    frozenColumns: [
        {
            label: 'Item Number',
            key: 'itemNumber',
            sticky: 'true'
        },
        {
            label: 'Service Level',
            key: 'serviceLevel',
            sticky: 'true'
        },
        {
            label: '% Change(Recom Float Value)',
            key: 'changePercentageRecommendedFloatValue',
            sticky: 'true'
        }
        /* {
         label: 'Plant Code',
         key: 'plantCode',
         sticky: 'true'
         },
         {
             label: 'Parts Category',
             key: 'partsCategory',
             sticky: 'true'
         },
         {
             label: 'Parts Controller',
             key: 'partsController',
             sticky: 'true'
         }*/
        /*   {
               label: 'Item Number',
               key: 'itemNumber',
               sticky: 'true'
           },
           {
               label: 'Unit Price',
               key: 'unitPrice',
               sticky: 'true'
           },
           {
               label: 'Supplier Type',
               key: 'supplierType',
               sticky: 'true'
           }*/
    ],

    columns: [
        // {
        //     label: 'Item Number',
        //     key: 'itemNumber'

        // },
        // {
        //     label: 'Unit Price',
        //     key: 'unitPrice'

        // },
        // {
        //     label: 'Supplier Type',
        //     key: 'supplierType'


        // },
        {
            label: 'Model Execution Date',
            key: 'modelExecutionDate',
            type: 'date'
        },

        {
            label: 'Unit Price',
            key: 'unitPrice'
        },
        {
            label: 'Supplier Type',
            key: 'supplierType'

        },
        {
            label: 'Supplier Code',
            key: 'supplierCode'
        },

        {
            label: 'Baseline Inventory Qty',
            key: 'baselineInventoryQuantity'
        },
        {
            label: 'Baseline Inventory Value',
            key: 'baselineInventoryValue'
        },


        {
            label: 'ABC Class by Inventory Value',
            key: 'abcClassInventoryValue'
        },
        {
            label: 'ABC Class by Consumption Value',
            key: 'abcClassConsumptionValue'
        },
        {
            label: 'XYZ Class by Demand CoV',
            key: 'xyzClassCoefficientOfVarianceDemandForecast'
        },

        {
            label: 'Min RAN Qty',
            key: 'minimumRanOrderQuantity'
        },

        {
            label: 'SNQ Qty',
            key: 'snqQuantity'
        },
        {
            label: 'Float recommended(days)',
            key: 'floatRecommendedDays'
        },
        {
            label: 'Op Reserve Qty',
            key: 'operationalReserveQuantity'
        },
        {
            label: 'Op Reserve Value',
            key: 'operationalReserveValue'
        },

        {
            label: 'Direct Pipeline Stock Qty',
            key: 'directPipelineStockQuantity'
        },
        {
            label: 'ILC Pipeline Stock Qty',
            key: 'ilcPipelineStockQuantity'
        },
        {
            label:
                'Scrap(% of Tot Ann Dem aft OM)',
            key: 'scrapPercentageToAnnualDemand'
        },
        {
            label: 'CL(% of Tot Ann Dem aft OM)',
            key: 'cycleLossPercentageTotalAnnualDemand'
        },
        {
            label: 'Total Recom Float(hrs)',
            key: 'totalRecommendedFloatHours'
        },
        {
            label: 'Total Recom Float(days)',
            key: 'totalRecommendedFloatDays'
        },
        {
            label: 'Float Inventory Savings($)',
            key: 'floatInventorySavings'
        },
        {
            label: 'Min Recom Float(hrs)',
            key: 'minimumRecommendedFloatHours'
        },
        {
            label: 'Min Recom Float(days)',
            key: 'minimumRecommendedFloatDays'
        },
        {
            label: 'Min Float Qty',
            key: 'minimumFloatQuantity'
        },
        {
            label: 'Plant Code',
            key: 'plantCode'
        },
        {
            label: 'Parts Category',
            key: 'partsCategory'
        },
        {
            label: 'Parts Controller',
            key: 'partsController'
        },
        {
            label: 'Part Type Code',
            key: 'partTypeCode'
        }

    ]
};
