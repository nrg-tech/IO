import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LastRunComponent } from './components/last-run/last-run.component';

const routes: Routes = [
  {
    path: '',
    component: LastRunComponent,
    data: {
      breadcrumb: 'Latest Run',
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LastRunRoutingModule {}
