import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Components import
import { LastRunComponent } from './components/last-run/last-run.component';
import { LastRunTableComponent } from './components/last-run-table/last-run-table.component';

// Module import
import { LastRunRoutingModule } from './last-run-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PrimeNgModule } from '../../shared/prime-ng/prime-ng.module';
import { FilterModule } from '../../shared/modules/filter.module';
import { ReportDownloadModule } from '../../shared/modules/report-download.module';
import { LastRunMaterialModule } from './last-run-material/last-run-material.module';
import { MatPaginatorModule } from '@angular/material/paginator';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';

@NgModule({
  declarations: [
    LastRunComponent,
    LastRunTableComponent,
  ],
  imports: [
    CommonModule,
    LastRunRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    LastRunMaterialModule,
    PrimeNgModule,
    FilterModule,
    ReportDownloadModule,
    MatPaginatorModule,
    NgxSkeletonLoaderModule,
  ],
  exports: [
    LastRunComponent,
  ]
})
export class LastRunModule { }
