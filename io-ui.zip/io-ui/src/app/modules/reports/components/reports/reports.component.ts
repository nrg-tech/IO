import { Component, OnInit, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { ReportsConfig } from 'src/app/configs/reports-config';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { MatAutocompleteSelectedEvent, MatChipInputEvent } from '@angular/material';
import { PartsReport, PartSelected } from 'src/app/shared/interfaces/parts-report';

@Component({
  selector: 'io-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
  @ViewChild('searchInput') searchInput: ElementRef<HTMLInputElement>;
  reportTypes: string[];
  parts: string[];
  selectedReportType: string;
  selectedPartCategory: string;
  selectedParts: PartSelected[] = [];
  allParts: PartsReport[] = [];
  searchControl = new FormControl();
  filteredParts: Observable<PartsReport[]>;
  isShowAllPartsSelected = false;
  partListChipWidth: number;
  remainingPartChipWidth: number;
  outsideChipCount = 0;
  showExtraChip = false;
  constructor() {}

  ngOnInit() {
    this.reportTypes = ReportsConfig.reportTypes;
    this.selectedReportType = this.reportTypes[0];
    this.parts = ReportsConfig.parts;
    this.selectedPartCategory = ReportsConfig.parts[0];
    this.allParts = [
      {
        partNumber: 'One111728'
      },
      {
        partNumber: 'Two'
      },
      {
        partNumber: 'Three'
      },
      {
        partNumber: 'rtuy'
      },
      {
        partNumber: 'iuyiasaus'
      },
      {
        partNumber: 'aksjkaasdasdascas'
      },
      {
        partNumber: 'asdaascascc'
      },
      {
        partNumber: 'Twoascas'
      },
      {
        partNumber: 'Threascasase'
      },
      {
        partNumber: 'kjhaskjcasjcn'
      },
      {
        partNumber: 'alsjcla'
      },
    ];
    this.filteredParts = this.searchControl.valueChanges
      .pipe(
        startWith(''),
        map(value => this._filter(value))
      );
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;
    const index = this.indexOfIgnoreCase(this.allParts, value);
    if ((value || '').trim() && index > -1) {
      const partSelected: PartSelected = {
        partNumber: value.trim(),
        isAdded: false
      };
      this.selectedParts.push(partSelected);
      setTimeout(() => {
        this.calculateDynamicWidth(value.trim());
      }, 0);
      this.allParts[index].isSelected = true;
    }
    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.searchControl.setValue('');
  }

  remove(part: PartSelected): void {
    const partNumber = part.partNumber;
    const index = this.indexOfIgnoreCase(this.selectedParts, partNumber);
    if (index >= 0) {
      this.selectedParts.splice(index, 1);
      if (index < this.outsideChipCount) {
        const partChipElement = document.getElementById(partNumber);
        const chipWidth = partChipElement.getBoundingClientRect().width;
        this.remainingPartChipWidth += chipWidth;
        this.outsideChipCount--;
        this.selectedParts.slice(this.outsideChipCount).forEach(selectedPart => {
          this.calculateDynamicWidth(selectedPart.partNumber, true);
        });
      }
      if (this.selectedParts.length === this.outsideChipCount) {
        this.showExtraChip = false;
      }
    }
    const indexAllParts = this.indexOfIgnoreCase(this.allParts, partNumber);
    this.allParts[indexAllParts].isSelected = false;
  }

  searchSelected(event: MatAutocompleteSelectedEvent): void {
    const partNumberSelected = event.option.viewValue;
    const selectedPart: PartSelected = {
      partNumber: partNumberSelected,
      isAdded: false
    };
    this.selectedParts.push(selectedPart);
    const index = this.indexOfIgnoreCase(this.allParts, selectedPart.partNumber);
    this.allParts[index].isSelected = true;
    this.searchInput.nativeElement.value = '';
    this.searchControl.setValue('');
    this.searchInput.nativeElement.blur();
    setTimeout(() => {
      this.calculateDynamicWidth(partNumberSelected);
    }, 0);
  }

  showAllPartsSelected() {
    this.isShowAllPartsSelected = !this.isShowAllPartsSelected;
  }

  getInitialPartListChipWidth() {
    if (!this.partListChipWidth) {
      const node = document.querySelector('.part-list');
      this.partListChipWidth = node.getBoundingClientRect().width;
      this.remainingPartChipWidth = this.partListChipWidth;
    }
  }

  calculateDynamicWidth(partNumber: string, removeFlag?: boolean) {
    const partChipElement = document.getElementById(partNumber);
    let siblingCondition = true;
    const previousSibling = partChipElement.previousElementSibling;
    if (previousSibling !== null) {
      siblingCondition = previousSibling.classList.contains('overlayed-part');
      if (removeFlag && !siblingCondition) {
        siblingCondition = !siblingCondition;
      }
    }
    const chipWidth = partChipElement.getBoundingClientRect().width;
    if (chipWidth < this.remainingPartChipWidth && (siblingCondition || !this.showExtraChip)) {
      const index = this.indexOfIgnoreCase(this.selectedParts, partNumber);
      this.selectedParts[index].isAdded = true;
      this.remainingPartChipWidth -= chipWidth;
      this.outsideChipCount++;
    } else {
      this.showExtraChip = true;
      // partChipElement.remove();
    }
  }
  removeAllParts() {
    this.selectedParts = [];
    this.showExtraChip = false;
    this.isShowAllPartsSelected = false;
    this.outsideChipCount = 0;
    this.remainingPartChipWidth = this.partListChipWidth;
    this.allParts.forEach(part => {
      part.isSelected = false;
    });
  }

  indexOfIgnoreCase(arr: any[], value: any) {
    const lowerArr = arr.map((item) => {
        return item.partNumber.toLowerCase();
    });
    return lowerArr.indexOf(value.toLowerCase());
  }

  private _filter(value: string): PartsReport[] {
    const filterValue = value.toLowerCase();
    return this.allParts.filter(part => part.partNumber.toLowerCase().includes(filterValue));
  }

}
