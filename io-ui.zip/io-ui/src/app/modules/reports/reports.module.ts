import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Module Imports
import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsMaterialModule } from './reports-material/reports-material.module';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';

// Component Imports
import { ReportsComponent } from './components/reports/reports.component';

@NgModule({
  declarations: [
    ReportsComponent,
  ],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    ReportsMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    NgxSkeletonLoaderModule,
  ]
})
export class ReportsModule { }
