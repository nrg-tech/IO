import { Component, OnInit, Input} from '@angular/core';
import { ScheduleRunService } from '../schedule-run/schedule-run.service';
import { DatePipe } from '@angular/common';
import { Offset } from '../../models/schedule-run-offset';
import { SinglePartOffsetModel } from '../../models/single-part-offset-model';
import { scheduleRunConstants } from '../../constants/schedule-run-constants';
import { EventListenerService } from 'src/app/shared/services/event-listener/event-listener.service';

@Component({
  selector: 'io-edit-menu',
  templateUrl: './edit-menu.component.html',
  styleUrls: ['./edit-menu.component.scss']
})

export class EditMenuComponent implements OnInit {
  @Input() offsetData: Offset;
  @Input() partId: number;

  constructor(private scheduleRunService: ScheduleRunService, private eventListenerService: EventListenerService) { }

  ngOnInit() {
    this.initialiseData();
  }

  initialiseData() {

    // if (this.offsetData !== undefined && this.offsetData !== null) {
    //   this.offsetValue = this.offsetDetails.offsetValue;
    //   this.startDate = this.convertDateStringToDate(this.offsetDetails.offsetStartDate);
    //   this.endDate = this.convertDateStringToDate(this.offsetDetails.offsetEndDate);
    // }

    // this.eventListenerService.currentPlantId.subscribe(currentPlantId => {
    //   this.plantId = currentPlantId;
    // });
  }

  updateButtonClicked() {
    // const updatedOffsetDetails = this.offsetDetails;
    // updatedOffsetDetails.offsetValue = this.offsetValue;
    // this.singlePartOffsetDetails.offset = updatedOffsetDetails;
    // // this.singlePartOffsetDetails.plantId = this.plantId;
    // this.singlePartOffsetDetails.plantId = this.plantId ? this.plantId : 2;
    // this.singlePartOffsetDetails.userId = 1011;
    // delete this.singlePartOffsetDetails.sl; // delete sl key from update api request body

    // if (this.validateData()) {
    //   const datePipe = new DatePipe('en-US');
    //   updatedOffsetDetails.offsetStartDate = datePipe.transform(this.startDate, 'yyyy-MM-dd');
    //   updatedOffsetDetails.offsetEndDate = datePipe.transform(this.endDate, 'yyyy-MM-dd');
    //   this.scheduleRunService.updateSinglePartOffset(this.singlePartOffsetDetails).subscribe(data => {
    //   });
    // }
  }

  resetButtonClicked() {
    this.initialiseData();
  }

  // validateData(): boolean {
  //   let isDataValidated = false;
  //   let errorMessage = '';
  //   switch (true) {
  //     case this.singlePartOffsetDetails.partId === null:
  //       errorMessage = scheduleRunConstants.errorMessages.partIdNotAvailable;
  //       break;
  //     case this.startDate === null:
  //       errorMessage = scheduleRunConstants.errorMessages.offsetStartDateEmpty;
  //       break;
  //     case this.endDate === null:
  //       errorMessage = scheduleRunConstants.errorMessages.offsetEndDateEmpty;
  //       break;
  //     default:
  //       isDataValidated = true;
  //   }
  //   if (!isDataValidated) {
  //     console.log(errorMessage);
  //   }
  //   return isDataValidated;
  // }
}
