import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleRunTableComponent } from './schedule-run-table.component';

describe('TableViewComponent', () => {
  let component: ScheduleRunTableComponent;
  let fixture: ComponentFixture<ScheduleRunTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScheduleRunTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleRunTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
