import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { scheduleRunConstants } from '../../constants/schedule-run-constants';
import { ScheduleRunRow } from '../../models/scheduleRunRow';
import { Offset } from '../../models/schedule-run-offset';
import { ScheduleRunMockConfig } from 'src/app/configs/mock/schedule-run-mock-config';
import { SinglePartOffsetModel } from '../../models/single-part-offset-model';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
  selector: 'io-schedule-run-table',
  templateUrl: './schedule-run-table.component.html',
  styleUrls: ['./schedule-run-table.component.scss']
})
export class ScheduleRunTableComponent implements OnInit {

  @Input() scheduleRunTableOffsets: Offset[];
  @Input() data: ScheduleRunRow[] = [];

  frozenColumns = scheduleRunConstants.frozenColumns;
  displayedColumns = scheduleRunConstants.tableColumns;
  selectedPartIds: number[] = [];
  selectedItemNumbers: string[] = [];
  initialSelection = [];
  allowMultiSelect = true;
  selection: SelectionModel<ScheduleRunRow>;

  constructor() { }

  ngOnInit() {
    this.scheduleRunTableOffsets.map(offset => {
      this.frozenColumns[1].children.push({label: offset.offsetName, key: offset.offsetId});
    });
    this.data = ScheduleRunMockConfig.tableRows;
    this.selection = new SelectionModel<ScheduleRunRow>(this.allowMultiSelect, this.initialSelection);
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.data.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
    } else {
      this.data.forEach(row => this.selection.select(row));
    }
  }

  getPartsSelected() {
    this.selectedPartIds = this.selection.selected.map(item => item.partId);
    this.selectedItemNumbers = this.selection.selected.map(item => item.itemNumber);
    return {selectedItemNumbers: this.selectedItemNumbers, selectedPartIds: this.selectedPartIds};
  }
}
