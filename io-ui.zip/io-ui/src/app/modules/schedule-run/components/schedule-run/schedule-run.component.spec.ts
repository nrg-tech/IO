import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ScheduleRunComponent } from './schedule-run.component';

describe('ScheduleRunComponent', () => {
  let component: ScheduleRunComponent;
  let fixture: ComponentFixture<ScheduleRunComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ScheduleRunComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ScheduleRunComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
