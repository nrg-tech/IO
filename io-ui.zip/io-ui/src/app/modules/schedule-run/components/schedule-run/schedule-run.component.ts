import { Component, OnInit, ViewChild } from '@angular/core';
import { ExcelService } from 'src/app/shared/services/export/excel.service';
import { FilterType } from 'src/app/shared/enums/filter-type-enum';
import { ScheduleRunRow } from '../../models/scheduleRunRow';
import { ScheduleRunService } from './schedule-run.service';
import { scheduleRunConstants } from '../../constants/schedule-run-constants';
import { Offset } from '../../models/schedule-run-offset';
import { FilterModel } from 'src/app/shared/models/filter-model';
import { ScheduleRunTableComponent } from '../schedule-run-table/schedule-run-table.component';
import { EventListenerService } from 'src/app/shared/services/event-listener/event-listener.service';

@Component({
  selector: 'io-schedule-run',
  templateUrl: './schedule-run.component.html',
  styleUrls: ['./schedule-run.component.scss']
})
export class ScheduleRunComponent implements OnInit {
  @ViewChild('scheduleRunTableComponent') scheduleRunTableComponent: ScheduleRunTableComponent;

  isSidebarVisible = false;
  isClearFilterSelected = false;
  reportDownloadOption = 'all';
  selectedDate: Date = new Date();
  currentDate: Date = new Date();
  filterModel: FilterModel = new FilterModel();
  scheduleRunTableData: ScheduleRunRow[] = [];
  scheduleRunTableOffsets: Offset[] = [];
  selectedPartIds: number[] = [];
  selectedItemNumbers: string[] = [];

  constructor(private excelService: ExcelService, private scheduleRunService: ScheduleRunService,
              private eventListenerService: EventListenerService) { }

  ngOnInit() {
    this.getScheduleRunTableOffsets();
    this.getScheduleRunTable();
  }

  closeSidebar() {
    this.isSidebarVisible = false;
  }

  getScheduleRunTableOffsets() {
    this.scheduleRunService.getScheduleRunOffsets().subscribe(data => {
      this.scheduleRunTableOffsets = data;
    });
  }

  getScheduleRunTable() {
    this.scheduleRunService.getScheduleRunTable(this.selectedDate, this.getPlantId()).subscribe(data => {
      this.scheduleRunTableData = data;
    });
  }

  generateSpreadsheet() {
    this.excelService.exportAsExcelFile(this.scheduleRunTableData, scheduleRunConstants.tableColumns, 'Schedule Run', 'Schedule Run');
  }

  getFilterTypes(): Array<number> {
    const enumKeys = Object.keys(FilterType);
    const enumKeysString = enumKeys.slice(0, enumKeys.length / 2);
    const enumValues = enumKeysString.map(value => {
      return +value;
    });
    return enumValues;
  }

  handleFilterItemSelection(event: any) {
    switch (event.filterType) {
      case FilterType.PARTS_CONTROLLER:
        this.filterModel.partsController = event.selectedList;
        break;
      case FilterType.SUPPLIER:
        this.filterModel.supplier = event.selectedList;
        break;
      case FilterType.CATEGORY:
        this.filterModel.category = event.selectedList;
        break;
      case FilterType.PARTS_FLOW:
        this.filterModel.partsFlow = event.selectedList;
        break;
      default: {}
    }
  }

  applyFilterClicked() {
    this.scheduleRunTableData.filter(model => {
      return (
        (this.filterModel.partsController
          .map(item => item.name)
          .includes(model.partsController) ||  this.filterModel.partsController.length === 0) &&
        (this.filterModel.supplier
          .map(item => item.name)
          .includes(model.supplierCode) ||  this.filterModel.supplier.length === 0) &&
        (this.filterModel.category
          .map(item => item.name)
          .includes(model.partsCategory) ||  this.filterModel.category.length === 0) &&
        (this.filterModel.partsFlow
          .map(item => item.name)
          .includes(model.partTypeCode) ||  this.filterModel.partsFlow.length === 0)
      );
    });
  }

  clearFilterClicked() {
    this.filterModel = new FilterModel();
    this.isClearFilterSelected = true;
    setTimeout(() => {
      // resetting clear filter selected to false
      this.isClearFilterSelected = false;
    }, 5000);
  }

  setControlParamsClicked() {
    const partsSelected = this.scheduleRunTableComponent.getPartsSelected();
    this.selectedPartIds = partsSelected.selectedPartIds;
    this.selectedItemNumbers = partsSelected.selectedItemNumbers;
    this.isSidebarVisible = true;
  }

  getPlantId(): number {
    let plantId: number;
    this.eventListenerService.currentPlantId.subscribe(currentPlantId => {
      plantId = currentPlantId;
    });
    return plantId;
  }
}
