import { Injectable } from '@angular/core';
import { HttpService } from 'src/app/core/services/http-service/http.service';
import { Observable } from 'rxjs';
import { apiEndPoints } from 'src/app/configs/api-end-points';
import { Offset } from '../../models/schedule-run-offset';
import { ScheduleRunRow } from '../../models/scheduleRunRow';
import { Data } from '@angular/router';
import { MultiPartOffsetModel } from '../../models/multi-part-offset-model';
import { SinglePartOffsetModel } from '../../models/single-part-offset-model';
import { environment } from 'src/environments/environment';
import { of } from 'rxjs';
import { ScheduleRunMockConfig } from 'src/app/configs/mock/schedule-run-mock-config';

@Injectable({
  providedIn: 'root'
})
export class ScheduleRunService {

  constructor(private httpService: HttpService) { }

  public getScheduleRunOffsets(): Observable<Offset[]> {
    if (environment.mock) {
      return of(ScheduleRunMockConfig.offsets);
    } else {
      return this.httpService.get(apiEndPoints.scheduleRunOffsets, []);
    }
  }

  public getScheduleRunTable(dateString: Date, plantId: number): Observable<ScheduleRunRow[]> {
    if (environment.mock) {
      return of(ScheduleRunMockConfig.tableRows);
    } else {
      return this.httpService.get(apiEndPoints.scheduleRunTable, { date: dateString, plantId });
    }
  }

  public updateSinglePartOffset(requestBody: SinglePartOffsetModel): Observable<Data> {
    return this.httpService.put(apiEndPoints.singlePartOffset, requestBody);
  }

  public updateMultiPartsOffset(requestBody: MultiPartOffsetModel): Observable<Data> {
    return this.httpService.post(apiEndPoints.multiPartOffset, requestBody);
  }
}
