import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateSideMenuComponent } from './update-side-menu.component';

describe('UpdateSideMenuComponent', () => {
  let component: UpdateSideMenuComponent;
  let fixture: ComponentFixture<UpdateSideMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateSideMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateSideMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
