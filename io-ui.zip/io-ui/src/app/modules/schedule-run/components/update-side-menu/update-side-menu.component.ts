import { Component, OnInit, OnChanges, SimpleChanges, Output, EventEmitter, Input } from '@angular/core';
import { FilterModel } from 'src/app/shared/models/filter-model';
import { Offset } from '../../models/schedule-run-offset';
import { ScheduleRunService } from '../schedule-run/schedule-run.service';
import { MultiPartOffsetModel } from '../../models/multi-part-offset-model';
import { DatePipe } from '@angular/common';
import { EventListenerService } from 'src/app/shared/services/event-listener/event-listener.service';

@Component({
  selector: 'io-update-side-menu',
  templateUrl: './update-side-menu.component.html',
  styleUrls: ['./update-side-menu.component.scss']
})
export class UpdateSideMenuComponent implements OnInit {

  @Input() filterModel: FilterModel;
  @Input() selectedPartIds: number[];
  @Input() selectedItemNumbers: string[];
  @Input() offsets: Offset[];
  @Output() sidebarClosed = new EventEmitter<boolean>();

  selectedOffsetList: Offset[] = [];
  selectedOffset: Offset;

  constructor( private scheduleRunService: ScheduleRunService, private eventListenerService: EventListenerService) { }

  ngOnInit() {
  }

  closeSidebar() {
    this.sidebarClosed.emit(true);
  }

  addOffset() {
    const index = this.selectedOffsetList.findIndex(item => item.offsetId === this.selectedOffset.offsetId);
    if (index === -1) {
      const updatedOffset = new Offset();
      updatedOffset.offsetName =  this.selectedOffset.offsetName;
      updatedOffset.offsetId = this.selectedOffset.offsetId;
      this.selectedOffsetList.push(updatedOffset);
    }
  }

  deleteOffset(offset: Offset) {
    this.selectedOffsetList = this.selectedOffsetList.filter( value => value.offsetId !== offset.offsetId);
  }

  updateButtonClicked() {
    const offsetsToBeUpdated = this.selectedOffsetList.filter(offset => {
      return offset.offsetValue !== undefined && offset.offsetStartDate !== undefined && offset.offsetEndDate !== undefined;
    });
    for (const item of offsetsToBeUpdated) {
      const datePipe = new DatePipe('en-US');
      item.offsetStartDate = datePipe.transform(item.offsetStartDate, 'yyyy-MM-dd');
      item.offsetEndDate = datePipe.transform(item.offsetEndDate, 'yyyy-MM-dd');
    }

    let plantId = 0;
    this.eventListenerService.currentPlantId.subscribe(currentPlantId => {
      plantId = currentPlantId || 2;
    });
    const multiPartOffsetModel = new MultiPartOffsetModel(plantId, this.selectedPartIds, offsetsToBeUpdated);
    this.scheduleRunService.updateMultiPartsOffset(multiPartOffsetModel).subscribe(data => {
      this.closeSidebar();
    });
    this.closeSidebar();
  }

  clearAllButtonClicked() {
    this.selectedOffsetList = [];
  }
}
