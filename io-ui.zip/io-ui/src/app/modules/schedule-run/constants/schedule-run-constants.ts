export const scheduleRunConstants = {
  frozenColumns: [
    {
        label: 'Item Number',
        key: 'itemNumber',
        sticky: 'true'
    },
    {
      label: 'Offsets',
      key: 'offsets',
      sticky: 'true',
      children: [

      ]
    },
  ],
  tableColumns: [
    {
      label: 'Last Run',
      key: 'lastRun',
      children: [
        {
          label: 'Curr Float',
          key: 'currFloat'
        },
        {
          label: 'Rec SL',
          key: 'recSL'
        },
        {
          label: 'Rec Float',
          key: 'recFloat'
        }
      ]
    },
    {
        label: 'Plant Code',
        key: 'plantCode',
    },
    {
      label: 'Model Execution Date',
      key: 'modelExecutionDate'
    },
    // {
    //     label: 'Distribution Type(Lead Time)',
    //     key: 'distributionTypeLeadTime'
    // },
    // {
    //     label: 'Distribution Type for Demand',
    //     key: 'distributionTypeDemand',
    //     sticky: 'false'
    // },
    {
      label: 'Unit Price',
      key: 'unitPrice'
    },
    {
      label: 'Supplier Type',
      key: 'supplierType'
    },
    {
      label: 'Supplier Code',
      key: 'supplierCode'
    },
    // {
    //     label: 'Supplier Name',
    //     key: 'supplierName'
    // },
    // {
    //     label: 'Supplier Location',
    //     key: 'supplierLocation'
    // },
    {
      label: 'Baseline Inventory Qty',
      key: 'baselineInventoryQuantity'
    },
    {
      label: 'Baseline Inventory Value',
      key: 'baselineInventoryValue'
    },
    // {
    //     label: 'Total Demand Forecast(6m)',
    //     key: 'totalDemandForecast'
    // },
    // {
    //     label: 'Total Demand Status',
    //     key: 'totalDemandStatus'
    // },
    // {
    //     label: 'Average Daily Demand',
    //     key: 'averageDailyDemand'
    // },

    {
      label: 'ABC Class by Inventory Value',
      key: 'abcClassInventoryValue'
    },
    {
      label: 'ABC Class by Consumption Value',
      key: 'abcClassConsumptionValue'
    },
    {
      label: 'XYZ Class by Demand CoV',
      key: 'xyzClassCoefficientOfVarianceDemandForecast'
    },
    // {
    //     label: 'Other Class',
    //     key: 'otherClass'
    // },
    {
      label: 'Min RAN Qty',
      key: 'minimumRanOrderQuantity'
    },

    {
      label: 'SNQ Qty',
      key: 'snqQuantity'
    },
    {
        label: 'Float recommended(days)',
        key: 'floatRecommendedDays'
    },
    {
      label: 'Op Reserve Qty',
      key: 'operationalReserveQuantity'
    },
    {
      label: 'Op Reserve Value',
      key: 'operationalReserveValue'
    },
    {
        label: 'Service Level',
        key: 'serviceLevel'
    },
    // {
    //     label: 'Ran Purchase Freq(days)',
    //     key: 'purchaseFrequencyRanDays'
    // },
    // {
    //     label: 'Purchase Lead Time(days)',
    //     key: 'purchaseLeadTime'
    // },
    // {
    //     label: 'Min Flag(Calc LT/PF)',
    //     key: 'minimumFlag'
    // },

    // {
    //     label: 'CoV for Daily Demand',
    //     key: 'coefficientOfVarianceDailyDemand'
    // },
    // {
    //     label: 'CoV for Daily Demand(OM)',
    //     key: 'coefficientOfVarianceDailyOmDemand'
    // },
    // {
    //     label: 'CoV for Lead Time Var',
    //     key: 'coefficientOfVarianceLeadTimeVariability'
    // },
    // {
    //     label: 'CoV for Lead Time Var(OM)',
    //     key: 'coefficientOfVarianceLeadTimeVariabilityOm'
    // },
    // {
    //     label: 'Purchase Freq Variability',
    //     key: 'purchaseFrequencyVariability'
    // },
    // {
    //     label: 'Purchase Freq Var(OM)',
    //     key: 'purchaseFrequencyVariabilityOm'
    // },
    // {
    //     label: 'Safety Stock Qty(Demand Var)',
    //     key: 'safetyStockQuantityDemandVariability'
    // },
    // {
    //     label: 'Safety Stock Value(Demand Var)',
    //     key: 'safetyStockValueDemandVariability'
    // },
    // {
    //     label: 'Safety Stock(Supply Var)',
    //     key: 'safetyStockQuantitySupplierVariability'
    // },
    // {
    //     label: 'Safety Stock Value(Supply Var)',
    //     key: 'safetyStockValueSupplierVariability'
    // },
    // {
    //     label: 'Total Safety Stock Qty',
    //     key: 'totalSafetyStockQuantity'
    // },
    // {
    //     label: 'Safety Stock Value',
    //     key: 'safetyStockValue'
    // },
    {
      label: 'Direct Pipeline Stock Qty',
      key: 'directPipelineStockQuantity'
    },
    // {
    //     label: 'Direct Pipeline Stock Value',
    //     key: 'directPipelineStockValue'
    // },

    {
      label: 'ILC Pipeline Stock Qty',
      key: 'ilcPipelineStockQuantity'
    },
    // {
    //     label: 'ILC Pipeline Stock Value',
    //     key: 'ilcPipelineStockValue'
    // },

    // {
    //     label: 'Scrap Qty',
    //     key: 'scrapQuantity'
    // },
    {
      label: 'Scrap(% of Tot Ann Dem aft OM)',
      key: 'scrapPercentageToAnnualDemand'
    },
    // {
    //     label: 'Max Scrap Qty Instance',
    //     key: 'maximumScrapQuantityInstance'
    // },
    // {
    //     label: 'Max Scrp Qty Ins(% of Op Rsrv)',
    //     key: 'maximumScrapQuantityInstancePercentage'
    // },
    // {
    //     label: 'Cycle Loss Qty',
    //     key: 'totalCycleLossQuantity'
    // },
    {
      label: 'CL(% of Tot Ann Dem aft OM)',
      key: 'cycleLossPercentageTotalAnnualDemand'
    },
    // {
    //     label: 'Max Cycle Loss Qty Instance',
    //     key: 'maximumCycleLossQuantityInstance'
    // },
    // {
    //     label: 'Max CL Qty Ins(% of Op Rsrv)',
    //     key: 'maximumCycleLossQuantityInstancePercentage'
    // },
    {
      label: 'Total Recom Float(hrs)',
      key: 'totalRecommendedFloatHours'
    },
    {
      label: 'Total Recom Float(days)',
      key: 'totalRecommendedFloatDays'
    },
    {
      label: 'Float Inventory Savings($)',
      key: 'floatInventorySavings'
    },
    // {
    //     label: 'Total Recom Float Qty',
    //     key: 'totalRecommendedFloatQuantity'
    // },
    // {
    //     label: 'Total Recommended Float Value',
    //     key: 'totalRecommendedFloatValue'
    // },
    {
      label: 'Min Recom Float(hrs)',
      key: 'minimumRecommendedFloatHours'
    },
    {
      label: 'Min Recom Float(days)',
      key: 'minimumRecommendedFloatDays'
    },
    {
      label: 'Min Float Qty',
      key: 'minimumFloatQuantity'
    },
    // {
    //     label: 'Min Float Value',
    //     key: 'minimumFloatValue'
    // },
    {
      label: '% Change(Recom Float Value)',
      key: 'changePercentageRecommendedFloatValue'
    },
     {
        label: 'Parts Category',
        key: 'partsCategory'
    },
    {
        label: 'Parts Controller',
        key: 'partsController'
    },
    {
        label: 'Part Type Code',
        key: 'partTypeCode'
    },
    {
      label: '',
      key: ''
    },
    {
      label: '',
      key: ''
    },
    // {
    //     label: 'Total Recom Reorder Qty',
    //     key: 'totalRecommendedReorderQuantity'
    // },
    // {
    //     label: 'Total Recom Cycle Stock Qty',
    //     key: 'totalRecommendedCycleStockQuantity'
    // },
    // {
    //     label: 'Total Recom On-hand Stock Qty',
    //     key: 'totalRecommendedOnHandStockQuantity'
    // },
    // {
    //     label: 'Total Recom On-hand Stock Val',
    //     key: 'totalRecommendedOnHandStockValue'
    // },
    // {
    //     label: 'Active Mgmnt Lever 1(Days)',
    //     key: 'activeManagementLever1Days',
    //     sticky: 'false'
    // }
  ],
  errorMessages: {
    partIdNotAvailable: 'Part Id is not available. Please check the request',
    offsetStartDateEmpty: 'Please enter offset start date',
    offsetEndDateEmpty: 'Please enter offset end date'

  }
};
