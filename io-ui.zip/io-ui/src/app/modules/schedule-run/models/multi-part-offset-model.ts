import { Offset } from './schedule-run-offset';

export class MultiPartOffsetModel {
    public plantId: number;
    public partIds: number[];
    public offset: Offset[];

    constructor(plantId: number, partIds: number[], offset: Offset[]) {
        this.plantId = plantId;
        this.partIds = partIds;
        this.offset = offset;
    }
}
