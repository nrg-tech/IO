export class ScheduleLastRunModel {
    public currFloat: number;
    public recSL: number;
    public recFloat: number;
}
