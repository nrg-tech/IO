export class Offset {
    public offsetEndDate: string;
    public offsetId: number;
    public offsetName: string;
    public offsetStartDate: string;
    public offsetValue: number;
}
