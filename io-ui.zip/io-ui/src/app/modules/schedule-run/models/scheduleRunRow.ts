import { Offset } from './schedule-run-offset';
import { ScheduleLastRunModel } from './schedule-last-run-model';

export class ScheduleRunRow {
    public plantCode: string;
    public lastRun: ScheduleLastRunModel;
    public offsets: Offset[];
    public partId: number;
    public itemNumber: string;
    public serviceLevel: number;
    public modelExecutionDate: string;
    public unitPrice: number;
    public supplierType: string;
    public supplierCode: string;
    public baselineInventoryQuantity: number;
    public baselineInventoryValue: number;
    public abcClassInventoryValue: string;
    public abcClassConsumptionValue: string;
    public xyzClassCoefficientOfVarianceDemandForecast: string;
    public minimumRanOrderQuantity: number;
    public snqQuantity: number;
    public floatRecommendedDays: number;
    public operationalReserveQuantity: number;
    public operationalReserveValue: number;
    public directPipelineStockQuantity: number;
    public ilcPipelineStockQuantity: number;
    public scrapPercentageToAnnualDemand: number;
    public cycleLossPercentageTotalAnnualDemand: number;
    public totalRecommendedFloatHours: number;
    public totalRecommendedFloatDays: number;
    public floatInventorySavings: number;
    public minimumRecommendedFloatHours: number;
    public minimumRecommendedFloatDays: number;
    public minimumFloatQuantity: number;
   public changePercentageRecommendedFloatValue: number;
   public partsCategory: string;
   public partsController: string;
   public partTypeCode: string;
}
