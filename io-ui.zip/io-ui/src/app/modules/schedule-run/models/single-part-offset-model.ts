import { Offset } from './schedule-run-offset';

export class SinglePartOffsetModel {
    public plantId: number;
    public userId: number;
    public partId: number;
    public sl: number;
    public offset: Offset;

    // constructor(plantId: number, userId: number, partId: number, offset: ScheduleRunOffset) {
    //     this.plantId = plantId;
    //     this.userId = userId;
    //     this.partId = partId;
    //     this.offset = offset;
    // }
}
