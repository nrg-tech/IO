import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ScheduleRunTableComponent } from './components/schedule-run-table/schedule-run-table.component';
import { ScheduleRunComponent } from './components/schedule-run/schedule-run.component';

const routes: Routes = [
  {
    path: '',
    component: ScheduleRunComponent,
    data: {
      breadcrumb: 'Schedule Run'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ScheduleRunRoutingModule { }
