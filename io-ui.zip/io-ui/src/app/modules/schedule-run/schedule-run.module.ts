import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScheduleRunMaterialModule } from './schedule-run-material/schedule-run-material.module';
import { ScheduleRunRoutingModule } from './schedule-run-routing.module';
import { ScheduleRunTableComponent } from './components/schedule-run-table/schedule-run-table.component';
import { PrimeNgModule } from '../../shared/prime-ng/prime-ng.module';
import { FormsModule } from '@angular/forms';
import { UpdateSideMenuComponent } from './components/update-side-menu/update-side-menu.component';
import { EditMenuComponent } from './components/edit-menu/edit-menu.component';
import { ScheduleRunComponent } from './components/schedule-run/schedule-run.component';
import { FilterModule } from 'src/app/shared/modules/filter.module';

@NgModule({
  declarations: [ScheduleRunComponent, UpdateSideMenuComponent, EditMenuComponent, ScheduleRunComponent, ScheduleRunTableComponent],
  imports: [
    CommonModule,
    ScheduleRunRoutingModule,
    ScheduleRunMaterialModule,
    PrimeNgModule,
    FormsModule,
    FilterModule
  ]
})
export class ScheduleRunModule { }
