import { Component, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'io-filter-menu',
  templateUrl: './filter-menu.component.html',
  styleUrls: ['./filter-menu.component.scss']
})
export class FilterMenuComponent implements OnInit {

  @ViewChild('childMenu') public childMenu;
  constructor() { }

  ngOnInit() {
  }

}
