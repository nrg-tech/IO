import { Component, OnInit, Input, ViewChild, Output, EventEmitter, SimpleChanges, OnChanges } from '@angular/core';
import { FilterItemModel } from '../../models/filter-item-model';
import { FilterType } from '../../enums/filter-type-enum';
import { FilterService } from '../../services/filter/filter.service';
import { FilterConfig } from 'src/app/configs/filter-config';


@Component({
  selector: 'io-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss'],

})
export class FilterComponent implements OnInit, OnChanges {
  @ViewChild('filterMatSelect') filterMatSelect;
  @Input() filterType: FilterType;
  @Input() isClearFilterSelected: boolean;
  @Output() selectedFilterParams: EventEmitter <any> = new EventEmitter();

  dropDownList: FilterItemModel[];
  filteredList: FilterItemModel[];
  selectedListTobeDisplayed: FilterItemModel[] = [];
  selectedList: FilterItemModel[] = [];
  remainingChiplist = [];

  filterName: string;
  selectable = true;
  removable = true;
  isSelectAllClicked = false;
  isFilterPopupOpen = false;
  isFilterDataLoaded = false;
  isShowAllChipsSelected = false;

  constructor(private filterService: FilterService) {
  }

  ngOnInit() {
    if (!this.isFilterDataLoaded) {
      this.isFilterDataLoaded = true;
      this.getFilterData();
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    for (const property in changes) {
        if (property === 'isClearFilterSelected' && changes[property].currentValue === true) {
          this.filteredList = Object.assign([], this.dropDownList);
          this.selectedListTobeDisplayed = [];
          this.remainingChiplist = [];
          this.selectedList = Object.assign([], this.selectedListTobeDisplayed);
          this.isSelectAllClicked = false;
        }
    }
}

  getFilterData() {
    switch (this.filterType) {
      case FilterType.PARTS_CONTROLLER:
        this.filterName = FilterConfig.PARTS_CONTROLLER_FILTER_TYPE;
        this.getRoles() ;
        break;
      case FilterType.SUPPLIER:
          this.filterName = FilterConfig.SUPPLIER_FILTER_TYPE;
          this.getSuppliers() ;
          break;
      case FilterType.CATEGORY:
          this.filterName = FilterConfig.CATEGORY_FILTER_TYPE;
          this.getCategories() ;
          break;
      // case FilterType.LOCATION:
      //     this.filterName = FilterConfig.LOCATION_FILTER_TYPE;
      //     this.dropDownList = FilterConfig.LOCATION_LIST;
      //     this.filteredList = this.dropDownList;
      //     break;
       case FilterType.PARTS_FLOW:
          this.filterName = FilterConfig.PARTS_FLOW_FILTER_TYPE;
          this.dropDownList = FilterConfig.PARTS_FLOW_LIST;
          this.filteredList = this.dropDownList;
          break;
     }
  }

  getRoles() {
    this.filterService.getRoles('Parts+Controller').subscribe(data => {
      this.dropDownList = data;
      this.filteredList = Object.assign([], this.dropDownList);
    });
  }

  getSuppliers() {
    this.filterService.getSuppliers().subscribe(data => {
      this.dropDownList = data;
      this.filteredList = Object.assign([], this.dropDownList);
    });
  }

  getCategories() {
    this.filterService.getCategories().subscribe(data => {
      this.dropDownList = data;
      this.filteredList = Object.assign([], this.dropDownList);
    });
    console.log('filtered list', this.filteredList);
  }

  // Receive user input and send to search method**
  onKey(value) {
    this.filteredList = this.search(value);
  }

  toggleSelection(value: boolean) {
    if (value) {
     this.selectedListTobeDisplayed = Object.assign([], this.dropDownList);
    } else {
      this.selectedListTobeDisplayed = [];
    }
  }

  search(value: string) {
    const filter = value.toLowerCase();
    return this.dropDownList.filter(option =>
      option.name.toLowerCase().includes(filter)
    );
  }

  remove(item: FilterItemModel): void {
    const index = this.selectedListTobeDisplayed.indexOf(item);
    if (index >= 0) {
    this.selectedListTobeDisplayed.splice(index, 1);
    const indexOfDeleteditem  =  this.remainingChiplist.indexOf(item);
    if (indexOfDeleteditem >= 0) {
      this.remainingChiplist.splice(indexOfDeleteditem, 1);
    }

   }
    this.selectedListTobeDisplayed = Object.assign([], this.selectedListTobeDisplayed);
    this.remainingChiplist = Object.assign([], this.remainingChiplist);
    this.selectedList = Object.assign([], this.selectedListTobeDisplayed);
    if (this.remainingChiplist.length === 0) {
      this.isShowAllChipsSelected =  false;
    }
 }

  showOrHideAllChips() {
    this.remainingChiplist = this.selectedList.slice(2, this.selectedList.length);
    this.isShowAllChipsSelected = !this.isShowAllChipsSelected;
  }

  filterPopupOpenedChange(isOpen: boolean) {
    this.isFilterPopupOpen = isOpen;
  }

  applyButtonClicked() {
    this.selectedList = this.selectedListTobeDisplayed;
    this.selectedFilterParams.emit({filterType: this.filterType, selectedList: this.selectedList});
    this.filterMatSelect.close();
  }

  cancelButtonClicked() {
    this.selectedListTobeDisplayed = this.selectedList;
    this.isFilterPopupOpen = false;
    this.filterMatSelect.close();
  }

}
