import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'io-legend',
  templateUrl: './legend.component.html',
  styleUrls: ['./legend.component.scss']
})
export class LegendComponent implements OnInit {

  @Input() legends: any;

  constructor() { }

  ngOnInit() {
  }

}
