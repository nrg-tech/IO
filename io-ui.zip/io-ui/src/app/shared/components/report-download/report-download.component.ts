import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { MatMenuTrigger } from '@angular/material';
import { ExcelService } from '../../services/export/excel.service';
import { lastRunTableConstants } from 'src/app/modules/last-run/constants/last-run-table-constants';
import { scheduleRunConstants } from 'src/app/modules/schedule-run/constants/schedule-run-constants';

@Component({
  selector: 'io-report-download',
  templateUrl: './report-download.component.html',
  styleUrls: ['./report-download.component.scss']
})
export class ReportDownloadComponent implements OnInit {

  @ViewChild('downloadReport') public downloadReport;
  @Output() triggerMenu = new EventEmitter<string>();
  @Input() featureModule: string;
  @Input() allData: any;
  @Input() filteredData: any;
  @Input() completeTableSize: number;
  @Input() filteredTableSize: number;
  reportDownloadOption = 'all';
  exportType: string;
  exportTypes = ['Excel', 'CSV'];
  constructor(private excelService: ExcelService) { }

  ngOnInit() {
    this.exportType = this.exportTypes[0];
  }

  closeMenu(action: string) {
    this.triggerMenu.emit('downloadReport');
    if (action === 'download') {
      this.generateSpreadsheet();
    }
  }
  generateSpreadsheet() {
    if (this.featureModule === 'lastRun') {
      Array.prototype.push.apply(lastRunTableConstants.frozenColumns, lastRunTableConstants.columns);
      const newobj = Object.assign([], lastRunTableConstants.frozenColumns);
      if (this.reportDownloadOption.toUpperCase() === 'ALL') {
        this.excelService.exportAsExcelFile(this.allData, newobj, 'Last Run', 'Last Run');
      } else {
        this.excelService.exportAsExcelFile(this.filteredData, newobj, 'Last Run', 'Last Run');
      }
    } else {
      Array.prototype.push.apply(scheduleRunConstants.frozenColumns, lastRunTableConstants.columns);
      const newobj = Object.assign([], scheduleRunConstants.frozenColumns);
      if (this.reportDownloadOption.toUpperCase() === 'ALL') {
        this.excelService.exportAsExcelFile(this.allData, newobj, 'Schedule Run', 'Schedule Run');
      } else {
        this.excelService.exportAsExcelFile(this.filteredData, newobj, 'Schedule Run', 'Schedule Run');
      }
    }
  }
}
