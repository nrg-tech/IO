export enum FilterType {
    PARTS_CONTROLLER = 1,
    SUPPLIER,
    CATEGORY,
  //  LOCATION,
    PARTS_FLOW
}
