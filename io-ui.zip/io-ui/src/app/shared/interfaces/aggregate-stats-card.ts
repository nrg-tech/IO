export interface AggregateStatsCardBase {
    title: string;
    valueId: string;
    differenceId?: string;
    value?: string;
    difference?: number;
    backgroundImage: string;
    currency?: string;
}

export interface AggregateStatsCard {
    stockKeepingUnit: number;
    currentInventoryBaseline: number;
    currentInventoryBaselineDifference: number;
    currentSafetyStock: number;
    currentSafetyStockDifference: number;
    surplusSafetyStock: number;
    surplusSafetyStockDifference: number;
}
