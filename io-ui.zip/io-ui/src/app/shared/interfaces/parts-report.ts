export class PartsReport {
    partNumber: string;
    isSelected ?= false;
}

export class PartSelected {
    partNumber: string;
    isAdded ?= false;
}
