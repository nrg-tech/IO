export interface PlantDetails {
    plantId: number;
    plantName: string;
}
