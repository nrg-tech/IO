export interface Runtime {
    date: Date;
    timeZone: string;
}
