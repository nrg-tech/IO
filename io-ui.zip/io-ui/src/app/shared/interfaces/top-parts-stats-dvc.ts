export interface TopPartsStatsDVC {
    averageDailyDemand: number;
    coefVariableDailyDemand: number;
    itemNumber: number;
}
