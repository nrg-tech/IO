export interface TopPartsStatsOverview {
    currentFloat: number;
    floatSurplus: number;
    itemNumber: string;
    recommendedFloat: number;
}
