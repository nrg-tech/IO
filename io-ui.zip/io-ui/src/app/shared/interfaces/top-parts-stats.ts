export interface TopPartsStatsOverview {
    currentFloat: number;
    floatSurplus: number;
    itemNumber: string;
    recommendedFloat: number;
}


export interface TopPartsStatsDVC {
    averageDailyDemand: number;
    coefVariableDailyDemand: number;
    itemNumber: string;
}


export interface TopPartsStatsSVC {
    averageSupplyCycleTime: number;
    coefVariableSupplyCycleTime: number;
    itemNumber: string;
}
