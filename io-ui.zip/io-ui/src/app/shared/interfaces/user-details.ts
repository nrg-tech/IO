export interface UserDetails {
    userId: number;
    firstName: string;
    lastName: string;
    userRole: string;
    userImage: string;
}
