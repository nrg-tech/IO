import { FilterItemModel } from './filter-item-model';

export class FilterModel {
  public partsController: FilterItemModel[] = [];
  public supplier: FilterItemModel[] = [];
  public category: FilterItemModel[] = [];
 // public location: FilterItemModel[];
  public partsFlow: FilterItemModel[] = [];
}
