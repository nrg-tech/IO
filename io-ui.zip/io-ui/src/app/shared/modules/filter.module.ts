import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Components import
import { FilterComponent } from '../../shared/components/filter/filter.component';
import { FilterMenuComponent } from '../components/filter-menu/filter-menu.component';

// Module imports
import { MatChipsModule } from '@angular/material/chips';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { FormsModule } from '@angular/forms';
import { ScrollingModule } from '@angular/cdk/scrolling';

@NgModule({
  declarations: [
    FilterComponent,
    FilterMenuComponent,
  ],
  imports: [
    CommonModule,
    MatChipsModule,
    MatSelectModule,
    MatIconModule,
    MatCheckboxModule,
    MatButtonModule,
    FormsModule,
    ScrollingModule,
    MatMenuModule,
  ],
  exports: [
    FilterComponent,
    FilterMenuComponent,
  ]
})
export class FilterModule { }
