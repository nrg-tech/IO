import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

// Component
import { LegendComponent } from '../components/legend/legend.component';

@NgModule({
  declarations: [
    LegendComponent,
  ],
  imports: [
    CommonModule
  ],
  exports: [
    LegendComponent,
  ]
})
export class LegendModule { }
