import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// components import
import { ReportDownloadComponent } from '../components/report-download/report-download.component';

// Modules import
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    ReportDownloadComponent,
  ],
  imports: [
    CommonModule,
    MatSelectModule,
    MatRadioModule,
    MatMenuModule,
    MatButtonModule,
    FormsModule,

  ],
  exports: [
    ReportDownloadComponent,
  ]
})
export class ReportDownloadModule { }
