import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {TableModule} from 'primeng/table';
import {SidebarModule} from 'primeng/sidebar';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    TableModule,
    SidebarModule,
  ],
  exports: [
    TableModule,
    SidebarModule,
  ]
})
export class PrimeNgModule { }
