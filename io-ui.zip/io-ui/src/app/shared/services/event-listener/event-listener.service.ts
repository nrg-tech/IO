import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Runtime } from '../../interfaces/runtime';

@Injectable({
  providedIn: 'root'
})
export class EventListenerService {

  private plantSource = new BehaviorSubject(null);
  private runtimeSource = new BehaviorSubject(null);

  currentPlantId = this.plantSource.asObservable();
  runtimeDetail = this.runtimeSource.asObservable();

  constructor() { }

  updatePlant(plantId: number) {
    this.plantSource.next(plantId);
  }

  updateRuntime(runtime: Runtime) {
    this.runtimeSource.next(runtime);
  }
}
