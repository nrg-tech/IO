import { Injectable } from '@angular/core';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';

@Injectable({
  providedIn: 'root'
})
export class ExcelService {

  constructor() { }

  public exportAsExcelFile(json: any[], headers: any[], excelFileName: string, sheetName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const range = XLSX.utils.decode_range(worksheet['!ref']);
    for (let rangeCount = range.s.r; rangeCount <= range.e.r; ++rangeCount) {
      const address = XLSX.utils.encode_col(rangeCount); // <-- first row, column number C
      if (!worksheet[address]) {
        continue;
      }

      worksheet[address].v = headers[rangeCount].label.toUpperCase();
    }
    const workbook: XLSX.WorkBook = { Sheets: { [sheetName] : worksheet }, SheetNames: [sheetName.toString()] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }
  private saveAsExcelFile(buffer: any, fileName: string): void {
     const data: Blob = new Blob([buffer], {type: EXCEL_TYPE});
     FileSaver.saveAs(data, `${fileName}${EXCEL_EXTENSION}`);
  }
}
