import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { apiEndPoints } from 'src/app/configs/api-end-points';
import { HttpService } from 'src/app/core/services/http-service/http.service';
import { FilterItemModel } from '../../models/filter-item-model';

@Injectable({
  providedIn: 'root'
})
export class FilterService {
  constructor(private httpService: HttpService) {}

  public getRoles(role: string): Observable<FilterItemModel[]> {
    return this.httpService
      .get(apiEndPoints.roles, { role })
      .pipe(
        map((data: any[]) =>
          data.map(
            (item: any) =>
              new FilterItemModel(
                item.userName,
                item.userName
               // item.lastName + ', ' + item.firstName
              )
          )
        )
      );
  }

  public getSuppliers(): Observable<FilterItemModel[]> {
    return this.httpService.get(apiEndPoints.suppliers).pipe(
        map((data: any[]) =>
          data.map(
            (item: any) =>
              new FilterItemModel(item.id, item.supplierCode)
          )
        )
      );
  }

  public getCategories(): Observable<FilterItemModel[]> {
    return this.httpService
      .get(apiEndPoints.categories);
      // .pipe(
      //   map((data: any[]) =>
      //     data.map(
      //       (item: any) =>
      //         new FilterItemModel(item.categoryId, item.partCategoryDescription)
      //     )
      //   )
      // );
  }
}
