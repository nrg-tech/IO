export const environment = {
  production: true,
  baseURL: 'localhost:8080',
  basePath: '/io',
  baseAssetPath: '/sample'
};
